/*
 * SubFlow core — чистая логика без зависимостей от After Effects / Node.
 * Работает и в панели (window.SFCore), и в тестах (require).
 *
 * Слово:     { w: "Привет,", s: 0.52, e: 0.91 }      (секунды)
 * Подпись:   { start, end, text }                      (text может содержать \n)
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.SFCore = api;   /* в CEP с Node.js `module` существует, но панели нужен window.SFCore */
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ------------------------------------------------------------------ языки */
  var LANGS = {
    ru: { code: 'ru', label: 'Русский', short: 'RU', en: 'Russian' },
    en: { code: 'en', label: 'English', short: 'EN', en: 'English' },
    kk: { code: 'kk', label: 'Қазақша', short: 'KK', en: 'Kazakh' }
  };
  var NAME_TO_CODE = {
    russian: 'ru', english: 'en', kazakh: 'kk', ukrainian: 'uk', uzbek: 'uz',
    turkish: 'tr', german: 'de', french: 'fr', spanish: 'es', chinese: 'zh'
  };

  function normLang(x) {
    if (!x) return '';
    x = String(x).toLowerCase().trim();
    if (NAME_TO_CODE[x]) return NAME_TO_CODE[x];
    if (x === 'auto') return 'auto';
    return x.length > 2 ? x.slice(0, 2) : x;
  }
  function langName(code) {
    if (LANGS[code]) return LANGS[code].en;
    return code || 'unknown';
  }

  /* ------------------------------------------------------------------ время / SRT */
  function pad(n, w) {
    var s = String(n);
    while (s.length < w) s = '0' + s;
    return s;
  }

  function fmtTime(sec) {
    if (!(sec > 0)) sec = 0;
    var ms = Math.round(sec * 1000);
    var h = Math.floor(ms / 3600000); ms -= h * 3600000;
    var m = Math.floor(ms / 60000); ms -= m * 60000;
    var s = Math.floor(ms / 1000); ms -= s * 1000;
    return pad(h, 2) + ':' + pad(m, 2) + ':' + pad(s, 2) + ',' + pad(ms, 3);
  }

  // короткий вид для интерфейса: 1:05.30
  function fmtShort(sec) {
    if (!(sec > 0)) sec = 0;
    var m = Math.floor(sec / 60);
    var s = sec - m * 60;
    return m + ':' + (s < 10 ? '0' : '') + s.toFixed(2);
  }

  function parseShort(str) {
    str = String(str).trim().replace(',', '.');
    var m = /^(?:(\d+):)?(\d+(?:\.\d+)?)$/.exec(str);
    if (!m) return NaN;
    return (m[1] ? parseInt(m[1], 10) * 60 : 0) + parseFloat(m[2]);
  }

  function toSRT(captions) {
    var out = [];
    for (var i = 0; i < captions.length; i++) {
      var c = captions[i];
      out.push((i + 1) + '\n' + fmtTime(c.start) + ' --> ' + fmtTime(c.end) + '\n' +
        String(c.text).replace(/\r\n?/g, '\n').replace(/^\n+|\n+$/g, ''));
    }
    return out.join('\n\n') + '\n';
  }

  var SRT_TIME = /(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})/;
  function msOf(str) { return parseInt((str + '00').slice(0, 3), 10); }

  function parseSRT(text) {
    text = String(text).replace(/^﻿/, '').replace(/\r\n?/g, '\n');
    var blocks = text.split(/\n{2,}/);
    var out = [];
    for (var i = 0; i < blocks.length; i++) {
      var lines = blocks[i].split('\n');
      var ti = -1;
      for (var j = 0; j < lines.length; j++) { if (SRT_TIME.test(lines[j])) { ti = j; break; } }
      if (ti < 0) continue;
      var m = SRT_TIME.exec(lines[ti]);
      var start = (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + msOf(m[4]) / 1000;
      var end = (+m[5]) * 3600 + (+m[6]) * 60 + (+m[7]) + msOf(m[8]) / 1000;
      var body = lines.slice(ti + 1).join('\n')
        .replace(/<[^>]+>/g, '').replace(/\{\\[^}]*\}/g, '').trim();
      if (!body) continue;
      out.push({ start: start, end: end > start ? end : start + 0.5, text: body });
    }
    return out;
  }

  /* ------------------------------------------------------------------ пунктуация */
  // ES3-совместимо: ровно эта же функция продублирована в jsx/host.jsx (есть тест на совпадение).
  function stripPunct(s) {
    if (s === null || s === undefined) return '';
    var t = String(s);
    var NB = '[^\\s\'’‘`"«»“”„()\\[\\]{}.,!?;:…]';
    // апостроф внутри слова (don't, ол'дым) — оставляем
    t = t.replace(new RegExp('(' + NB + ')[\'’`](?=' + NB + ')', 'g'), '$1\u0001');
    // 3.5  10:30  1,5 — разделители между цифрами оставляем
    t = t.replace(/(\d)([.,:])(?=\d)/g, function (m, d, c) {
      return d + (c === '.' ? '\u0004' : (c === ',' ? '\u0005' : '\u0006'));
    });
    // дефис внутри слова (кто-то, 2-й) — оставляем
    t = t.replace(/([^\s\-–—])-(?=[^\s\-–—])/g, '$1\u0007');
    // сама пунктуация, кавычки, скобки, тире
    t = t.replace(/[.,!?;:…"«»“”„‟‹›‘’`´()\[\]{}¿¡•·]/g, '');
    t = t.replace(/[\-–—]/g, '');
    t = t.replace(/\u0001/g, "'").replace(/\u0004/g, '.').replace(/\u0005/g, ',')
      .replace(/\u0006/g, ':').replace(/\u0007/g, '-');
    t = t.replace(/[ \t]+/g, ' ').replace(/ ?([\r\n]) ?/g, '$1');
    return t.replace(/^[ \t]+|[ \t]+$/g, '');
  }

  /* ------------------------------------------------------------------ слова */
  var STOP = {};
  ('в во на с со к ко по из за от до о об у и а но да что как не ни же бы ли для при без над под про или то это ' +
    'a an the of to in on at for and or but with from by as is are was be that this my your our their his her its ' +
    'және мен бен пен да де та те не ол бұл үшін бір деп осы сол бірақ немесе ал').split(' ').forEach(function (w) { STOP[w] = 1; });

  function bare(t) {
    return String(t).toLowerCase().replace(/[^a-z0-9\u0400-\u04ff'\-]/g, '');
  }
  function isStop(t) { return STOP[bare(t)] === 1; }
  function isSentenceEnd(t) { return /[.!?…]+["»”’')\]]*$/.test(t); }
  function isClauseEnd(t) { return /[,;:—–]["»”’')\]]*$/.test(t); }

  // Текст -> слова, время делится пропорционально длине слов (для перевода и сегментного режима)
  function wordsFromText(text, start, end) {
    var toks = String(text).trim().split(/\s+/).filter(Boolean);
    if (!toks.length) return [];
    if (!(end > start)) end = start + 0.3 * toks.length;
    var weights = toks.map(function (t) { return Math.max(2, t.length) + 1; });
    var total = weights.reduce(function (a, b) { return a + b; }, 0);
    var out = [], acc = 0;
    for (var i = 0; i < toks.length; i++) {
      var s = start + (end - start) * (acc / total);
      acc += weights[i];
      out.push({ w: toks[i], s: s, e: start + (end - start) * (acc / total) });
    }
    return out;
  }

  /* ------------------------------------------------------------------ группировка */
  var DEF = { pause: 0.35, hardPause: 0.9, fillGap: 0.4, hold: 0.25, minDur: 0.4 };

  function chunkCost(words, a, b, hard, o) {
    var n = words.length;
    var len = b - a;
    var d = len - o.targetWords;
    var c = d * d * 0.9 + 1.0;
    if (b < n) {
      var last = words[b - 1], next = words[b];
      if (isSentenceEnd(last.w)) c -= 6;
      else if (isClauseEnd(last.w)) c -= 2.5;
      var gap = next.s - last.e;
      if (gap > o.pause) c -= 3 * Math.min(2, gap / o.pause);
      if (isStop(last.w)) c += 4;
    }
    if (len === 1 && o.targetWords > 1) c += 3;
    return c;
  }

  // Оптимальное разбиение: минимизирует «стоимость» (длина, паузы, знаки препинания, служебные слова)
  function dpGroup(words, o) {
    var n = words.length;
    if (!n) return [];
    o = {
      targetWords: o.targetWords || 3,
      maxWords: o.maxWords || 4,
      maxChars: o.maxChars || 28,
      pause: o.pause || DEF.pause,
      hardPause: o.hardPause || DEF.hardPause
    };
    var hard = [];
    for (var i = 0; i < n; i++) {
      var gap = i + 1 < n ? words[i + 1].s - words[i].e : 99;
      hard.push(i === n - 1 || isSentenceEnd(words[i].w) || gap > o.hardPause);
    }
    var best = [0], prev = [-1];
    for (i = 1; i <= n; i++) best.push(Infinity);
    for (var a = 0; a < n; a++) {
      if (best[a] === Infinity) continue;
      var chars = 0;
      for (var b = a + 1; b <= n && b - a <= o.maxWords; b++) {
        chars += words[b - 1].w.length + (b - a > 1 ? 1 : 0);
        if (chars > o.maxChars && b - a > 1) break;
        var c = best[a] + chunkCost(words, a, b, hard, o);
        if (c < best[b]) { best[b] = c; prev[b] = a; }
        if (hard[b - 1]) break;
      }
    }
    var groups = [], k = n;
    while (k > 0) { groups.unshift(words.slice(prev[k], k)); k = prev[k]; }
    return groups;
  }

  function simpleGroups(words, size) {
    var out = [], cur = [];
    for (var i = 0; i < words.length; i++) {
      cur.push(words[i]);
      var gap = i + 1 < words.length ? words[i + 1].s - words[i].e : 99;
      if (cur.length >= size || isSentenceEnd(words[i].w) || gap > DEF.hardPause) { out.push(cur); cur = []; }
    }
    if (cur.length) out.push(cur);
    return out;
  }

  function sentenceGroups(words, o) {
    var raw = [], cur = [];
    for (var i = 0; i < words.length; i++) {
      cur.push(words[i]);
      var gap = i + 1 < words.length ? words[i + 1].s - words[i].e : 99;
      if (isSentenceEnd(words[i].w) || gap > 0.8) { raw.push(cur); cur = []; }
    }
    if (cur.length) raw.push(cur);
    var cap = o.maxChars * o.maxLines;
    var out = [];
    raw.forEach(function (g) {
      var chars = g.map(function (x) { return x.w; }).join(' ').length;
      if (chars <= cap) out.push(g);
      else dpGroup(g, { targetWords: 10, maxWords: 16, maxChars: cap }).forEach(function (x) { out.push(x); });
    });
    return out;
  }

  /* ------------------------------------------------------------------ перенос строк */
  // разбить слова на k строк, минимизируя самую длинную строку
  function partition(ws, k) {
    var n = ws.length;
    var pre = [0];
    for (var i = 0; i < n; i++) pre.push(pre[i] + ws[i].length + 1);
    function len(a, b) { return pre[b] - pre[a] - 1; }
    var memo = {};
    function go(a, parts) {
      var key = a + ':' + parts;
      if (memo[key]) return memo[key];
      var res;
      if (parts === 1) {
        var l = len(a, n);
        res = { max: l, sq: l * l, cuts: [] };
      } else {
        res = { max: Infinity, sq: Infinity, cuts: [] };
        for (var b = a + 1; b <= n - (parts - 1); b++) {
          var r = go(b, parts - 1);
          var l1 = len(a, b);
          var mx = Math.max(l1, r.max), sq = l1 * l1 + r.sq;
          if (mx < res.max || (mx === res.max && sq < res.sq)) res = { max: mx, sq: sq, cuts: [b].concat(r.cuts) };
        }
      }
      memo[key] = res;
      return res;
    }
    var r = go(0, k);
    var lines = [], from = 0;
    r.cuts.concat([n]).forEach(function (c) { lines.push(ws.slice(from, c).join(' ')); from = c; });
    return { lines: lines, max: r.max };
  }

  function wrapWords(ws, maxChars, maxLines) {
    var joined = ws.join(' ');
    if (!maxChars || maxLines <= 1 || ws.length < 2 || joined.length <= maxChars) return joined;
    var best = null;
    for (var k = 2; k <= Math.min(maxLines, ws.length); k++) {
      best = partition(ws, k);
      if (best.max <= maxChars) break;
    }
    return best.lines.join('\n');
  }

  /* ------------------------------------------------------------------ подписи */
  var MODES = {
    one:        { label: 'One Word' },
    two:        { label: 'Two Words' },
    smartShort: { label: 'Smart Short' },
    smartLong:  { label: 'Smart Long' },
    sentences:  { label: 'Sentences' },
    custom:     { label: 'Custom' }
  };

  function groupWords(words, mode, opts) {
    opts = opts || {};
    var mc = opts.maxCharsPerLine || 24;           // символов в строке
    var ml = opts.maxLines || 2;                   // строк
    switch (mode) {
      case 'one': return words.map(function (w) { return [w]; });
      case 'two': return simpleGroups(words, 2);
      case 'smartShort':
        return dpGroup(words, { targetWords: 3, maxWords: 4, maxChars: Math.min(26, mc * 2) });
      case 'smartLong':
        return dpGroup(words, { targetWords: 7, maxWords: 12, maxChars: mc * 2 });
      case 'sentences':
        return sentenceGroups(words, { maxChars: mc, maxLines: ml });
      case 'custom':
        var mw = Math.max(1, opts.maxWords || 5);
        return dpGroup(words, { targetWords: Math.max(1, Math.round(mw * 0.8)), maxWords: mw, maxChars: mc * ml });
      default:
        throw new Error('Неизвестный режим: ' + mode);
    }
  }

  function toCaptions(groups, mode, opts) {
    opts = opts || {};
    var mc = opts.maxCharsPerLine || 24;
    var ml = (mode === 'one' || mode === 'two') ? 1 : (mode === 'smartShort' ? 2 : (opts.maxLines || 2));
    if (mode === 'smartLong' && ml < 2) ml = 2;
    var caps = groups.map(function (g) {
      return {
        start: g[0].s,
        end: g[g.length - 1].e,
        text: wrapWords(g.map(function (x) { return x.w; }), mc, ml),
        words: g.length
      };
    });
    var minDur = mode === 'one' ? 0.15 : DEF.minDur;
    for (var i = 0; i < caps.length; i++) {
      var c = caps[i], nxt = caps[i + 1];
      if (nxt) {
        var gap = nxt.start - c.end;
        if (gap < DEF.fillGap) c.end = nxt.start;
        else c.end = Math.min(c.end + DEF.hold, nxt.start - 0.02);
      } else {
        c.end += DEF.hold;
      }
      if (c.end - c.start < minDur) c.end = nxt ? Math.min(c.start + minDur, nxt.start) : c.start + minDur;
      if (c.end <= c.start) c.end = c.start + 0.1;
    }
    return caps;
  }

  function makeCaptions(words, mode, opts) {
    if (!words || !words.length) return [];
    var clean = words.filter(function (w) { return w && w.w; });
    // знаки препинания нужны для группировки, поэтому чистим уже готовый текст
    var caps = toCaptions(groupWords(clean, mode, opts), mode, opts);
    if (opts && opts.removePunct) {
      caps.forEach(function (c) { c.text = stripPunct(c.text); });
      caps = caps.filter(function (c) { return c.text; });
    }
    return caps;
  }

  /* ------------------------------------------------------------------ сегменты (для перевода) */
  function segmentsFromWords(words) {
    var groups = dpGroup(words, { targetWords: 14, maxWords: 30, maxChars: 200 });
    return groups.map(function (g) {
      return { start: g[0].s, end: g[g.length - 1].e, text: g.map(function (x) { return x.w; }).join(' ') };
    });
  }

  // перевод сегмента -> слова с интерполированным временем
  function wordsFromSegments(segments) {
    var out = [];
    segments.forEach(function (s) { wordsFromText(s.text, s.start, s.end).forEach(function (w) { out.push(w); }); });
    return out;
  }

  /* ------------------------------------------------------------------ разбор ответов распознавания */
  var PUNCT_ONLY = /^[.,!?;:…»”"')\]\-–—]+$/;
  var OPEN_ONLY = /^[«“„"(\[]+$/;

  function fixTimes(words) {
    var prevS = 0;
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      if (w.s < prevS) w.s = prevS;
      if (!(w.e > w.s)) w.e = w.s + 0.08;
      prevS = w.s;
    }
    return words;
  }

  // whisper.cpp -oj
  // precise = true: файл сделан с -ml 1 -sow (каждое слово — отдельный сегмент)
  function parseWhisperCpp(obj, precise) {
    var items = (obj && obj.transcription) || [];
    var lang = normLang(obj && obj.result && obj.result.language);
    var words = [], pending = '';
    items.forEach(function (it) {
      var t = String(it.text || '').replace(/\s+/g, ' ').trim();
      if (!t || /^\[[^\]]*\]$/.test(t)) return;
      var s = ((it.offsets && it.offsets.from) || 0) / 1000;
      var e = ((it.offsets && it.offsets.to) || 0) / 1000;
      if (precise) {
        if (OPEN_ONLY.test(t)) { pending += t; return; }
        if (PUNCT_ONLY.test(t) && words.length) {
          words[words.length - 1].w += t;
          words[words.length - 1].e = Math.max(words[words.length - 1].e, e);
          return;
        }
        words.push({ w: pending + t, s: s, e: e });
        pending = '';
      } else {
        wordsFromText(t, s, e).forEach(function (w) { words.push(w); });
      }
    });
    return { language: lang, words: fixTimes(words) };
  }

  // OpenAI verbose_json: в words нет пунктуации — возвращаем её из текста сегментов
  function parseOpenAI(resp) {
    var lang = normLang(resp.language);
    var rawWords = (resp.words || []).map(function (w) {
      return { w: String(w.word || w.text || '').trim(), s: +w.start, e: +w.end };
    }).filter(function (w) { return w.w; });
    var segs = resp.segments || [];
    var out = [];
    if (!segs.length) return { language: lang, words: fixTimes(rawWords) };
    var wi = 0;
    segs.forEach(function (sg) {
      var toks = String(sg.text || '').trim().split(/\s+/).filter(Boolean);
      if (!toks.length) return;
      var mine = [];
      while (wi < rawWords.length && (rawWords[wi].s + rawWords[wi].e) / 2 <= sg.end + 0.05) {
        if ((rawWords[wi].s + rawWords[wi].e) / 2 >= sg.start - 0.05) mine.push(rawWords[wi]);
        wi++;
      }
      if (mine.length === toks.length) {
        mine.forEach(function (w, i) { out.push({ w: toks[i], s: w.s, e: w.e }); });
      } else if (mine.length) {
        wordsFromText(toks.join(' '), mine[0].s, mine[mine.length - 1].e).forEach(function (w) { out.push(w); });
      } else {
        wordsFromText(toks.join(' '), sg.start, sg.end).forEach(function (w) { out.push(w); });
      }
    });
    return { language: lang, words: fixTimes(out) };
  }

  /* ------------------------------------------------------------------ экспорт */
  /* ------------------------------------------------------------------ смешанная речь (RU / KK / EN в одном ролике) */
  var TURKIC_NEIGHBORS = { tr: 1, uz: 1, ky: 1, tt: 1, ba: 1, az: 1, tk: 1, tg: 1, mn: 1, sah: 1 };
  var SLAVIC_NEIGHBORS = { uk: 1, be: 1, bg: 1, sr: 1, mk: 1, bs: 1, hr: 1, sl: 1, pl: 1, cs: 1, sk: 1 };

  // язык, который определил whisper, приводим к одному из разрешённых (казахский часто путают с турецким/узбекским/киргизским и т.п.)
  function mapLang(detected, allowed) {
    var d = normLang(detected);
    if (allowed.indexOf(d) >= 0) return d;
    if (TURKIC_NEIGHBORS[d] && allowed.indexOf('kk') >= 0) return 'kk';
    if (SLAVIC_NEIGHBORS[d] && allowed.indexOf('ru') >= 0) return 'ru';
    return allowed[0];
  }

  /* режем звук по паузам на куски min..max секунд: язык определяется отдельно для каждого куска.
     silences: [{s,e}] в секундах; возвращает [{s,d}] */
  function planChunks(total, silences, o) {
    o = o || {};
    var min = o.min > 0 ? o.min : 3, max = o.max > 0 ? o.max : 25, i, cuts = [], b, out = [], cur = 0, len, n, k;
    for (i = 0; i < silences.length; i++) {
      var m = (silences[i].s + silences[i].e) / 2;
      if (m > 0.2 && m < total - 0.2) cuts.push(m);
    }
    cuts.sort(function (a, c) { return a - c; });
    cuts.push(total);
    function emit(from, to) {
      len = to - from;
      n = Math.max(1, Math.ceil(len / max));
      for (k = 0; k < n; k++) out.push({ s: from + k * len / n, d: len / n });
    }
    for (i = 0; i < cuts.length; i++) {
      b = cuts[i];
      if (b - cur >= min || i === cuts.length - 1) {
        if (i === cuts.length - 1 && b - cur < min && out.length) {
          // короткий хвост приклеиваем к предыдущему куску, если помещается
          var last = out[out.length - 1];
          if (last.d + (b - cur) <= max + 3) { last.d = b - last.s; cur = b; continue; }
        }
        if (b - cur > 0.05) emit(cur, b);
        cur = b;
      }
    }
    return out;
  }

  /* Язык по буквам текста: whisper иногда путает русский с казахским (и наоборот), а иногда язык вообще не отдаёт.
     Казахские буквы: ә ғ қ ң ө ұ ү һ. Возвращает 'kk' | 'ru' | 'en' | '' (мало текста). */
  var KK_LETTERS = /[әғқңөұүһӘҒҚҢӨҰҮҺ]/g;
  function guessLang(text) {
    var t = String(text || ''), cyr = (t.match(/[\u0400-\u04FF]/g) || []).length, lat = (t.match(/[A-Za-z]/g) || []).length;
    if (cyr + lat < 8) return '';
    if (lat > cyr) return 'en';
    return (t.match(KK_LETTERS) || []).length / cyr > 0.012 ? 'kk' : 'ru';
  }
  // заявленный язык + проверка по тексту: кириллица без единой казахской буквы — это не казахский, и наоборот
  function fixLang(src, text) {
    var g = guessLang(text), s0 = normLang(src);
    if (!g) return s0;
    if (!s0) return g;
    if (s0 === 'kk' && g === 'ru') return 'ru';
    if (s0 === 'ru' && g === 'kk') return 'kk';
    return s0;
  }

  // подряд идущие слова одного языка (слова с полем l) → [{l, words}]
  function runsByLang(words) {
    var out = [], cur = null;
    words.forEach(function (w) {
      var l = w.l || '';
      if (!cur || cur.l !== l) { cur = { l: l, words: [] }; out.push(cur); }
      cur.words.push(w);
    });
    return out;
  }

  // доли языков по числу слов: [{l, n, pct}] по убыванию
  function langShares(words) {
    var c = {}, tot = 0, out = [];
    words.forEach(function (w) { if (w.l) { c[w.l] = (c[w.l] || 0) + 1; tot++; } });
    Object.keys(c).forEach(function (l) { out.push({ l: l, n: c[l], pct: Math.round(100 * c[l] / tot) }); });
    out.sort(function (a, b) { return b.n - a.n; });
    return out;
  }

  /* ------------------------------------------------------------------ версии */
  // сравнение версий «1.10.2» > «1.9.0»: 1, -1 или 0
  function cmpVer(a, b) {
    var x = String(a || '0').replace(/^v/i, '').split('.'), y = String(b || '0').replace(/^v/i, '').split('.'), i, n, m;
    for (i = 0; i < Math.max(x.length, y.length); i++) {
      n = parseInt(x[i], 10) || 0; m = parseInt(y[i], 10) || 0;
      if (n !== m) return n > m ? 1 : -1;
    }
    return 0;
  }

  return {
    LANGS: LANGS, MODES: MODES, DEF: DEF,
    normLang: normLang, langName: langName,
    fmtTime: fmtTime, fmtShort: fmtShort, parseShort: parseShort,
    toSRT: toSRT, parseSRT: parseSRT,
    stripPunct: stripPunct,
    wordsFromText: wordsFromText, wordsFromSegments: wordsFromSegments,
    segmentsFromWords: segmentsFromWords,
    groupWords: groupWords, toCaptions: toCaptions, makeCaptions: makeCaptions,
    wrapWords: wrapWords, dpGroup: dpGroup,
    parseWhisperCpp: parseWhisperCpp, parseOpenAI: parseOpenAI,
    isSentenceEnd: isSentenceEnd,
    mapLang: mapLang, guessLang: guessLang, fixLang: fixLang, planChunks: planChunks, runsByLang: runsByLang, langShares: langShares,
    cmpVer: cmpVer
  };
});
