/* SubLee — логика панели (CEP, Chromium + Node). */
(function () {
  'use strict';

  var Core = window.SFCore;
  var I18N = window.SFI18n || { tr: function (x) { return x; }, setLang: function () { return 'ru'; }, getLang: function () { return 'ru'; } };
  var cs = new window.CSInterface();
  /* одна панель работает и в After Effects, и в Premiere Pro */
  var HOST = (function () {
    try { var e = cs.getHostEnvironment ? cs.getHostEnvironment() : null; return e && /PPRO/i.test(String(e.appName || '')) ? 'PPRO' : 'AEFT'; } catch (e2) { return 'AEFT'; }
  })();
  var PPRO = HOST === 'PPRO';

  /* ------------------------------------------------------------------ Node */
  var nodeRequire = (typeof require === 'function') ? require : (window.cep_node && window.cep_node.require);
  var Engine = null, fs = null, pathMod = null, os = null, bootError = '';
  var EXT = '';
  try {
    EXT = cs.getSystemPath('extension');
    if (!nodeRequire) throw new Error('Node.js недоступен в панели (проверь manifest: --enable-nodejs)');
    fs = nodeRequire('fs'); pathMod = nodeRequire('path'); os = nodeRequire('os');
    try { var enginePath = nodeRequire.resolve(EXT + '/js/engine.js'); if (nodeRequire.cache) delete nodeRequire.cache[enginePath]; } catch (e) { /* не критично */ }   // свежий engine.js при каждом открытии панели
    Engine = nodeRequire(EXT + '/js/engine.js');
  } catch (e) { bootError = String(e && e.message || e); }

  /* ------------------------------------------------------------------ состояние */
  var STYLE_DEFAULT = {
    font: 'Montserrat-Bold', sizePct: 5, fill: '#ffffff', stroke: '#000000', strokeW: 6, useStroke: true,
    shadow: true, shadowOpacity: 60, shadowColor: '#000000', shadowBlur: 1, shadowDist: 1, uppercase: false, tracking: 0, lineHeight: 1.15,
    box: false, boxColor: '#000000', boxOpacity: 70, boxPadX: 0.45, boxPadY: 0.2, boxRound: 0.35
  };

  var LOOK_KEYS = ['fill', 'stroke', 'strokeW', 'useStroke', 'shadow', 'shadowOpacity', 'shadowColor', 'shadowBlur', 'shadowDist',
    'uppercase', 'tracking', 'lineHeight', 'box', 'boxColor', 'boxOpacity', 'boxPadX', 'boxPadY', 'boxRound'];

  var STYLE_PRESETS = [
    { id: 'classic', name: 'Классика', patch: { fill: '#ffffff', stroke: '#000000', strokeW: 6, useStroke: true, shadow: true } },
    { id: 'yellow', name: 'Жёлтый', patch: { fill: '#ffe600', stroke: '#000000', strokeW: 8, useStroke: true, shadow: true } },
    { id: 'box', name: 'Плашка', patch: { fill: '#ffffff', useStroke: false, shadow: false, box: true, boxColor: '#000000', boxOpacity: 75 } },
    { id: 'tiktok', name: 'Шорты', patch: { fill: '#ffffff', stroke: '#000000', strokeW: 12, useStroke: true, shadow: false, uppercase: true, sizePct: 6 } },
    { id: 'neon', name: 'Неон', patch: { fill: '#00f0ff', stroke: '#16004d', strokeW: 7, useStroke: true, shadow: true } },
    { id: 'soft', name: 'Мягкий', patch: { fill: '#ffffff', useStroke: false, shadow: true, shadowOpacity: 85 } },
    { id: 'outline', name: 'Контур', patch: { fill: '#ffffff', stroke: '#000000', strokeW: 10, useStroke: true, shadow: false } },
    { id: 'bigyellow', name: 'Крупный жёлтый', patch: { fill: '#ffd400', stroke: '#000000', strokeW: 14, useStroke: true, shadow: true, shadowOpacity: 80, shadowDist: 1.3, shadowBlur: 0.3, uppercase: true, sizePct: 6 } },
    { id: 'redline', name: 'Красный контур', patch: { fill: '#ffffff', stroke: '#e11d2e', strokeW: 10, useStroke: true, shadow: true } },
    { id: 'gold', name: 'Золото', patch: { fill: '#ffd76a', stroke: '#5a3b00', strokeW: 8, useStroke: true, shadow: true, shadowOpacity: 75 } },
    { id: 'darktext', name: 'Тёмный текст', patch: { fill: '#111111', stroke: '#ffffff', strokeW: 8, useStroke: true, shadow: false } },
    { id: 'sticker', name: 'Стикер', patch: { fill: '#ffffff', useStroke: false, shadow: true, shadowOpacity: 55, shadowDist: 1.2, shadowBlur: 0.5, box: true, boxColor: '#ec4899', boxOpacity: 100, boxPadX: 0.55, boxPadY: 0.25, boxRound: 0.5 } },
    { id: 'violet', name: 'Фиолетовая', patch: { fill: '#ffffff', useStroke: false, shadow: false, box: true, boxColor: '#6d5df5', boxOpacity: 100, boxPadX: 0.55, boxPadY: 0.25, boxRound: 0.5 } },
    { id: 'marker', name: 'Маркер', patch: { fill: '#111111', useStroke: false, shadow: false, box: true, boxColor: '#ffe14d', boxOpacity: 100, boxPadX: 0.3, boxPadY: 0.1, boxRound: 0.08 } },
    { id: 'podcast', name: 'Подкаст', patch: { fill: '#14141a', useStroke: false, shadow: true, shadowOpacity: 35, shadowDist: 0.8, shadowBlur: 1.5, box: true, boxColor: '#ffffff', boxOpacity: 96, boxPadX: 0.6, boxPadY: 0.28, boxRound: 0.35 } },
    { id: 'onair', name: 'Эфир', patch: { fill: '#ffffff', useStroke: false, shadow: false, box: true, boxColor: '#e11d48', boxOpacity: 95, boxPadX: 0.5, boxPadY: 0.2, boxRound: 0.05 } },
    { id: 'glass', name: 'Стекло', patch: { fill: '#ffffff', useStroke: false, shadow: true, shadowOpacity: 45, shadowDist: 0.6, shadowBlur: 1.2, box: true, boxColor: '#ffffff', boxOpacity: 25, boxPadX: 0.6, boxPadY: 0.25, boxRound: 0.5 } },
    { id: 'retro', name: 'Ретро тень', patch: { fill: '#ffe600', useStroke: false, shadow: true, shadowColor: '#7a3b00', shadowOpacity: 100, shadowDist: 2.4, shadowBlur: 0, uppercase: true } },
    { id: 'extrude', name: '3D', patch: { fill: '#ffffff', stroke: '#000000', strokeW: 6, useStroke: true, shadow: true, shadowOpacity: 100, shadowDist: 1.8, shadowBlur: 0, uppercase: true } },
    { id: 'glow', name: 'Свечение', patch: { fill: '#ffffff', useStroke: false, shadow: true, shadowColor: '#8a6bff', shadowOpacity: 100, shadowDist: 0, shadowBlur: 2 } },
    { id: 'greenglow', name: 'Зелёное свечение', patch: { fill: '#3dff8a', useStroke: false, shadow: true, shadowColor: '#00ff66', shadowOpacity: 100, shadowDist: 0, shadowBlur: 2, uppercase: true } },
    { id: 'pinkneon', name: 'Розовый неон', patch: { fill: '#ffd1f3', useStroke: false, shadow: true, shadowColor: '#ff00c8', shadowOpacity: 100, shadowDist: 0, shadowBlur: 2.4 } },
    { id: 'cinema', name: 'Кино', patch: { fill: '#ffffff', useStroke: false, shadow: true, shadowOpacity: 70, shadowDist: 0.6, shadowBlur: 1.2, uppercase: true, tracking: 150, sizePct: 4 } }
  ];

  var ANIM_PRESETS = [
    { id: 'none', name: 'Нет', ico: '\u2014' },
    { id: 'fade', name: 'Плавно', ico: '\u25D0' },
    { id: 'pop', name: 'Поп', ico: '\u2B24' },
    { id: 'bounce', name: 'Пружина', ico: '\u2933' },
    { id: 'slide', name: 'Подъём', ico: '\u2191' },
    { id: 'type', name: 'Печать', ico: 'A|' },
    { id: 'stomp', name: 'Удар', ico: '\u25A3' },
    { id: 'drop', name: 'Падение', ico: '\u2193' },
    { id: 'zoom', name: 'Наезд', ico: '\u2922' },
    { id: 'spin', name: 'Поворот', ico: '\u21BB' },
    { id: 'blur', name: 'Из размытия', ico: '\u25CC' },
    { id: 'letters', name: 'По буквам', ico: 'Aa' },
    { id: 'tracking', name: 'Разъезд', ico: '\u2194' },
    { id: 'wiggle', name: 'Дрожь', ico: '\u2248' },
    { id: 'flicker', name: 'Мерцание', ico: '\u25CD' }
  ];

  var MODES = [
    { id: 'one', title: 'Одно слово', sub: 'По слову, как в шортсах', icon: 'one-word', bars: [10] },
    { id: 'two', title: 'Два слова', sub: 'Пара слов за раз', icon: 'two-words', bars: [10, 10] },
    { id: 'smartShort', title: 'Короткие фразы', sub: '2–4 слова, по смыслу', icon: 'smart-short', bars: [8, 5, 8] },
    { id: 'smartLong', title: 'Длинные фразы', sub: 'До 12 слов, две строки', icon: 'smart-long', bars: [16, 12] },
    { id: 'sentences', title: 'Предложения', sub: 'Целые предложения', icon: 'sentences', bars: [18, 18, 12] }
  ];

  var DEFAULT_CFG = {
    engine: 'local', ffmpegPath: '', whisperPath: '', modelPath: '', threads: 0, wordTiming: 'precise',
    openaiKey: '', openaiBase: 'https://api.openai.com/v1', openaiSttModel: 'whisper-1',
    trProvider: 'anthropic', anthropicKey: '', anthropicBase: 'https://api.anthropic.com',
    anthropicModel: 'claude-sonnet-5-5', openaiChatModel: 'gpt-4o-mini',
    ui: {
      layerMode: 'multi', precomp: false, review: true, speech: 'auto', langs: ['ru'], pos: 'below', yPct: 0,
      replace: true, noPunct: false, vis: { ru: true, en: true, kk: true },
      custom: { words: 5, lines: 2, chars: 0, safe: 8 },
      theme: 'cobalt', uiLang: 'ru', motion: true, autoScale: true, seenVersion: '', updateUrl: '', updateAuto: true, lastMode: 'smartShort',
      style: STYLE_DEFAULT, stylePreset: 'classic', customStyles: [], customStyleSel: '',
      anim: { preset: 'fade', frames: 6, power: 100, out: false, auto: false },
      fx: { mode: 'both', scope: 'auto', inF: 12, outF: 10, power: 100, cat: 'all', last: '' },
      pp: { tpl: '', out: 'mogrt' }, mogrt: { name: '', size: 'comp', anim: 'none' },
      bounce: { props: ['scale'], type: 'overshoot', amp: 6, freq: 3, decay: 6, elast: 70, auto: false }, customAnims: [], customAnimSel: '',
      open: { lang: true }
    }
  };

  var S = { cfg: null, fonts: [], audioFile: '', busy: false, cache: {}, trCache: {}, lastCtx: null };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function merge(base, extra) {
    if (!extra || typeof extra !== 'object') return base;
    Object.keys(extra).forEach(function (k) {
      if (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k]) && typeof extra[k] === 'object' && !Array.isArray(extra[k])) merge(base[k], extra[k]);
      else base[k] = extra[k];
    });
    return base;
  }

  /* ------------------------------------------------------------------ настройки на диске */
  function settingsFile() { return os ? pathMod.join(os.homedir(), '.subflow', 'settings.json') : ''; }
  var KEY_FIELDS = ['openaiKey', 'anthropicKey'];
  function canCrypt() { return !!(fs && Engine && Engine.encryptSecret && Engine.decryptSecret); }
  function loadCfg() {
    var cfg = clone(DEFAULT_CFG), saved = null, lost = false, migrate = false;
    try {
      if (fs && fs.existsSync(settingsFile())) saved = JSON.parse(fs.readFileSync(settingsFile(), 'utf8'));
      else if (window.localStorage.getItem('subflow')) saved = JSON.parse(window.localStorage.getItem('subflow'));
    } catch (e) { saved = null; }
    if (saved && canCrypt()) {
      KEY_FIELDS.forEach(function (k) {
        if (!saved[k]) return;
        var r = Engine.decryptSecret(saved[k]);
        if (!r.ok) lost = true;
        if (r.plain) migrate = true;      // старый файл с открытым ключом → пересохраним зашифрованным
        saved[k] = r.value;
      });
    }
    S.cfg = merge(cfg, saved);
    S.keysLost = lost;
    if (migrate) saveCfg();
  }
  var saveTimer = null;
  function saveCfg() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      var crypt = canCrypt(), disk = clone(S.cfg), mem = clone(S.cfg);
      if (crypt) {
        KEY_FIELDS.forEach(function (k) {
          mem[k] = '';                                           // в localStorage ключей нет
          try { disk[k] = Engine.encryptSecret(S.cfg[k]); } catch (e) { disk[k] = ''; }
        });
      }
      try { window.localStorage.setItem('subflow', JSON.stringify(mem, null, 2)); } catch (e) { /* ignore */ }
      try {
        if (fs) {
          fs.mkdirSync(pathMod.dirname(settingsFile()), { recursive: true });
          fs.writeFileSync(settingsFile(), JSON.stringify(disk, null, 2), { encoding: 'utf8', mode: 384 });
          try { fs.chmodSync(settingsFile(), 384); } catch (e) { /* Windows */ }
        }
      } catch (e) { /* ignore */ }
    }, 250);
  }

  /* ------------------------------------------------------------------ DOM */
  function $(id) { return document.getElementById(id); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function h(tag, attrs, kids) {
    var el = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'class') el.className = attrs[k];
      else if (k === 'text') el.textContent = attrs[k];
      else if (k === 'html') el.innerHTML = attrs[k];
      else if (k.indexOf('on') === 0) el.addEventListener(k.slice(2), attrs[k]);
      else el.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c) el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return el;
  }

  var statusEls = { create: 'status', styles: 'statusStyles', anim: 'statusAnim', fx: 'statusFx', mg: 'statusMogrt' };
  function setStatus(kind, msg, where) {
    var el = $(statusEls[where || 'create']);
    el.className = 'status ' + (kind || '');
    el.textContent = (kind === 'ok' ? '✓ ' : (kind === 'err' ? '✗ ' : '')) + msg;
  }
  function setProgress(p) {
    var bar = $('bar');
    if (p === null || p === undefined) { bar.classList.add('indet'); return; }
    bar.classList.remove('indet');
    bar.style.setProperty('--p', Math.max(0, Math.min(100, p)) + '%');
  }
  function setBusy(on) {
    S.busy = on;
    $('progress').classList.toggle('on', on);
    $$('.mode, #btnCustom, #btnImport, #btnHero').forEach(function (b) { b.disabled = on; });
    if (on) setProgress(null);
  }

  /* ------------------------------------------------------------------ AE host */
  var HOST_ERRORS = {
    E_NO_COMP: 'Открой композицию (кликни по ней в Timeline) и попробуй снова.',
    E_PP_NO_SEQUENCE: 'Открой последовательность в Premiere Pro (двойной клик по ней в панели Project) и попробуй снова.',
    E_PP_NO_FREE_TRACK: 'Над клипом нет свободной видеодорожки: добавь пустую дорожку V (правый клик по дорожке → «Добавить дорожку»).',
    E_PP_NO_TEXT_PARAM: 'В шаблоне .mogrt нет текстового параметра. Сделай шаблон заново в панели SubLee в After Effects.',
    E_PP_NO_MGT: 'Premiere не открыл параметры шаблона .mogrt. Проверь, что шаблон сделан в After Effects той же или более старой версии.',
    E_PP_NO_MOGRT: 'Не выбран шаблон .mogrt.',
    E_PP_IMPORT: 'Premiere не смог вставить шаблон .mogrt на таймлайн.'
  };
  var NAME_APP = PPRO ? 'Premiere Pro' : 'After Effects';
  var MSG_NO_ANSWER = PPRO ? 'Скрипт SubLee в Premiere Pro не отвечает. Перезапусти Premiere и открой панель заново.' : 'Скрипт SubLee в After Effects не отвечает. Перезапусти AE и открой панель заново.';
  var MSG_BAD_ANSWER = PPRO ? 'Непонятный ответ Premiere Pro: ' : 'Непонятный ответ After Effects: ';
  var MSG_NO_LINK = PPRO ? 'Нет связи с Premiere Pro: ' : 'Нет связи с After Effects: ';
  function host(name, payload) {
    return new Promise(function (resolve, reject) {
      var arg = payload === undefined ? '' : JSON.stringify(payload);
      var script = 'sf_call(' + JSON.stringify(name) + ',' + JSON.stringify(arg) + ')';
      script = script.split(String.fromCharCode(0x2028)).join('\\u2028').split(String.fromCharCode(0x2029)).join('\\u2029');
      try {
        cs.evalScript(script, function (res) {
          if (res === 'EvalScript error.' || res === undefined || res === null || res === '')
            return reject(new Error(MSG_NO_ANSWER));
          var r;
          try { r = JSON.parse(res); } catch (e) { return reject(new Error(MSG_BAD_ANSWER + String(res).slice(0, 200))); }
          if (!r.ok) {
            var code = String(r.error || '').split(' ')[0];
            return reject(new Error(HOST_ERRORS[code] || (NAME_APP + ': ' + r.error + (r.line ? ' (' + I18N.tr('строка') + ' ' + r.line + ')' : ''))));
          }
          resolve(r);
        });
      } catch (e) { reject(new Error(MSG_NO_LINK + e.message)); }
    });
  }

  /* ------------------------------------------------------------------ вкладки / акк / seg / chips */
  function initTabs() {
    $$('.tab-btn').forEach(function (b) {
      b.addEventListener('click', function () {
        $$('.tab-btn').forEach(function (x) { x.classList.toggle('active', x === b); });
        $$('.tab').forEach(function (t) { t.classList.toggle('active', t.id === 'tab-' + b.dataset.tab); });
      });
    });
  }
  function initAcc() {
    $$('.acc').forEach(function (a) {
      a.querySelector('.acc-head').addEventListener('click', function (e) {
        if (e.target.classList.contains('x')) return;
        a.classList.toggle('open');
        if (a.id === 'accLang') { S.cfg.ui.open.lang = a.classList.contains('open'); saveCfg(); }
      });
    });
    $('accLang').classList.toggle('open', S.cfg.ui.open.lang !== false);
  }
  function setSeg(el, value) { $$('button', el).forEach(function (b) { b.classList.toggle('on', b.dataset.v === value); }); }
  function bindSeg(el, get, set) {
    setSeg(el, get());
    $$('button', el).forEach(function (b) { b.addEventListener('click', function () { set(b.dataset.v); setSeg(el, get()); saveCfg(); }); });
  }

  /* ------------------------------------------------------------------ шрифты */
  function fontLabel(ps) {
    var f = S.fonts.filter(function (x) { return x.ps === ps; })[0];
    return f ? f.fam + ' — ' + f.sty : ps;
  }
  function renderFontList() {
    var q = $('fontSearch').value.trim().toLowerCase(), list = $('fontList');
    list.innerHTML = '';
    var cur = S.cfg.ui.style.font;
    if (!S.fonts.length) {
      list.appendChild(h('div', { text: 'Список шрифтов недоступен (нужен AE 2023+). Впиши PostScript-имя в поле выше и нажми Enter.' }));
      return;
    }
    var shown = 0;
    S.fonts.forEach(function (f) {
      if (shown >= 150) return;
      if (q && (f.fam + ' ' + f.sty + ' ' + f.ps).toLowerCase().indexOf(q) < 0) return;
      shown++;
      var row = h('div', { class: f.ps === cur ? 'on' : '' }, [h('span', { text: f.fam }), h('small', { text: f.sty })]);
      row.addEventListener('click', function () { pickFont(f.ps); });
      list.appendChild(row);
    });
  }
  function fontNoteText(note) {   // «Wanted -> Used» от host.jsx: выбранного шрифта нет в системе
    var m = /^(.+) -> (.+)$/.exec(note || '');
    return m ? '\nШрифт ' + m[1] + ' не установлен, использован ' + m[2] : '';
  }
  function paintFontQuick() {
    $$('#fontQuick button').forEach(function (b) { b.classList.toggle('on', b.dataset.f === S.cfg.ui.style.font); });
  }
  function pickFont(ps) {
    S.cfg.ui.style.font = ps;
    $('fontVal').textContent = fontLabel(ps);
    paintFontQuick(); renderFontList(); saveCfg();
  }
  function updateFontHint() {
    $('fontHint').textContent = (S.cfg.ui.langs.indexOf('kk') >= 0 || S.cfg.ui.langs.indexOf('orig') >= 0)
      ? 'Для казахского нужен шрифт с буквами ә ғ қ ң ө ұ ү һ і. Если видишь квадраты — смени шрифт (Arial, Segoe UI, Roboto).' : '';
    $('fontHint').className = 'hint warn';
  }
  function initFont() {
    $('fontVal').textContent = fontLabel(S.cfg.ui.style.font);
    $$('#fontQuick button').forEach(function (b) { b.addEventListener('click', function () { pickFont(b.dataset.f); }); });
    paintFontQuick();
    $('fontSearch').addEventListener('input', renderFontList);
    $('fontSearch').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && this.value.trim()) { pickFont(this.value.trim()); this.value = ''; renderFontList(); }
    });
    $('fontReset').addEventListener('click', function () { pickFont(STYLE_DEFAULT.font); });
    renderFontList(); updateFontHint();
    host('listFonts').then(function (r) {
      S.fonts = r.fonts.sort(function (a, b) { return (a.fam + a.sty).localeCompare(b.fam + b.sty); });
      $('fontVal').textContent = fontLabel(S.cfg.ui.style.font);
      renderFontList();
    }).catch(function () { /* AE ещё не готов — не критично */ });
  }

  /* ------------------------------------------------------------------ языки */
  function langTag(l) { return l === 'orig' ? 'Как сказано' : l.toUpperCase(); }
  function speechTag(v) { return v === 'auto' ? 'Авто' : (v === 'multi' ? 'Смешанная' : v.toUpperCase()); }
  function updateLangUI() {
    var u = S.cfg.ui;
    var sp = speechTag(u.speech);
    if ($('heroSub') && S.cfg.ui.lastMode !== undefined) { try { paintHero(); } catch (e) { /* modes not ready */ } }
    $('langVal').textContent = sp + ' → ' + (u.langs.map(langTag).join(' + ') || '—');
    var needTr = u.langs.some(function (l) { return l !== 'orig' && (u.speech === 'auto' || u.speech === 'multi' || l !== u.speech); });
    $('langHint').textContent = (u.speech === 'multi'
      ? 'Смешанная речь: звук режется по паузам, язык определяется для каждой фразы (RU / KK / EN). «Как сказано» оставляет фразы на своём языке, остальные языки — перевод через API. Переключение внутри одной фразы не ловится; лучше всего работают модели small и больше.\n'
      : '') + (needTr
      ? 'Если язык субтитров отличается от языка речи, текст переводится через API (ключ в «Настройках»). Совпадающий язык берётся прямо из распознавания.'
      : '');
    updateFontHint();
  }
  function initLang() {
    var u = S.cfg.ui;
    bindSeg($('segSpeech'), function () { return u.speech; }, function (v) { u.speech = v; updateLangUI(); });
    var chips = $('chipLangs');
    function paint() { $$('button', chips).forEach(function (b) { b.classList.toggle('on', u.langs.indexOf(b.dataset.v) >= 0); }); updateLangUI(); }
    $$('button', chips).forEach(function (b) {
      b.addEventListener('click', function () {
        var i = u.langs.indexOf(b.dataset.v);
        if (i >= 0) { if (u.langs.length > 1) u.langs.splice(i, 1); } else u.langs.push(b.dataset.v);
        var order = ['ru', 'en', 'kk', 'orig'];
        u.langs.sort(function (a, b2) { return order.indexOf(a) - order.indexOf(b2); });
        paint(); saveCfg();
      });
    });
    paint();
  }

  /* ------------------------------------------------------------------ верх: переключатели */
  function initToggles() {
    var u = S.cfg.ui, sw = $('swLayers');
    function paint() {
      var single = u.layerMode === 'single';
      sw.setAttribute('aria-checked', single ? 'true' : 'false');
      $('lblMulti').classList.toggle('on', !single);
      $('lblSingle').classList.toggle('on', single);
    }
    sw.addEventListener('click', function () { u.layerMode = u.layerMode === 'single' ? 'multi' : 'single'; paint(); saveCfg(); });
    paint();
    [['chkPrecomp', 'precomp'], ['chkReview', 'review'], ['chkReplace', 'replace'], ['chkNoPunct', 'noPunct']].forEach(function (p) {
      var el = $(p[0]); el.checked = !!u[p[1]];
      el.addEventListener('change', function () { u[p[1]] = el.checked; saveCfg(); });
    });
    bindSeg($('segPos'), function () { return u.pos; }, function (v) { u.pos = v; });
    var inpY = $('inpY'); inpY.value = u.yPct > 0 ? u.yPct : '';
    inpY.addEventListener('change', function () { u.yPct = parseFloat(inpY.value) || 0; saveCfg(); });
    ['cuWords:words', 'cuLines:lines', 'cuChars:chars', 'cuSafe:safe'].forEach(function (p) {
      var id = p.split(':')[0], k = p.split(':')[1], el = $(id);
      el.value = u.custom[k];
      el.addEventListener('change', function () { u.custom[k] = parseFloat(el.value) || 0; saveCfg(); });
    });
    // видимость языков в композиции
    var vis = $('chipVis');
    $$('button', vis).forEach(function (b) {
      b.classList.toggle('on', u.vis[b.dataset.v] !== false);
      b.addEventListener('click', function () {
        var on = !b.classList.contains('on');
        b.classList.toggle('on', on); u.vis[b.dataset.v] = on; saveCfg();
        host('toggleLang', { lang: b.dataset.v, visible: on }).then(function (r) {
          setStatus('ok', (on ? 'Показан' : 'Скрыт') + ' язык ' + b.dataset.v.toUpperCase() + ' (' + r.count + ' слоёв)');
        }).catch(function (e) { setStatus('err', e.message); });
      });
    });
    // источник звука
    $('btnPickAudio').addEventListener('click', function () {
      openDialog('Выбери видео или аудио', ['mp3', 'wav', 'm4a', 'mp4', 'mov', 'avi', 'mkv', 'webm', 'aac', 'flac', 'ogg']).then(function (p) {
        if (!p) return;
        S.audioFile = p; $('audioName').textContent = pathMod ? pathMod.basename(p) : p; $('audioClear').style.display = '';
      });
    });
    $('audioClear').addEventListener('click', function () {
      S.audioFile = ''; $('audioName').textContent = 'выделенный слой в композиции'; $('audioClear').style.display = 'none';
    });
  }

  /* ------------------------------------------------------------------ диалоги файлов */
  function openDialog(title, exts) {
    return new Promise(function (resolve) {
      try {
        var r = window.cep.fs.showOpenDialogEx(false, false, I18N.tr(title), '', exts || [], '', '');
        resolve(r && r.data && r.data.length ? r.data[0] : '');
      } catch (e) { setStatus('err', 'Диалог выбора файла недоступен: ' + e.message); resolve(''); }
    });
  }
  function saveDialog(title, defName, exts) {
    return new Promise(function (resolve) {
      try {
        var r = window.cep.fs.showSaveDialogEx(I18N.tr(title), '', exts || [], defName, '', '');
        resolve(r && r.data ? r.data : '');
      } catch (e) { setStatus('err', 'Диалог сохранения недоступен: ' + e.message); resolve(''); }
    });
  }

  /* ------------------------------------------------------------------ режимы (карточки) */
  function iconSvg(bars) {
    var y = 6, out = '';
    bars.forEach(function (w) {
      out += '<rect x="' + (16 - w) + '" y="' + y + '" width="' + (w * 2) + '" height="3.4" rx="1.7" fill="#c8d2ff"/>';
      y += 6.4;
    });
    return '<svg width="26" height="26" viewBox="0 0 32 32">' + out + '</svg>';
  }
  function modeById(id) { var i; for (i = 0; i < MODES.length; i++) if (MODES[i].id === id) return MODES[i]; return MODES[2]; }
  function paintHero() {
    var u = S.cfg.ui, m = modeById(u.lastMode);
    var langs = u.langs.map(langTag).join(' + ');
    $('heroSub').textContent = m.title + ' \u00B7 ' + langs;
    var hi = $('heroIco');
    if (hi) { var img = hi.firstChild; if (!img || img.nodeName !== 'IMG') { hi.textContent = ''; img = h('img', { alt: '', draggable: 'false' }); hi.appendChild(img); } img.setAttribute('src', 'img/' + m.icon + '.png'); }
    $$('.mode').forEach(function (b) { b.classList.toggle('last', b.getAttribute('data-mode') === m.id); });
  }
  function initModes() {
    var box = $('modes');
    MODES.forEach(function (m) {
      var b = h('button', { class: 'mode', 'data-mode': m.id, title: m.title + ' \u2014 ' + m.sub }, [
        h('span', { class: 'mi' }, [h('img', { src: 'img/' + m.icon + '.png', alt: '', draggable: 'false' })]),
        h('span', { class: 'mtx' }, [h('div', { class: 'mt', text: m.title }), h('div', { class: 'ms', text: m.sub })])
      ]);
      b.addEventListener('click', function () { S.cfg.ui.lastMode = m.id; paintHero(); saveCfg(); runMode(m.id); });
      box.appendChild(b);
    });
    $('btnHero').addEventListener('click', function () { runMode(S.cfg.ui.lastMode || 'smartShort'); });
    $('btnCustom').addEventListener('click', function () { runMode('custom'); });
    paintHero();
  }

  /* ------------------------------------------------------------------ стили */
  function hexA(hex, a) {
    hex = String(hex || '#000000').replace('#', '');
    if (hex.length === 3) hex = hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
    return 'rgba(' + parseInt(hex.substr(0, 2), 16) + ',' + parseInt(hex.substr(2, 2), 16) + ',' + parseInt(hex.substr(4, 2), 16) + ',' + a + ')';
  }
  function styleSample(st) {
    var css = 'color:' + st.fill + ';';
    if (st.useStroke) css += '-webkit-text-stroke:' + Math.max(1, st.strokeW / 6) + 'px ' + st.stroke + ';paint-order:stroke fill;';
    if (st.shadow) {
      var sd = st.shadowDist === undefined ? 1 : st.shadowDist, sb = st.shadowBlur === undefined ? 1 : st.shadowBlur;
      var col = hexA(st.shadowColor || '#000000', (st.shadowOpacity > 0 ? st.shadowOpacity : 60) / 100), d = Math.round(sd * 2), b = Math.round(sb * 5);
      css += sd === 0 ? 'text-shadow:0 0 ' + b + 'px ' + col + ',0 0 ' + (b * 2) + 'px ' + col + ';' : 'text-shadow:' + d + 'px ' + d + 'px ' + b + 'px ' + col + ';';
    }
    if (st.box) {
      var rd = st.boxRound >= 0 ? st.boxRound : 0.35;
      css += 'background:' + hexA(st.boxColor, (st.boxOpacity > 0 ? st.boxOpacity : 70) / 100) + ';padding:2px ' + Math.round(6 + 10 * (st.boxPadX || 0.45)) + 'px;border-radius:' + Math.round(3 + rd * 12) + 'px;';
    }
    return css;
  }
  /* образец текста из отдельных букв (нужно для анимаций «по буквам» и «печать») */
  function sampleSpan(txt, attrs) {
    var kids = txt.split('').map(function (ch, i) { return h('i', { text: ch, style: '--i:' + i }); });
    return h('span', attrs, kids);
  }
  /* у каждого встроенного стиля своя «фирменная» анимация в плитке; на пользовательских — мягкое появление */
  var STYLE_FX = { classic: 'fade', yellow: 'pop', box: 'slide', tiktok: 'stomp', neon: 'flicker', soft: 'fade', outline: 'zoom',
    bigyellow: 'stomp', redline: 'pop', gold: 'pulse', darktext: 'blur', sticker: 'letters', violet: 'bounce', marker: 'wipe',
    podcast: 'slide', onair: 'drop', glass: 'blur', retro: 'stomp', extrude: 'drop', glow: 'pulse', greenglow: 'flicker',
    pinkneon: 'flicker', cinema: 'tracking' };
  var pvSeq = 0;
  function pvPhase() { pvSeq++; return '--d:-' + (((pvSeq * 0.37) % 2.2)).toFixed(2) + 's'; }   // плитки играют не синхронно
  function stylePreview(st, fx) {
    // при наведении образец проигрывает анимацию, выбранную на вкладке «Анимация» (data-a подставляется в mouseover)
    var sp = sampleSpan(st.uppercase ? 'ABC' : 'Abc', { class: 'pvs', 'data-follow': '1', 'data-a': fx || 'fade', style: styleSample(st) });
    return h('div', { class: 'pv', style: pvPhase() }, [h('span', { class: 'pvw' }, [sp])]);
  }
  function animPreview(id) {
    return h('div', { class: 'pv', style: pvPhase() }, [h('span', { class: 'pvw' }, [sampleSpan('Abc', { class: 'pvs', 'data-a': id })])]);
  }
  function applyBuiltinStyle(p) {
    var u = S.cfg.ui, ns = Object.assign({}, u.style);
    LOOK_KEYS.forEach(function (k) { ns[k] = STYLE_DEFAULT[k]; });
    Object.keys(p.patch).forEach(function (k) { ns[k] = p.patch[k]; });
    u.style = ns; u.stylePreset = p.id;
  }
  function renderStylePresets() {
    var box = $('stylePresets'); box.innerHTML = '';
    STYLE_PRESETS.forEach(function (p) {
      var st = Object.assign({}, STYLE_DEFAULT, p.patch);
      var el = h('button', { class: 'preset' + (S.cfg.ui.stylePreset === p.id ? ' on' : ''), title: p.name }, [stylePreview(st, STYLE_FX[p.id]), h('div', { class: 'pn', text: p.name })]);
      el.addEventListener('click', function () { applyBuiltinStyle(p); fillStyleControls(); renderStylePresets(); saveCfg(); });
      box.appendChild(el);
    });
  }
  var STYLE_BINDS = [
    ['stSize', 'sizePct', 'num', 'vSize', function (v) { return v + '%'; }],
    ['stFill', 'fill', 'str'], ['stStroke', 'stroke', 'str'],
    ['stUseStroke', 'useStroke', 'bool'], ['stStrokeW', 'strokeW', 'num', 'vStrokeW', function (v) { return v; }],
    ['stShadow', 'shadow', 'bool'], ['stShadowColor', 'shadowColor', 'str'],
    ['stShadowOpacity', 'shadowOpacity', 'num', 'vShadowOp', function (v) { return v + '%'; }],
    ['stShadowBlur', 'shadowBlur', 'num', 'vShadowBlur', function (v) { return v; }],
    ['stShadowDist', 'shadowDist', 'num', 'vShadowDist', function (v) { return v; }],
    ['stUpper', 'uppercase', 'bool'],
    ['stTracking', 'tracking', 'num', 'vTracking', function (v) { return v; }],
    ['stLH', 'lineHeight', 'num', 'vLH', function (v) { return v; }],
    ['stBox', 'box', 'bool'], ['stBoxColor', 'boxColor', 'str'],
    ['stBoxOpacity', 'boxOpacity', 'num', 'vBoxOp', function (v) { return v + '%'; }],
    ['stBoxPadX', 'boxPadX', 'num', 'vBoxPadX', function (v) { return v; }],
    ['stBoxPadY', 'boxPadY', 'num', 'vBoxPadY', function (v) { return v; }],
    ['stBoxRound', 'boxRound', 'num', 'vBoxRound', function (v) { return v; }]
  ];
  function toggleStyleRows() {
    var st = S.cfg.ui.style;
    $('rowStrokeW').style.display = st.useStroke ? '' : 'none';
    $('boxOpts').style.display = st.box ? '' : 'none';
    $('shadowOpts').style.display = st.shadow ? '' : 'none';
  }
  function fillStyleControls() {
    var st = S.cfg.ui.style;
    STYLE_BINDS.forEach(function (b) {
      var el = $(b[0]), v = st[b[1]];
      if (v === undefined) v = STYLE_DEFAULT[b[1]];
      if (b[2] === 'bool') el.checked = !!v; else el.value = v;
      if (b[3]) $(b[3]).textContent = b[4](v);
    });
    toggleStyleRows();
    syncQuickSize();
  }
  /* быстрый ползунок размера на главной вкладке (то же значение, что «Размер» на вкладке «Стили») */
  function syncQuickSize() {
    var q = $('qSize'); if (!q) return;
    var v = S.cfg.ui.style.sizePct; if (v === undefined) v = STYLE_DEFAULT.sizePct;
    q.value = v; $('vQSize').textContent = v + '%';
  }
  function initQuickSize() {
    var q = $('qSize');
    q.addEventListener('input', function () {
      var v = parseFloat(q.value);
      S.cfg.ui.style.sizePct = v; S.cfg.ui.stylePreset = '';
      $('stSize').value = v; $('vSize').textContent = v + '%';
      $('vQSize').textContent = v + '%';
      renderStylePresets(); saveCfg();
    });
    function go(sel) {
      setStatus('busy', 'Меняю размер…');
      host('applySize', { style: S.cfg.ui.style, selectedOnly: sel }).then(function (r) {
        setStatus(r.count ? 'ok' : '', r.count ? 'Размер текста изменён у ' + r.count + ' слоёв' : 'Нет слоёв SubLee в этой композиции');
      }).catch(function (e) { setStatus('err', e.message); });
    }
    $('btnSizeSel').addEventListener('click', function () { go(true); });
    $('btnSizeAll').addEventListener('click', function () { go(false); });
    syncQuickSize();
  }

  /* пользовательские пресеты (стили и анимации): сохранить / обновить / удалить */
  function setupUserPresets(o) {
    var ui = function () { return S.cfg.ui; };
    var delTimer = null;
    function list() { return ui()[o.listKey]; }
    function sel() { var id = ui()[o.selKey], i; for (i = 0; i < list().length; i++) if (list()[i].id === id) return list()[i]; return null; }
    function render() {
      var box = $(o.grid); box.innerHTML = '';
      box.setAttribute('data-empty', o.emptyText);
      list().forEach(function (it) {
        var el = h('button', { class: 'preset' + (ui()[o.selKey] === it.id ? ' on' : ''), title: it.name }, [o.tile(it.data), h('div', { class: 'pn', text: it.name })]);
        el.addEventListener('click', function () {
          ui()[o.selKey] = it.id; $(o.name).value = it.name; o.apply(it.data); render(); saveCfg();
        });
        box.appendChild(el);
      });
    }
    function newId() { return 'u' + Date.now().toString(36) + Math.floor(Math.random() * 1296).toString(36); }
    function nameOr(def) { var n = $(o.name).value.replace(/^\s+|\s+$/g, ''); return n || def; }
    $(o.add).addEventListener('click', function () {
      var it = { id: newId(), name: nameOr(o.defName + ' ' + (list().length + 1)), data: o.snapshot() };
      list().push(it); ui()[o.selKey] = it.id; $(o.name).value = it.name; render(); saveCfg();
      setStatus('ok', 'Сохранено: ' + it.name, o.statusTab);
    });
    $(o.upd).addEventListener('click', function () {
      var it = sel();
      if (!it) { setStatus('err', o.pickFirst, o.statusTab); return; }
      it.data = o.snapshot(); it.name = nameOr(it.name); $(o.name).value = it.name; render(); saveCfg();
      setStatus('ok', 'Обновлено: ' + it.name, o.statusTab);
    });
    $(o.del).addEventListener('click', function () {
      var it = sel(), btn = $(o.del);
      if (!it) { setStatus('err', o.pickFirst, o.statusTab); return; }
      if (!btn.getAttribute('data-arm')) {
        btn.setAttribute('data-arm', '1'); btn.textContent = 'Точно?';
        clearTimeout(delTimer);
        delTimer = setTimeout(function () { btn.removeAttribute('data-arm'); btn.textContent = 'Удалить'; }, 3000);
        return;
      }
      clearTimeout(delTimer); btn.removeAttribute('data-arm'); btn.textContent = 'Удалить';
      ui()[o.listKey] = list().filter(function (x) { return x !== it; });
      ui()[o.selKey] = ''; $(o.name).value = ''; render(); saveCfg();
      setStatus('ok', 'Удалено: ' + it.name, o.statusTab);
    });
    var cur = sel(); if (cur) $(o.name).value = cur.name;
    render();
    return { render: render };
  }

  function initStyles() {
    STYLE_BINDS.forEach(function (b) {
      var el = $(b[0]);
      el.addEventListener('input', function () {
        var v = b[2] === 'bool' ? el.checked : (b[2] === 'num' ? parseFloat(el.value) : el.value);
        S.cfg.ui.style[b[1]] = v; S.cfg.ui.stylePreset = '';
        if (b[3]) $(b[3]).textContent = b[4](v);
        toggleStyleRows();
        syncQuickSize();
        renderStylePresets(); saveCfg();
      });
    });
    fillStyleControls(); renderStylePresets();
    var my = setupUserPresets({
      listKey: 'customStyles', selKey: 'customStyleSel', grid: 'myStylePresets', name: 'myStyleName',
      add: 'btnMyAdd', upd: 'btnMyUpd', del: 'btnMyDel', statusTab: 'styles', defName: 'Мой стиль',
      emptyText: 'Пока пусто — настрой стиль ниже и нажми «Сохранить новый»',
      pickFirst: 'Сначала выбери свой стиль в списке выше',
      snapshot: function () { return clone(S.cfg.ui.style); },
      tile: function (data) { return stylePreview(Object.assign({}, STYLE_DEFAULT, data)); },
      apply: function (data) {
        S.cfg.ui.style = Object.assign({}, STYLE_DEFAULT, clone(data)); S.cfg.ui.stylePreset = '';
        fillStyleControls(); renderStylePresets();
      }
    });
    S.rerenderMyStyles = my.render;
    $('btnStyleSel').addEventListener('click', function () { applyStyle(true); });
    $('btnStyleAll').addEventListener('click', function () { applyStyle(false); });
  }
  function applyStyle(selectedOnly) {
    setStatus('busy', 'Применяю стиль…', 'styles');
    host('applyStyle', { style: S.cfg.ui.style, selectedOnly: selectedOnly }).then(function (r) {
      setStatus(r.count ? 'ok' : '', r.count ? 'Стиль применён к ' + r.count + ' слоям' + fontNoteText(r.fontNote) : 'Нет слоёв SubLee в этой композиции', 'styles');
    }).catch(function (e) { setStatus('err', e.message, 'styles'); });
  }

  /* ------------------------------------------------------------------ анимация */
  function animPayload(a, selectedOnly) {
    return { preset: a.preset, frames: a.frames, power: a.power > 0 ? a.power : 100, out: a.out, selectedOnly: selectedOnly };
  }
  function initAnim() {
    var a = S.cfg.ui.anim, box = $('animPresets'), my;
    function paint() {
      box.innerHTML = '';
      ANIM_PRESETS.forEach(function (p) {
        var el = h('button', { class: 'preset' + (a.preset === p.id ? ' on' : ''), title: p.name }, [
          animPreview(p.id), h('div', { class: 'pn', text: p.name })
        ]);
        el.addEventListener('click', function () { a.preset = p.id; paint(); saveCfg(); });
        box.appendChild(el);
      });
    }
    function sync() {
      $('anFrames').value = a.frames; $('vFrames').textContent = a.frames;
      $('anPower').value = a.power; $('vPower').textContent = a.power + '%';
      $('anOut').checked = !!a.out; $('anAuto').checked = !!a.auto;
    }
    paint(); sync();
    var fr = $('anFrames');
    fr.addEventListener('input', function () { a.frames = parseInt(fr.value, 10); $('vFrames').textContent = a.frames; saveCfg(); });
    var pw = $('anPower');
    pw.addEventListener('input', function () { a.power = parseInt(pw.value, 10); $('vPower').textContent = a.power + '%'; saveCfg(); });
    [['anOut', 'out'], ['anAuto', 'auto']].forEach(function (p) {
      var el = $(p[0]);
      el.addEventListener('change', function () { a[p[1]] = el.checked; saveCfg(); });
    });
    my = setupUserPresets({
      listKey: 'customAnims', selKey: 'customAnimSel', grid: 'myAnimPresets', name: 'myAnimName',
      add: 'btnMyAnimAdd', upd: 'btnMyAnimUpd', del: 'btnMyAnimDel', statusTab: 'anim', defName: 'Моя анимация',
      emptyText: 'Пока пусто — выбери пресет, подстрой ползунки и нажми «Сохранить новую»',
      pickFirst: 'Сначала выбери свою анимацию в списке выше',
      snapshot: function () { return { preset: a.preset, frames: a.frames, power: a.power, out: !!a.out }; },
      tile: function (data) { return animPreview(data.preset); },
      apply: function (data) {
        a.preset = data.preset; a.frames = data.frames; a.power = data.power > 0 ? data.power : 100; a.out = !!data.out;
        paint(); sync();
      }
    });
    S.rerenderMyAnims = my.render;
    initBounce();
    $('btnAnimSel').addEventListener('click', function () { applyAnim(true); });
    $('btnAnimAll').addEventListener('click', function () { applyAnim(false); });
  }
  function bounceFrom(b) {
    var sel = b.props.indexOf('selected') >= 0;
    return {
      props: b.props.filter(function (x) { return x !== 'selected'; }), useSelected: sel, type: b.type,
      amp: b.amp / 100, freq: b.freq, decay: b.decay, elast: b.elast / 100,
      frames: S.cfg.ui.anim.frames, power: S.cfg.ui.anim.power > 0 ? S.cfg.ui.anim.power : 100
    };
  }
  function initBounce() {
    var b = S.cfg.ui.bounce;
    function paintProps() {
      $$('#bnProps button').forEach(function (el) { el.classList.toggle('on', b.props.indexOf(el.dataset.v) >= 0); });
      $('bnOver').style.display = b.type === 'overshoot' ? '' : 'none';
      $('bnBack').style.display = b.type === 'back' ? '' : 'none';
    }
    $$('#bnProps button').forEach(function (el) {
      el.addEventListener('click', function () {
        var v = el.dataset.v, i = b.props.indexOf(v);
        if (v === 'selected') b.props = i >= 0 ? [] : ['selected'];
        else {
          b.props = b.props.filter(function (x) { return x !== 'selected'; });
          i = b.props.indexOf(v);
          if (i >= 0) b.props.splice(i, 1); else b.props.push(v);
        }
        paintProps(); saveCfg();
      });
    });
    bindSeg($('bnType'), function () { return b.type; }, function (v) { b.type = v; paintProps(); });
    [['bnAmp', 'amp', 'vBnAmp', function (v) { return v + '%'; }], ['bnFreq', 'freq', 'vBnFreq', function (v) { return v; }],
     ['bnDecay', 'decay', 'vBnDecay', function (v) { return v; }], ['bnElast', 'elast', 'vBnElast', function (v) { return v + '%'; }]].forEach(function (c) {
      var el = $(c[0]); el.value = b[c[1]]; $(c[2]).textContent = c[3](b[c[1]]);
      el.addEventListener('input', function () { b[c[1]] = parseFloat(el.value); $(c[2]).textContent = c[3](b[c[1]]); saveCfg(); });
    });
    $('bnAuto').checked = !!b.auto;
    $('bnAuto').addEventListener('change', function () { b.auto = $('bnAuto').checked; saveCfg(); });
    paintProps();
    function run(selectedOnly) {
      var pl = bounceFrom(b);
      if (!pl.useSelected && !pl.props.length) { setStatus('err', 'Выбери, что пружинит: Position, Scale, Rotation или Selected', 'anim'); return; }
      pl.selectedOnly = selectedOnly;
      setStatus('busy', 'Добавляю Bounce…', 'anim');
      host('applyBounce', pl).then(function (r) {
        if (pl.useSelected) setStatus(r.count ? 'ok' : 'err', r.count ? 'Bounce добавлен к свойствам: ' + r.count + (r.skipped ? ' (пропущено без ключей: ' + r.skipped + ')' : '') : 'Выдели в таймлайне AE свойства с ключами (минимум 2 ключа)', 'anim');
        else setStatus(r.count ? 'ok' : '', r.count ? 'Bounce добавлен к ' + r.count + ' слоям' : 'Нет подходящих слоёв (нужен режим «слой на подпись»)', 'anim');
      }).catch(function (e) { setStatus('err', e.message, 'anim'); });
    }
    $('btnBounceSel').addEventListener('click', function () { run(true); });
    $('btnBounceAll').addEventListener('click', function () { run(false); });
  }
  function applyAnim(selectedOnly) {
    var a = S.cfg.ui.anim;
    setStatus('busy', 'Применяю анимацию…', 'anim');
    host('applyAnimation', animPayload(a, selectedOnly)).then(function (r) {
      setStatus(r.count ? 'ok' : '', r.count ? 'Анимация применена к ' + r.count + ' слоям' : 'Нет подходящих слоёв (анимация работает в режиме «слой на подпись»)', 'anim');
    }).catch(function (e) { setStatus('err', e.message, 'anim'); });
  }

  /* ------------------------------------------------------------------ эффекты текста (по словам / по буквам, In и Out) */
  /* spec: u — единица (w слова, c буквы, l строки), r — случайный порядок, x/y/z — сдвиг в размерах шрифта, o — прозрачность,
     b — размытие, s — масштаб %, t — поворот, rx/ry — 3D-повороты, ax/ay — якорь, k — трекинг, sh — «ступеньками» (печать) */
  var FX_CATS = [{"id":"all","name":"Все"},{"id":"pos","name":"Сдвиг"},{"id":"blur","name":"Сдвиг + размытие"},{"id":"op","name":"Проявление"},{"id":"rand","name":"Случайные"},{"id":"d3","name":"3D"},{"id":"anc","name":"Якорь"},{"id":"type","name":"Печать"},{"id":"pop","name":"Масштаб"},{"id":"twist","name":"Вращение"},{"id":"trk","name":"Разъезд"}];
  var FX_PRESETS = [{"id":"fx00","cat":"pos","name":"Слова вниз","spec":{"u":"w","x":0,"y":-1.3,"o":0}},{"id":"fx01","cat":"pos","name":"Слова вверх","spec":{"u":"w","x":0,"y":1.3,"o":0}},{"id":"fx02","cat":"pos","name":"Слова влево","spec":{"u":"w","x":2.2,"y":0,"o":0}},{"id":"fx03","cat":"pos","name":"Слова вправо","spec":{"u":"w","x":-2.2,"y":0,"o":0}},{"id":"fx04","cat":"pos","name":"Буквы вниз","spec":{"u":"c","x":0.0,"y":-1.1700000000000002,"o":0}},{"id":"fx05","cat":"pos","name":"Буквы вверх","spec":{"u":"c","x":0.0,"y":1.1700000000000002,"o":0}},{"id":"fx06","cat":"pos","name":"Буквы влево","spec":{"u":"c","x":1.1,"y":0.0,"o":0}},{"id":"fx07","cat":"pos","name":"Буквы вправо","spec":{"u":"c","x":-1.1,"y":0.0,"o":0}},{"id":"fx08","cat":"blur","name":"Слова вниз + размытие","spec":{"u":"w","x":0,"y":-1.3,"o":0,"b":0.3}},{"id":"fx09","cat":"blur","name":"Слова вверх + размытие","spec":{"u":"w","x":0,"y":1.3,"o":0,"b":0.3}},{"id":"fx10","cat":"blur","name":"Слова влево + размытие","spec":{"u":"w","x":2.2,"y":0,"o":0,"b":0.3}},{"id":"fx11","cat":"blur","name":"Слова вправо + размытие","spec":{"u":"w","x":-2.2,"y":0,"o":0,"b":0.3}},{"id":"fx12","cat":"blur","name":"Буквы вниз + размытие","spec":{"u":"c","x":0.0,"y":-1.1700000000000002,"o":0,"b":0.3}},{"id":"fx13","cat":"blur","name":"Буквы вверх + размытие","spec":{"u":"c","x":0.0,"y":1.1700000000000002,"o":0,"b":0.3}},{"id":"fx14","cat":"blur","name":"Буквы влево + размытие","spec":{"u":"c","x":1.1,"y":0.0,"o":0,"b":0.3}},{"id":"fx15","cat":"blur","name":"Буквы вправо + размытие","spec":{"u":"c","x":-1.1,"y":0.0,"o":0,"b":0.3}},{"id":"fx16","cat":"op","name":"Слова","spec":{"u":"w","o":0}},{"id":"fx17","cat":"op","name":"Буквы","spec":{"u":"c","o":0}},{"id":"fx18","cat":"op","name":"Строки","spec":{"u":"l","o":0}},{"id":"fx19","cat":"op","name":"Слова + размытие","spec":{"u":"w","o":0,"b":0.35}},{"id":"fx20","cat":"op","name":"Буквы + размытие","spec":{"u":"c","o":0,"b":0.35}},{"id":"fx21","cat":"rand","name":"Случайные слова","spec":{"u":"w","r":1,"o":0}},{"id":"fx22","cat":"rand","name":"Случайные буквы","spec":{"u":"c","r":1,"o":0}},{"id":"fx23","cat":"rand","name":"Случайные слова + размытие","spec":{"u":"w","r":1,"o":0,"b":0.35}},{"id":"fx24","cat":"rand","name":"Случайные буквы + размытие","spec":{"u":"c","r":1,"o":0,"b":0.35}},{"id":"fx25","cat":"rand","name":"Случайные слова вверх","spec":{"u":"w","r":1,"y":1.1,"o":0}},{"id":"fx26","cat":"rand","name":"Случайные буквы вниз","spec":{"u":"c","r":1,"y":-1.1,"o":0}},{"id":"fx27","cat":"d3","name":"3D слова вниз","spec":{"u":"w","o":0,"rx":-90,"y":-0.4}},{"id":"fx28","cat":"d3","name":"3D слова вверх","spec":{"u":"w","o":0,"rx":90,"y":0.4}},{"id":"fx29","cat":"d3","name":"3D слова влево","spec":{"u":"w","o":0,"ry":-90,"x":0.8}},{"id":"fx30","cat":"d3","name":"3D слова вправо","spec":{"u":"w","o":0,"ry":90,"x":-0.8}},{"id":"fx31","cat":"d3","name":"3D слова вперёд","spec":{"u":"w","o":0,"z":-5,"s":140}},{"id":"fx32","cat":"d3","name":"3D буквы вниз","spec":{"u":"c","o":0,"rx":-90,"y":-0.4}},{"id":"fx33","cat":"d3","name":"3D буквы вверх","spec":{"u":"c","o":0,"rx":90,"y":0.4}},{"id":"fx34","cat":"d3","name":"3D буквы влево","spec":{"u":"c","o":0,"ry":-90,"x":0.8}},{"id":"fx35","cat":"d3","name":"3D буквы вправо","spec":{"u":"c","o":0,"ry":90,"x":-0.8}},{"id":"fx36","cat":"d3","name":"3D буквы вперёд","spec":{"u":"c","o":0,"z":-5,"s":140}},{"id":"fx37","cat":"d3","name":"3D буквы + поворот вниз","spec":{"u":"c","o":0,"rx":-90,"t":-20}},{"id":"fx38","cat":"d3","name":"3D буквы + поворот вверх","spec":{"u":"c","o":0,"rx":90,"t":20}},{"id":"fx39","cat":"d3","name":"3D буквы + поворот влево","spec":{"u":"c","o":0,"ry":-90,"t":-20}},{"id":"fx40","cat":"d3","name":"3D буквы + поворот вправо","spec":{"u":"c","o":0,"ry":90,"t":20}},{"id":"fx41","cat":"anc","name":"Слова якорь вниз","spec":{"u":"w","ax":0,"ay":-2.2,"t":-25,"o":0}},{"id":"fx42","cat":"anc","name":"Слова якорь вверх","spec":{"u":"w","ax":0,"ay":2.2,"t":25,"o":0}},{"id":"fx43","cat":"anc","name":"Слова якорь влево","spec":{"u":"w","ax":2.2,"ay":0,"t":-25,"o":0}},{"id":"fx44","cat":"anc","name":"Слова якорь вправо","spec":{"u":"w","ax":-2.2,"ay":0,"t":25,"o":0}},{"id":"fx45","cat":"anc","name":"Буквы якорь вниз","spec":{"u":"c","ax":0,"ay":-2.2,"t":-25,"o":0}},{"id":"fx46","cat":"anc","name":"Буквы якорь вверх","spec":{"u":"c","ax":0,"ay":2.2,"t":25,"o":0}},{"id":"fx47","cat":"anc","name":"Буквы якорь влево","spec":{"u":"c","ax":2.2,"ay":0,"t":-25,"o":0}},{"id":"fx48","cat":"anc","name":"Буквы якорь вправо","spec":{"u":"c","ax":-2.2,"ay":0,"t":25,"o":0}},{"id":"fx49","cat":"type","name":"Печать: буквы","spec":{"u":"c","o":0,"sh":1}},{"id":"fx50","cat":"type","name":"Печать: слова","spec":{"u":"w","o":0,"sh":1}},{"id":"fx51","cat":"type","name":"Печать + размытие","spec":{"u":"c","o":0,"sh":1,"b":0.3}},{"id":"fx52","cat":"pop","name":"Слова вырастают","spec":{"u":"w","s":0,"o":0}},{"id":"fx53","cat":"pop","name":"Буквы вырастают","spec":{"u":"c","s":0,"o":0}},{"id":"fx54","cat":"pop","name":"Слова: наезд","spec":{"u":"w","s":260,"o":0}},{"id":"fx55","cat":"pop","name":"Буквы: наезд","spec":{"u":"c","s":260,"o":0}},{"id":"fx56","cat":"twist","name":"Буквы: вращение","spec":{"u":"c","t":-90,"o":0}},{"id":"fx57","cat":"twist","name":"Слова: вращение","spec":{"u":"w","t":-45,"o":0}},{"id":"fx58","cat":"twist","name":"Вихрь","spec":{"u":"c","t":-180,"s":0,"o":0}},{"id":"fx59","cat":"trk","name":"Разъезд букв","spec":{"u":"c","k":150,"o":0}},{"id":"fx60","cat":"trk","name":"Сжатие букв","spec":{"u":"c","k":-60,"o":0}}];
  var FX_STEP = { c: 0.07, w: 0.2, l: 0.32 };

  function fxShuffle(n, seed) {      // повторяемая «случайная» перестановка для превью
    var a = [], i, j, t, x = seed * 9301 + 49297;
    for (i = 0; i < n; i++) a.push(i);
    for (i = n - 1; i > 0; i--) { x = (x * 9301 + 49297) % 233280; j = Math.floor(x / 233280 * (i + 1)); t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function em(v) { return (Math.round(v * 100) / 100) + 'em'; }
  function fxUnitStyle(sp, order, step) {
    var k = 0.6, sc = sp.s === undefined ? 1 : sp.s / 100;
    var x = (sp.x || 0) * k, y = (sp.y || 0) * k, z = -(sp.z || 0) * k * 0.7;
    var ax = sp.ax || 0, ay = sp.ay || 0;
    return '--dl:' + (order * step).toFixed(2) + 's;--o:' + (sp.o === undefined ? 0 : sp.o / 100) +
      ';--x:' + em(x) + ';--y:' + em(y) + ';--z:' + em(z) + ';--ox:' + em(-x) + ';--oy:' + em(-y) + ';--oz:' + em(-z) +
      ';--rx:' + (sp.rx || 0) + 'deg;--ry:' + (sp.ry || 0) + 'deg;--r:' + (sp.t || 0) + 'deg' +
      ';--orx:' + (-(sp.rx || 0)) + 'deg;--ory:' + (-(sp.ry || 0)) + 'deg;--or:' + (-(sp.t || 0)) + 'deg' +
      ';--s:' + sc + ';--b:' + Math.round((sp.b || 0) * 14) + 'px;--ls:' + em((sp.k || 0) / 1000 * 3) +
      ';--tox:' + (50 + ax * 22) + '%;--toy:' + (50 + ay * 22) + '%';
  }
  function fxPreview(sp) {
    var words = ['Text', 'FX'], units = [], wrap = h('span', { class: 'fxs' + (sp.u === 'l' ? ' lines' : '') });
    words.forEach(function (w, wi) {
      var ww = h('span', { class: 'fxw' });
      if (sp.u === 'c') w.split('').forEach(function (ch) { var u = h('i', { class: 'fxu', text: ch }); units.push(u); ww.appendChild(u); });
      else { var u = h('i', { class: 'fxu', text: w }); units.push(u); ww.appendChild(u); }
      wrap.appendChild(ww);
    });
    var order = sp.r ? fxShuffle(units.length, 7) : units.map(function (_, i) { return i; });
    units.forEach(function (u, i) { u.setAttribute('style', fxUnitStyle(sp, order[i], FX_STEP[sp.u || 'c'])); });
    return h('div', { class: 'pv fxv', style: pvPhase() }, [wrap]);
  }
  function initFx() {
    var f = S.cfg.ui.fx, grid = $('fxGrid'), armed = null;
    function paintCats() {
      var box = $('fxCats'); box.innerHTML = '';
      FX_CATS.forEach(function (c) {
        var b = h('button', { 'data-v': c.id, class: f.cat === c.id ? 'on' : '', text: c.name });
        b.addEventListener('click', function () { f.cat = c.id; paintCats(); paintGrid(); saveCfg(); });
        box.appendChild(b);
      });
    }
    function paintGrid() {
      grid.innerHTML = ''; grid.setAttribute('data-m', f.mode);
      FX_PRESETS.forEach(function (p) {
        if (f.cat !== 'all' && p.cat !== f.cat) return;
        var el = h('button', { class: 'preset', title: p.name, 'data-fx': p.id }, [fxPreview(p.spec), h('div', { class: 'pn', text: p.name })]);
        el.addEventListener('click', function () { applyFx(p); });
        grid.appendChild(el);
      });
    }
    function modeLabel() { return f.mode === 'in' ? 'Только In' : (f.mode === 'out' ? 'Только Out' : 'In + Out'); }
    function applyFx(p) {
      f.last = p.id; saveCfg();
      setStatus('busy', 'Добавляю эффект…', 'fx');
      host('applyFx', { spec: p.spec, mode: f.mode, inFrames: f.inF, outFrames: f.outF, power: f.power, selectedOnly: f.scope !== 'all' }).then(function (r) {
        setStatus(r.count ? 'ok' : '', r.count ? 'Эффект «' + p.name + '» (' + modeLabel() + '): ' + r.count + ' слоёв' : 'Нет текстовых слоёв: выдели текст или создай субтитры (режим «один слой» не поддерживается)', 'fx');
      }).catch(function (e) { setStatus('err', e.message, 'fx'); });
    }
    function sync() {
      $('fxIn').value = f.inF; $('vFxIn').textContent = f.inF;
      $('fxOut').value = f.outF; $('vFxOut').textContent = f.outF;
      $('fxPower').value = f.power; $('vFxPower').textContent = f.power + '%';
    }
    bindSeg($('fxMode'), function () { return f.mode; }, function (v) { f.mode = v; grid.setAttribute('data-m', v); });
    bindSeg($('fxScope'), function () { return f.scope; }, function (v) { f.scope = v; });
    [['fxIn', 'inF', 'vFxIn', function (v) { return v; }], ['fxOut', 'outF', 'vFxOut', function (v) { return v; }], ['fxPower', 'power', 'vFxPower', function (v) { return v + '%'; }]].forEach(function (c) {
      var el = $(c[0]);
      el.addEventListener('input', function () { f[c[1]] = parseInt(el.value, 10); $(c[2]).textContent = c[3](f[c[1]]); saveCfg(); });
    });
    var del = $('btnFxClear');
    function disarm() { clearTimeout(armed); armed = null; del.classList.remove('arm'); del.lastChild.textContent = ' Удалить все анимации'; }
    del.addEventListener('click', function () {
      if (!armed) { del.classList.add('arm'); del.lastChild.textContent = ' Точно удалить?'; armed = setTimeout(disarm, 3000); return; }
      disarm();
      setStatus('busy', 'Удаляю анимации…', 'fx');
      host('clearAnimations', { selectedOnly: f.scope !== 'all' }).then(function (r) {
        setStatus(r.count ? 'ok' : '', r.count ? 'Анимации удалены: ' + r.count + ' слоёв (Ctrl+Z вернёт)' : 'Нет текстовых слоёв в этой композиции', 'fx');
      }).catch(function (e) { setStatus('err', e.message, 'fx'); });
    });
    sync(); paintCats(); paintGrid();
  }

  /* ------------------------------------------------------------------ оформление */
  var THEMES = [
    { id: 'cobalt', name: 'Кобальт', bg: 'linear-gradient(165deg,#00409a,#011a42)', bar: 'linear-gradient(135deg,#fff,#b5d3ff)' },
    { id: 'electro', name: 'Электро', bg: 'linear-gradient(165deg,#020618,#0a2a78)', bar: 'linear-gradient(135deg,#2ee6ff,#3a6bff)' },
    { id: 'sunset', name: 'Закат', bg: 'linear-gradient(165deg,#081244,#2a1572)', bar: 'linear-gradient(135deg,#0a5be0,#6b46e6,#d24bff)' },
    { id: 'ice', name: 'Лёд', bg: 'linear-gradient(165deg,#f2f7ff,#d4e3ff)', bar: 'linear-gradient(135deg,#00409a,#2f86ff)' },
    { id: 'classic', name: 'Графит', bg: '#1b1b1f', bar: 'linear-gradient(135deg,#7da2ff,#c9a3ff)' },
    { id: 'ae', name: 'Как в Adobe', bg: '#1d1d1d', bar: 'linear-gradient(135deg,#2d8ceb,#1473e6)' }
  ];
  /* «Как в Adobe»: цвет панелей берём у самого After Effects (яркость интерфейса: Darkest … Lightest) */
  var AE_VARS = ['--bg', '--card', '--card2', '--line', '--line2', '--input', '--input2', '--raised', '--hover', '--well', '--well2'];
  function hex2(c) { c = Math.max(0, Math.min(255, Math.round(c))); return (c < 16 ? '0' : '') + c.toString(16); }
  function mixc(a, b, t) { return '#' + hex2(a[0] + (b[0] - a[0]) * t) + hex2(a[1] + (b[1] - a[1]) * t) + hex2(a[2] + (b[2] - a[2]) * t); }
  function aeSkin() {
    var env = cs.getHostEnvironment ? cs.getHostEnvironment() : null, c = env && env.appSkinInfo && env.appSkinInfo.panelBackgroundColor && env.appSkinInfo.panelBackgroundColor.color;
    if (!c || isNaN(c.red) || isNaN(c.green) || isNaN(c.blue)) return null;
    return [c.red, c.green, c.blue];
  }
  function applyAeSkin() {
    var root = document.documentElement, st = root.style, i;
    if (S.cfg.ui.theme !== 'ae') {
      root.removeAttribute('data-ae');
      for (i = 0; i < AE_VARS.length; i++) st.removeProperty(AE_VARS[i]);
      return;
    }
    var c = aeSkin() || [29, 29, 29], W = [255, 255, 255], K = [0, 0, 0];
    var light = (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) / 255 > 0.5;
    var v = light ? {
      '--bg': mixc(c, W, 0), '--card': mixc(c, W, 0.35), '--card2': mixc(c, W, 0.55), '--line': mixc(c, K, 0.14), '--line2': mixc(c, K, 0.34),
      '--input': mixc(c, W, 0.75), '--input2': mixc(c, W, 0.6), '--raised': mixc(c, K, 0.08), '--hover': mixc(c, K, 0.04), '--well': mixc(c, W, 0.45), '--well2': mixc(c, W, 0.55)
    } : {
      '--bg': mixc(c, K, 0), '--card': mixc(c, W, 0.04), '--card2': mixc(c, W, 0.075), '--line': mixc(c, W, 0.13), '--line2': mixc(c, W, 0.29),
      '--input': mixc(c, K, 0.3), '--input2': mixc(c, K, 0.2), '--raised': mixc(c, W, 0.13), '--hover': mixc(c, W, 0.07), '--well': mixc(c, K, 0.38), '--well2': mixc(c, K, 0.28)
    };
    root.setAttribute('data-ae', light ? 'light' : 'dark');
    Object.keys(v).forEach(function (k) { st.setProperty(k, v[k]); });
  }
  function applyTheme() {
    document.documentElement.setAttribute('data-theme', S.cfg.ui.theme || 'cobalt');
    document.documentElement.setAttribute('data-motion', S.cfg.ui.motion === false ? 'off' : 'on');
    applyAeSkin();
  }
  /* превью по наведению: образец стиля играет текущую анимацию */
  function initHoverPreview() {
    function sp(e) { var t = e.target, pr = t && t.closest ? t.closest('.preset') : null; return pr ? pr.querySelector('.pvs[data-follow]') : null; }
    document.addEventListener('mouseover', function (e) {      // наведение: плитка стиля играет выбранную анимацию
      var el = sp(e); if (!el || el.getAttribute('data-hov')) return;
      el.setAttribute('data-own', el.getAttribute('data-a')); el.setAttribute('data-hov', '1');
      el.setAttribute('data-a', S.cfg.ui.anim.preset);
    });
    document.addEventListener('mouseout', function (e) {       // ушли — вернулась своя анимация стиля
      var el = sp(e); if (!el || !el.getAttribute('data-hov')) return;
      var pr = el.closest('.preset'), to = e.relatedTarget;
      if (to && pr && pr.contains(to)) return;
      el.setAttribute('data-a', el.getAttribute('data-own')); el.removeAttribute('data-hov');
    });
  }
  /* масштаб интерфейса следует за шириной панели в AE (база — 440 px) */
  function fitScale() {
    var app = $('app'), z = 1;
    if (S.cfg.ui.autoScale !== false) z = Math.max(0.7, Math.min(2.5, (window.innerWidth || 440) / 440));
    z = Math.round(z * 100) / 100;
    app.style.zoom = z === 1 ? '' : String(z);
    app.style.height = z === 1 ? '' : Math.floor((window.innerHeight || 800) / z) + 'px';
  }
  function initScale() {
    var cb = $('stScale'), raf = null;
    cb.checked = S.cfg.ui.autoScale !== false;
    cb.addEventListener('change', function () { S.cfg.ui.autoScale = cb.checked; fitScale(); saveCfg(); });
    window.addEventListener('resize', function () { if (raf) return; raf = setTimeout(function () { raf = null; fitScale(); }, 30); });
    fitScale();
  }
  function initMotion() {
    var cb = $('stMotion');
    cb.checked = S.cfg.ui.motion !== false;
    cb.addEventListener('change', function () { S.cfg.ui.motion = cb.checked; applyTheme(); saveCfg(); });
  }
  function initThemes() {
    var box = $('themePicker');
    function paint() {
      box.innerHTML = '';
      THEMES.forEach(function (t) {
        var el = h('button', { class: 'theme' + (S.cfg.ui.theme === t.id ? ' on' : ''), title: t.name }, [
          h('div', { class: 'sw', style: 'background:' + t.bg }, [h('b', { style: 'background:' + t.bar }), h('i', { style: 'background:' + t.bar })]),
          h('div', { class: 'tn', text: t.name })
        ]);
        el.addEventListener('click', function () { S.cfg.ui.theme = t.id; applyTheme(); paint(); saveCfg(); });
        box.appendChild(el);
      });
    }
    paint();
    if (cs.addEventListener) cs.addEventListener('com.adobe.csxs.events.ThemeColorChanged', function () { applyAeSkin(); });   // пользователь сменил яркость интерфейса AE
  }

  /* ------------------------------------------------------------------ настройки */
  var SET_FIELDS = [
    ['sWhisper', 'whisperPath'], ['sModel', 'modelPath'], ['sFfmpeg', 'ffmpegPath'], ['sThreads', 'threads', 'num'],
    ['sTiming', 'wordTiming'], ['sOaKey', 'openaiKey'], ['sOaStt', 'openaiSttModel'], ['sOaBase', 'openaiBase'],
    ['sAnKey', 'anthropicKey'], ['sAnModel', 'anthropicModel'], ['sOaChat', 'openaiChatModel']
  ];
  function paintSettingsBoxes() {
    $('boxLocal').style.display = S.cfg.engine === 'local' ? '' : 'none';
    $('boxOpenAI').style.display = S.cfg.engine === 'openai' || S.cfg.trProvider === 'openai' ? '' : 'none';
    $('boxTrAnthropic').style.display = S.cfg.trProvider === 'anthropic' ? '' : 'none';
    $('boxTrOpenAI').style.display = S.cfg.trProvider === 'openai' ? '' : 'none';
  }
  function initSettings() {
    SET_FIELDS.forEach(function (f) {
      var el = $(f[0]); el.value = S.cfg[f[1]];
      el.addEventListener('change', function () { S.cfg[f[1]] = f[2] === 'num' ? (parseInt(el.value, 10) || 0) : el.value.trim(); saveCfg(); });
    });
    bindSeg($('segEngine'), function () { return S.cfg.engine; }, function (v) { S.cfg.engine = v; paintSettingsBoxes(); });
    bindSeg($('segTr'), function () { return S.cfg.trProvider; }, function (v) { S.cfg.trProvider = v; paintSettingsBoxes(); });
    paintSettingsBoxes();
    if (S.keysLost) { var kh = $('keyHint'); kh.textContent = I18N.tr('Ключи из файла настроек не расшифровались (файл с другого компьютера?). Впиши их заново.', S.cfg.ui.uiLang); kh.classList.add('warn'); }
    $$('[data-browse]').forEach(function (b) {
      b.addEventListener('click', function () {
        openDialog('Выбери файл', []).then(function (p) {
          if (!p) return;
          var el = $(b.dataset.browse); el.value = p; el.dispatchEvent(new Event('change'));
        });
      });
    });
    $('btnSave').addEventListener('click', function () { saveCfg(); showDiag('Сохранено.', 'g'); });
    $('btnDiag').addEventListener('click', runDiag);
  }
  function showDiag(text, cls) { $('diag').innerHTML = ''; $('diag').appendChild(h('div', { class: cls || '', text: text })); }
  function runDiag() {
    var d = $('diag'); d.innerHTML = '';
    function line(ok, label, val, hint) {
      d.appendChild(h('div', { class: ok ? 'g' : 'r', text: (ok ? '✓ ' : '✗ ') + label + ': ' + (val || 'не найден') }));
      if (!ok && hint) d.appendChild(h('div', { class: 'y', text: '   ' + hint }));
    }
    if (!Engine) { line(false, 'Движок', '', bootError); return; }
    var r = Engine.diagnose(engineSettings());
    line(!!r.ffmpeg, 'ffmpeg', r.ffmpeg, 'Положи ffmpeg(.exe) в папку bin расширения или укажи путь выше.');
    if (S.cfg.engine === 'local') {
      line(!!r.whisper, 'whisper-cli', r.whisper, 'Запусти установщик с ключом -WithWhisper или укажи путь.');
      line(!!r.model, 'Модель', r.model, 'Нужен файл ggml-*.bin (рекомендую ggml-large-v3-turbo-q5_0.bin).');
    } else {
      line(!!r.openaiKey, 'OpenAI ключ', r.openaiKey ? 'задан' : '', 'Впиши ключ в поле выше.');
    }
    var needsKey = S.cfg.trProvider === 'openai' ? r.openaiKey : r.anthropicKey;
    d.appendChild(h('div', { class: needsKey ? 'g' : 'y', text: (needsKey ? '✓ ' : '! ') + 'Ключ для перевода: ' + (needsKey ? 'задан' : 'не задан (нужен только если язык субтитров ≠ языку речи)') }));
    host('ping').then(function (p) {
      d.appendChild(h('div', { class: 'g', text: '✓ ' + NAME_APP + ': ' + p.version }));
    }).catch(function (e) { d.appendChild(h('div', { class: 'r', text: '✗ ' + e.message })); });
  }
  function engineSettings() {
    var c = S.cfg, o = {};
    Object.keys(Engine.DEFAULTS).forEach(function (k) { o[k] = c[k]; });
    return o;
  }

  /* ------------------------------------------------------------------ главный процесс */
  function autoChars(comp) {
    var u = S.cfg.ui, safe = u.custom.safe >= 0 ? u.custom.safe : 8;
    var px = Math.min(comp.width, comp.height) * u.style.sizePct / 100;
    var factor = u.style.uppercase ? 0.70 : 0.58;
    var n = Math.floor(comp.width * (1 - 2 * safe / 100) / (px * factor));
    return Math.max(12, Math.min(48, n));
  }

  function pickClips(ctx) {
    if (S.audioFile) {
      return [{ file: S.audioFile, srcStart: 0, srcDur: 0, offset: 0, stretch: 100, name: pathMod.basename(S.audioFile) }];
    }
    var clips = ctx.layers.filter(function (l) { return l.file && l.hasAudio; });
    if (!clips.length && !ctx.layers.length && ctx.all.length === 1) clips = ctx.all;
    if (!clips.length) {
      var bad = ctx.layers[0];
      if (bad && bad.note === 'precomp') throw new Error('Выбран пре-комп. Выдели исходный слой с видео/аудио (или выбери файл в «Дополнительно»).');
      if (bad && bad.note === 'nofile') throw new Error('У слоя нет файла-источника. Выбери файл в «Дополнительно».');
      if (PPRO) throw new Error('Выдели на таймлайне клип с видео или аудио (или выбери файл в «Дополнительно»).');
      throw new Error('Выдели в композиции слой с видео или аудио (или выбери файл в «Дополнительно»).');
    }
    return clips.map(function (c) {
      return { file: c.file, srcStart: c.srcStart, srcDur: c.srcDur, offset: c.inPoint, stretch: c.stretch || 100, name: c.name, note: c.note };
    });
  }

  function transcribeClips(clips) {
    var u = S.cfg.ui, out = [], chain = Promise.resolve();
    S.langInfo = '';
    clips.forEach(function (c, i) {
      chain = chain.then(function () {
        var key = [S.cfg.engine, u.speech, S.cfg.wordTiming, c.file, c.srcStart.toFixed(3), c.srcDur.toFixed(3)].join('|');
        if (S.cache[key]) { out.push({ clip: c, tr: S.cache[key], key: key }); return; }
        var tag = clips.length > 1 ? ' (' + (i + 1) + '/' + clips.length + ')' : '';
        return Engine.transcribeClip({
          input: c.file, start: c.srcStart, duration: c.srcDur, lang: u.speech, settings: engineSettings(),
          onStatus: function (m) { setStatus('busy', m + tag); },
          onProgress: function (p) { setProgress(p); }
        }).then(function (tr) {
          if (!tr.words.length) throw new Error('Речь не найдена в «' + c.name + '».');
          S.cache[key] = tr; out.push({ clip: c, tr: tr, key: key });
        });
      });
    });
    return chain.then(function () {
      var all = [];
      out.forEach(function (it) { if (it.tr.mixed) all = all.concat(it.tr.words); });
      if (all.length) S.langInfo = Core.langShares(all).map(function (x) { return x.l.toUpperCase() + ' ' + x.pct + '%'; }).join(' \u00B7 ');
      return out;
    });
  }

  // смешанная речь: слова каждого языка переводим отдельно, слова на нужном языке не трогаем
  function wordsForMixed(item, lang) {
    var key = item.key + '>' + lang + '|' + S.cfg.trProvider;
    if (S.trCache[key]) return Promise.resolve(S.trCache[key]);
    var runs = Core.runsByLang(item.tr.words), segs = [], owner = [];
    runs.forEach(function (r, ri) {
      if (!r.l || r.l === lang) return;
      Core.segmentsFromWords(r.words).forEach(function (sg) { segs.push(sg); owner.push(ri); });
    });
    if (!segs.length) return Promise.resolve(item.tr.words);
    setStatus('busy', 'Перевожу фразы на ' + lang.toUpperCase() + '…');
    setProgress(null);
    var srcOf = owner.map(function (ri) { return runs[ri].l; });
    // переводим по языкам-источникам: один запрос на каждый язык
    var groups = {}, order = [];
    segs.forEach(function (sg, i) { var l = srcOf[i]; if (!groups[l]) { groups[l] = []; order.push(l); } groups[l].push(i); });
    var texts = new Array(segs.length), chain = Promise.resolve();
    order.forEach(function (l) {
      chain = chain.then(function () {
        return Engine.translateTexts(groups[l].map(function (i) { return segs[i].text; }), l, lang, engineSettings(), function (p) { setProgress(p); })
          .then(function (tt) { groups[l].forEach(function (i, k) { texts[i] = tt[k]; }); });
      });
    });
    return chain.then(function () {
      var byRun = {};
      segs.forEach(function (sg, i) { (byRun[owner[i]] = byRun[owner[i]] || []).push({ start: sg.start, end: sg.end, text: texts[i] }); });
      var words = [];
      runs.forEach(function (r, ri) {
        if (byRun[ri]) Core.wordsFromSegments(byRun[ri]).forEach(function (w) { words.push(w); });
        else r.words.forEach(function (w) { words.push(w); });
      });
      S.trCache[key] = words;
      return words;
    });
  }

  // слова на нужном языке для одного клипа
  function wordsFor(item, lang) {
    if (lang === 'orig') return Promise.resolve(item.tr.words);       // «как сказано»: без перевода
    if (item.tr.mixed) return wordsForMixed(item, lang);
    var tr = item.tr, src = tr.language || (S.cfg.ui.speech !== 'auto' ? S.cfg.ui.speech : '');
    if (!src || src === lang) return Promise.resolve(tr.words);
    var key = item.key + '>' + lang + '|' + S.cfg.trProvider;
    if (S.trCache[key]) return Promise.resolve(S.trCache[key]);
    var segs = Core.segmentsFromWords(tr.words);
    setStatus('busy', 'Перевожу ' + src.toUpperCase() + ' → ' + lang.toUpperCase() + '…');
    setProgress(null);
    return Engine.translateTexts(segs.map(function (s) { return s.text; }), src, lang, engineSettings(), function (p) { setProgress(p); })
      .then(function (texts) {
        var tsegs = segs.map(function (s, i) { return { start: s.start, end: s.end, text: texts[i] }; });
        var words = Core.wordsFromSegments(tsegs);
        S.trCache[key] = words;
        return words;
      });
  }

  function buildSets(items, mode, ctx) {
    var u = S.cfg.ui, mc = u.custom.chars > 0 && mode === 'custom' ? u.custom.chars : autoChars(ctx.comp);
    var opts = {
      maxCharsPerLine: mc, maxLines: mode === 'custom' ? Math.max(1, u.custom.lines) : 2,
      maxWords: u.custom.words, removePunct: u.noPunct
    };
    var sets = [], chain = Promise.resolve();
    u.langs.forEach(function (lang) {
      chain = chain.then(function () {
        var caps = [], inner = Promise.resolve();
        items.forEach(function (item) {
          inner = inner.then(function () { return wordsFor(item, lang); }).then(function (words) {
            Core.makeCaptions(words, mode, opts).forEach(function (c) {
              caps.push({
                start: item.clip.offset + c.start * item.clip.stretch / 100,
                end: item.clip.offset + c.end * item.clip.stretch / 100,
                text: c.text
              });
            });
          });
        });
        return inner.then(function () {
          caps.sort(function (a, b) { return a.start - b.start; });
          sets.push({ lang: lang, captions: caps });
        });
      });
    });
    return chain.then(function () { return sets; });
  }

  function runMode(mode) {
    if (S.busy) return;
    if (!Engine) { setStatus('err', 'Движок не загружен: ' + bootError); return; }
    setBusy(true);
    setStatus('busy', PPRO ? 'Читаю последовательность…' : 'Читаю композицию…');
    var ctx, clips;
    host(PPRO ? 'ppContext' : 'getContext').then(function (c) {
      ctx = c; S.lastCtx = c; clips = pickClips(c);
      return transcribeClips(clips);
    }).then(function (items) {
      return buildSets(items, mode, ctx);
    }).then(function (sets) {
      var total = sets.reduce(function (n, s) { return n + s.captions.length; }, 0);
      if (!total) throw new Error('Не получилось собрать ни одной подписи.');
      setBusy(false);
      if (S.cfg.ui.review) return reviewSets(sets);
      return sets;
    }).then(function (sets) {
      if (!sets) { setStatus('', 'Отменено.'); return; }
      setBusy(true); setStatus('busy', PPRO ? 'Вставляю шаблоны в Premiere Pro…' : 'Создаю слои в After Effects…'); setProgress(null);
      return (PPRO ? createInPremiere(sets) : createInAE(sets)).then(function () { setBusy(false); });
    }).catch(function (e) {
      setBusy(false);
      setStatus(e && e.cancelled ? '' : 'err', e && e.cancelled ? 'Отменено.' : (e && e.message || String(e)));
    });
  }

  function createInAE(sets) {
    var u = S.cfg.ui;
    var payload = {
      style: u.style,
      layout: { pos: u.pos, y: u.yPct, safe: u.custom.safe },
      mode: u.layerMode, replace: u.replace, precomp: u.precomp,
      sets: sets.map(function (s) {
        return {
          lang: s.lang,
          captions: s.captions.filter(function (c) { return c.text && c.text.trim(); }).map(function (c) {
            return { start: c.start, end: c.end, text: u.style.uppercase ? c.text.toUpperCase() : c.text };
          })
        };
      })
    };
    return host('createCaptions', payload).then(function (r) {
      var langs = sets.map(function (s) { return langTag(s.lang); }).join(' + ');
      var msg = 'Готово! Создано подписей: ' + r.created + ' (' + langs + ') \u2728' + fontNoteText(r.fontNote) + (S.langInfo ? '\nЯзыки в речи: ' + S.langInfo : '');
      if (r.errors && r.errors.length) { setStatus('err', msg + '\nПроблемы: ' + r.errors.join(' | ')); }
      else setStatus('ok', msg);
      var chain = Promise.resolve();
      if (u.anim.auto && u.anim.preset !== 'none' && u.layerMode === 'multi') {
        chain = chain.then(function () { return host('applyAnimation', animPayload(u.anim, false)); });
      }
      if (u.bounce.auto && u.layerMode === 'multi' && u.bounce.props.length && u.bounce.props.indexOf('selected') < 0) {
        chain = chain.then(function () { return host('applyBounce', Object.assign(bounceFrom(u.bounce), { selectedOnly: false })); });
      }
      return chain.catch(function () {});
    });
  }

  /* ------------------------------------------------------------------ Premiere Pro: вставка шаблонов .mogrt и SRT */
  function mogrtDir() { return os ? pathMod.join(os.homedir(), '.subflow', 'mogrt') : ''; }
  function templateInfo(file) {
    var side = file.replace(/\.mogrt$/i, '.json'), o = { uppercase: false };
    try { if (fs.existsSync(side)) o = merge(o, JSON.parse(fs.readFileSync(side, 'utf8'))); } catch (e) { /* без файла-описания */ }
    return o;
  }
  function listTemplates() {
    var out = [], dir = mogrtDir();
    try {
      fs.readdirSync(dir).forEach(function (f) { if (/\.mogrt$/i.test(f)) out.push({ name: f.replace(/\.mogrt$/i, ''), file: pathMod.join(dir, f) }); });
    } catch (e) { /* папки ещё нет */ }
    out.sort(function (a, b) { return a.name < b.name ? -1 : 1; });
    return out;
  }

  function createInPremiere(sets) {
    var u = S.cfg.ui, pp = u.pp, langs = sets.map(function (s) { return langTag(s.lang); }).join(' + ');
    var clean = sets.map(function (s) {
      return { lang: s.lang, captions: s.captions.filter(function (c) { return c.text && c.text.trim(); }) };
    });
    if (pp.out === 'srt') return importSrtPremiere(clean, langs);
    if (!pp.tpl || !fs.existsSync(pp.tpl)) {
      return Promise.reject(new Error('Нет шаблона субтитров. Сделай .mogrt в панели SubLee в After Effects (вкладка «Стили» → «Экспорт в Premiere») или выбери готовый файл.'));
    }
    var upper = templateInfo(pp.tpl).uppercase;
    var payload = {
      mogrt: pp.tpl, replace: u.replace,
      sets: clean.map(function (s) {
        return { lang: s.lang, captions: s.captions.map(function (c) { return { start: c.start, end: c.end, text: upper ? c.text.toUpperCase() : c.text }; }) };
      })
    };
    return host('ppInsert', payload).then(function (r) {
      var msg = 'Готово! Создано подписей: ' + r.created + ' (' + langs + ') ✨' + (S.langInfo ? '\nЯзыки в речи: ' + S.langInfo : '');
      if (r.tracks && r.tracks.length) msg += '\nДорожки: ' + r.tracks.map(function (n) { return 'V' + n; }).join(', ');
      if (r.errors && r.errors.length) setStatus('err', msg + '\nПроблемы: ' + r.errors.join(' | '));
      else setStatus('ok', msg);
    });
  }

  function importSrtPremiere(sets, langs) {
    var chain = Promise.resolve(), made = 0;
    sets.forEach(function (s) {
      chain = chain.then(function () {
        var file = pathMod.join(os.tmpdir(), 'SubLee_' + s.lang.toUpperCase() + '_' + Date.now() + '.srt');
        fs.writeFileSync(file, Core.toSRT(s.captions), 'utf8');
        return host('ppImportSrt', { file: file, start: 0 }).then(function () { made++; });
      });
    });
    return chain.then(function () {
      setStatus('ok', 'Готово! Субтитры Premiere добавлены (' + langs + ') ✨');
    });
  }

  function initPremiere() {
    var sel = $('ppTpl'), pp = S.cfg.ui.pp;
    function paint() {
      var list = listTemplates();
      if (pp.tpl && !list.some(function (t) { return t.file === pp.tpl; }) && fs.existsSync(pp.tpl)) list.push({ name: pathMod.basename(pp.tpl).replace(/\.mogrt$/i, ''), file: pp.tpl });
      sel.innerHTML = '';
      if (!list.length) { sel.appendChild(h('option', { value: '', text: I18N.tr('Шаблонов пока нет') })); return; }
      list.forEach(function (t) { sel.appendChild(h('option', { value: t.file, text: t.name })); });
      if (!pp.tpl || !list.some(function (t) { return t.file === pp.tpl; })) { pp.tpl = list[0].file; saveCfg(); }
      sel.value = pp.tpl;
    }
    sel.addEventListener('change', function () { pp.tpl = sel.value; saveCfg(); });
    $('ppRefresh').addEventListener('click', function () { paint(); setStatus('', I18N.tr('Список шаблонов обновлён.')); });
    $('ppPick').addEventListener('click', function () {
      openDialog('Выбери шаблон .mogrt', ['mogrt']).then(function (p) { if (p) { pp.tpl = p; saveCfg(); paint(); } });
    });
    bindSeg($('ppOut'), function () { return pp.out; }, function (v) { pp.out = v; });
    paint();
  }

  /* ------------------------------------------------------------------ After Effects: экспорт стиля как .mogrt для Premiere */
  function waitForFile(file, ms) {
    return new Promise(function (resolve, reject) {
      var t0 = Date.now(), last = -1, same = 0;
      (function tick() {
        var sz = -1;
        try { sz = fs.statSync(file).size; } catch (e) { sz = -1; }
        if (sz > 0) {
          if (sz === last) { if (++same >= 3) return resolve(sz); } else { same = 0; last = sz; }
        }
        if (Date.now() - t0 > ms) return reject(new Error('Файл .mogrt не появился. Проверь, что в AE включено «Разрешить скриптам запись файлов» (Настройки → Scripting & Expressions), и попробуй ещё раз.'));
        setTimeout(tick, 400);
      })();
    });
  }

  function initMogrt() {
    var btn = $('btnMogrt');
    if (!btn || PPRO) return;
    var m = S.cfg.ui.mogrt, name = $('mgName'), size = $('mgSize'), anim = $('mgAnim');
    name.value = m.name || ''; size.value = m.size; anim.value = m.anim;
    name.addEventListener('change', function () { m.name = name.value.trim(); saveCfg(); });
    size.addEventListener('change', function () { m.size = size.value; saveCfg(); });
    anim.addEventListener('change', function () { m.anim = anim.value; saveCfg(); });
    function fail(e) { S.busy = false; btn.disabled = false; setStatus('err', e && e.message || String(e), 'mg'); }
    btn.addEventListener('click', function () {
      if (S.busy) return;
      var u = S.cfg.ui, nm = (name.value || '').trim() || 'SubLee', safe = nm.replace(/[\\/:*?"<>|]+/g, ' ').trim() || 'SubLee';
      var file = pathMod.join(mogrtDir(), safe + '.mogrt'), payload, fxp = null, ctx;
      if (m.anim === 'fx') {
        FX_PRESETS.forEach(function (p) { if (p.id === u.fx.last) fxp = p; });
        if (!fxp) { setStatus('err', 'Сначала выбери анимацию во вкладке «Кастом».', 'mg'); return; }
      }
      S.busy = true; btn.disabled = true;
      setStatus('busy', 'Собираю шаблон в After Effects…', 'mg');
      try { fs.mkdirSync(mogrtDir(), { recursive: true }); if (fs.existsSync(file)) fs.unlinkSync(file); } catch (e0) { /* ignore */ }
      host('getContext').then(function (c) {
        ctx = c;
        var wh = m.size === 'comp' ? [c.comp.width, c.comp.height] : m.size.split('x').map(function (x) { return parseInt(x, 10); });
        payload = {
          name: nm, file: file, text: u.style.uppercase ? 'SUBTITLE' : 'Subtitle', width: wh[0], height: wh[1], fps: Math.round(c.comp.fps) || 30, duration: 4,
          style: u.style, layout: { pos: u.pos, y: u.yPct, safe: u.custom.safe },
          inFrames: m.anim === 'fx' ? u.fx.inF : (m.anim === 'anim' ? u.anim.frames : 12), outFrames: m.anim === 'fx' ? u.fx.outF : 10
        };
        if (m.anim === 'anim' && u.anim.preset !== 'none') payload.anim = animPayload(u.anim, false);
        if (m.anim === 'fx') payload.fx = { spec: fxp.spec, mode: u.fx.mode, inFrames: u.fx.inF, outFrames: u.fx.outF, power: u.fx.power, selectedOnly: false };
        return host('exportMogrt', payload);
      }).then(function (r) {
        setStatus('busy', 'Экспортирую .mogrt (до минуты)…', 'mg');
        return waitForFile(file, 90000).then(function (sz) {
          var head = fs.readFileSync(file).slice(0, 2).toString('latin1');
          if (head !== 'PK') throw new Error('Получился неверный файл .mogrt. Попробуй ещё раз.');
          fs.writeFileSync(file.replace(/\.mogrt$/i, '.json'), JSON.stringify({ name: nm, uppercase: !!u.style.uppercase, anim: m.anim, created: new Date().toISOString() }, null, 2), 'utf8');
          return host('exportMogrtCleanup', { prevId: r.prevId }).catch(function () {}).then(function () { return r; });
        });
      }).then(function (r) {
        S.busy = false; btn.disabled = false;
        setStatus('ok', 'Шаблон готов: ' + pathMod.basename(file) + ' ✨' + (r.warnings && r.warnings.length ? '\nПредупреждения: ' + r.warnings.join(', ') : '') + '\nОткрой Premiere: панель SubLee → «Шаблон субтитров».', 'mg');
      }).catch(fail);
    });
  }

  /* ------------------------------------------------------------------ проверка текста */
  function reviewSets(sets) {
    return new Promise(function (resolve) {
      var data = clone(sets), cur = 0, ov = $('review');
      function paintTabs() {
        var box = $('rvLangs'); box.innerHTML = '';
        if (data.length < 2) return;
        data.forEach(function (s, i) {
          var b = h('button', { class: i === cur ? 'on' : '', text: langTag(s.lang) + ' (' + s.captions.length + ')' });
          b.addEventListener('click', function () { cur = i; paint(); });
          box.appendChild(b);
        });
      }
      function paint() {
        paintTabs();
        var list = $('rvList'), caps = data[cur].captions;
        list.innerHTML = '';
        $('rvCount').textContent = caps.length + ' подписей';
        caps.forEach(function (c, i) {
          var tS = h('input', { type: 'text', value: Core.fmtShort(c.start), title: 'Начало' });
          var tE = h('input', { type: 'text', value: Core.fmtShort(c.end), title: 'Конец' });
          tS.addEventListener('change', function () { var v = Core.parseShort(tS.value); if (!isNaN(v)) c.start = v; tS.value = Core.fmtShort(c.start); });
          tE.addEventListener('change', function () { var v = Core.parseShort(tE.value); if (!isNaN(v) && v > c.start) c.end = v; tE.value = Core.fmtShort(c.end); });
          var ta = h('textarea', { rows: String(Math.max(1, c.text.split('\n').length)) });
          ta.value = c.text;
          ta.addEventListener('input', function () { c.text = ta.value; });
          var del = h('button', { title: 'Удалить', text: '×' });
          del.addEventListener('click', function () { caps.splice(i, 1); paint(); });
          var merge = h('button', { title: 'Склеить со следующей', text: '⇣' });
          merge.addEventListener('click', function () {
            if (i + 1 >= caps.length) return;
            var n = caps[i + 1]; c.text = (c.text + ' ' + n.text).replace(/\n/g, ' '); c.end = n.end; caps.splice(i + 1, 1); paint();
          });
          list.appendChild(h('div', { class: 'rv-row' }, [
            h('div', { class: 'rv-time' }, [tS, tE]), ta, h('div', { class: 'rv-act' }, [del, merge])
          ]));
        });
      }
      function close(result) { ov.classList.remove('on'); $('rvOk').onclick = $('rvCancel').onclick = null; resolve(result); }
      $('rvOk').onclick = function () { close(data); };
      $('rvCancel').onclick = function () { close(null); };
      paint();
      ov.classList.add('on');
    });
  }

  /* ------------------------------------------------------------------ кнопки низа */
  function initActions() {
    $('btnCancel').addEventListener('click', function () { if (Engine) Engine.cancel(); });
    $('btnSelect').addEventListener('click', function () {
      host('selectAll').then(function (r) {
        setStatus(r.count ? 'ok' : '', r.count ? 'Выделено слоёв: ' + r.count : 'В этой композиции нет слоёв SubLee');
      }).catch(function (e) { setStatus('err', e.message); });
    });
    $('btnPunct').addEventListener('click', function () {
      host('stripPunct', { selectedOnly: true }).then(function (r) {
        setStatus(r.count ? 'ok' : '', r.count ? 'Убрана пунктуация в ' + r.count + ' слоях' : 'Нет слоёв SubLee');
      }).catch(function (e) { setStatus('err', e.message); });
    });
    var armed = null, del = $('btnDelete');
    del.addEventListener('click', function () {
      if (!armed) {
        del.classList.add('arm'); del.lastChild.textContent = ' Точно удалить?';
        armed = setTimeout(disarm, 3000); return;
      }
      disarm();
      host(PPRO ? 'ppDeleteAll' : 'deleteAll', {}).then(function (r) {
        setStatus(r.count ? 'ok' : '', r.count ? 'Удалено слоёв: ' + r.count + ' (Ctrl+Z вернёт)' : 'Нечего удалять');
      }).catch(function (e) { setStatus('err', e.message); });
    });
    function disarm() { clearTimeout(armed); armed = null; del.classList.remove('arm'); del.lastChild.textContent = ' Удалить все'; }

    $('btnImport').addEventListener('click', importSRT);
    $('btnExport').addEventListener('click', exportSRT);
  }

  function importSRT() {
    if (S.busy) return;
    openDialog('Выбери файл субтитров', ['srt']).then(function (p) {
      if (!p) return;
      var caps = Core.parseSRT(fs.readFileSync(p, 'utf8'));
      if (!caps.length) throw new Error('В файле не нашлось подписей (формат SRT).');
      var lang = S.cfg.ui.langs[0];
      if (S.cfg.ui.noPunct) caps.forEach(function (c) { c.text = Core.stripPunct(c.text); });
      var sets = [{ lang: lang, captions: caps }];
      var step = S.cfg.ui.review ? reviewSets(sets) : Promise.resolve(sets);
      return step.then(function (res) {
        if (!res) { setStatus('', 'Отменено.'); return; }
        setStatus('busy', 'Создаю слои…');
        return PPRO ? createInPremiere(res) : createInAE(res);
      });
    }).catch(function (e) { setStatus('err', e.message); });
  }

  function exportSRT() {
    host('getCaptions').then(function (r) {
      if (!r.captions.length) throw new Error('В композиции нет субтитров SubLee.');
      var byLang = {};
      r.captions.forEach(function (c) { (byLang[c.lang] = byLang[c.lang] || []).push(c); });
      var langs = Object.keys(byLang);
      var name = (S.lastCtx && S.lastCtx.comp.name || 'subtitles').replace(/[\\/:*?"<>|]/g, '_');
      return saveDialog('Сохранить SRT', name + '.srt', ['srt']).then(function (p) {
        if (!p) return;
        p = String(p).replace(/\.srt$/i, '');
        var written = [];
        langs.forEach(function (l) {
          var file = langs.length > 1 ? p + '.' + l + '.srt' : p + '.srt';
          fs.writeFileSync(file, Core.toSRT(byLang[l]), 'utf8');
          written.push(pathMod.basename(file));
        });
        setStatus('ok', 'Сохранено: ' + written.join(', '));
      });
    }).catch(function (e) { setStatus('err', e.message); });
  }

  /* ------------------------------------------------------------------ язык интерфейса */
  function initUiLang() {
    var groups = [$('uiLangHead'), $('segUiLang')];
    function paint() {
      groups.forEach(function (g) { $$('button', g).forEach(function (b) { b.classList.toggle('on', b.dataset.l === S.cfg.ui.uiLang); }); });
    }
    groups.forEach(function (g) {
      $$('button', g).forEach(function (b) {
        b.addEventListener('click', function () {
          S.cfg.ui.uiLang = I18N.setLang(b.dataset.l);
          paint(); updateLangUI(); saveCfg();
          if (window.SubLeeUpdate) window.SubLeeUpdate.clearLog();   // список изменений перерисуется на новом языке при открытии
        });
      });
    });
    paint();
  }

  /* ------------------------------------------------------------------ версия и «Что нового» */
  var VER = { version: '', log: [] };
  try {
    var verPath = nodeRequire.resolve(EXT + '/version.json');
    if (nodeRequire.cache) delete nodeRequire.cache[verPath];
    VER = nodeRequire(EXT + '/version.json');
  } catch (e) { /* без файла версии плашка просто не показывается */ }

  function initVersion() {
    var u = S.cfg.ui, pill = $('verPill'), ban = $('updBanner'), wn = $('whatsnew'), U = { avail: null, busy: false, err: '' };
    if (!VER.version) { pill.style.display = 'none'; return; }
    function langIdx() { return { ru: 0, en: 1, kk: 2 }[I18N.getLang()] || 0; }
    function isNew() { return u.seenVersion !== VER.version; }
    function url() { return (u.updateUrl || VER.updateUrl || '').trim(); }
    function paint() {
      $('verTxt').textContent = 'v' + VER.version;
      var show = !!U.busy || (ban.dataset.closed !== '1' && (!!U.avail || isNew()));
      pill.classList.toggle('new', !!U.avail || isNew());
      ban.hidden = !show;
      ban.classList.toggle('upd', !!U.avail);
      $('updTxt').textContent = U.busy ? U.busy
        : (U.err ? 'Не удалось обновить: ' + U.err
        : (U.avail ? 'Доступно обновление v' + U.avail.version + ' · нажми, чтобы обновить'
        : 'Обновлено до v' + VER.version + ' · Что нового'));
      $('wnUpd').hidden = !U.avail || !!U.busy;
      $('wnUpd').textContent = U.avail ? 'Обновить до v' + U.avail.version : '';
    }
    function markSeen() { if (u.seenVersion !== VER.version) { u.seenVersion = VER.version; saveCfg(); } ban.dataset.closed = '1'; paint(); }
    function stat(msg) { $('wnStat').textContent = msg || ''; }
    function check(manual) {
      if (!Engine) { if (manual) stat('Движок не загружен: ' + bootError); return Promise.resolve(); }
      if (!url()) { if (manual) stat('Адрес обновлений не задан (Настройки → Обновления)'); return Promise.resolve(); }
      if (manual) stat('Проверяю…');
      return Engine.checkUpdate(url(), VER.version).then(function (r) {
        U.avail = r.newer ? r : null; U.err = '';
        if (r.newer) ban.dataset.closed = '';   // нашлась новая версия — показываем кнопку заново
        if (manual) stat(r.newer ? 'Доступна версия v' + r.version : 'Обновлений нет: у тебя последняя версия v' + VER.version);
        paint();
      }).catch(function (e) { if (manual) stat('Не удалось проверить обновления: ' + (e && e.message || e)); });
    }
    function install() {
      if (!U.avail || U.busy) return;
      U.err = ''; ban.dataset.closed = ''; U.busy = 'Скачиваю обновление…'; paint(); stat('');
      Engine.installUpdate(U.avail).then(function (r) {
        U.busy = r.restart ? 'Готово! Перезапусти After Effects, чтобы закончить обновление.' : 'Готово! Перезагружаю панель…'; paint();
        if (!r.restart) setTimeout(function () { try { window.location.reload(); } catch (e) { /* ignore */ } }, 900);
      }).catch(function (e) { U.busy = false; U.err = (e && e.message) || String(e); paint(); stat('Не удалось обновить: ' + U.err); });
    }
    function openLog() {
      var box = $('wnList'), i = langIdx();
      box.innerHTML = '';
      VER.log.forEach(function (e, n) {
        box.appendChild(h('div', { class: 'wn-v' }, ['v' + e.v, n === 0 ? h('em', { text: i === 0 ? 'сейчас' : I18N.tr('сейчас', I18N.getLang()) }) : '']));
        box.appendChild(h('ul', {}, e.items.map(function (it) { return h('li', { text: it[i] || it[0] }); })));
      });
      $('wnVer').textContent = 'v' + VER.version;
      stat(url() ? '' : 'Адрес обновлений не задан (Настройки → Обновления)');
      wn.classList.add('on');
      if (!U.avail) markSeen();
    }
    pill.addEventListener('click', openLog);
    ban.addEventListener('click', function (ev) {
      if (ev.target.id === 'updX') { U.err = ''; if (!U.avail && !U.busy) markSeen(); else { ban.dataset.closed = '1'; paint(); } return; }
      if (U.avail) install(); else openLog();
    });
    $('wnOk').addEventListener('click', function () { wn.classList.remove('on'); });
    $('wnCheck').addEventListener('click', function () { check(true); });
    $('wnUpd').addEventListener('click', function () { wn.classList.remove('on'); install(); });
    // настройки
    var fUrl = $('stUpdUrl'), fAuto = $('stUpdAuto');
    fUrl.value = u.updateUrl || ''; fAuto.checked = u.updateAuto !== false;
    fUrl.addEventListener('change', function () { u.updateUrl = fUrl.value.trim(); saveCfg(); U.avail = null; paint(); if (u.updateAuto !== false) check(false); });
    fAuto.addEventListener('change', function () { u.updateAuto = fAuto.checked; saveCfg(); });
    paint();
    if (u.updateAuto !== false && url()) setTimeout(function () { check(false); }, 1200);
    window.SubLeeUpdate = { check: check, install: install, state: U, clearLog: function () { $('wnList').innerHTML = ''; paint(); } };
  }

  /* ------------------------------------------------------------------ старт */
  function init() {
    loadCfg();
    document.documentElement.setAttribute('data-host', HOST);
    applyTheme();
    // свежий host.jsx при каждом открытии панели: правки скрипта AE подхватываются без перезапуска After Effects
    try { cs.evalScript('try{$.evalFile(new File("' + String(EXT).replace(/\\/g, '/').replace(/"/g, '\\"') + '/jsx/host.jsx"));}catch(e){}', function () {}); } catch (e) { /* не критично */ }
    S.cfg.ui.uiLang = I18N.setLang(S.cfg.ui.uiLang || 'ru');
    initTabs(); initAcc(); initToggles(); initLang(); initFont(); initModes();
    initStyles(); initQuickSize(); initAnim(); initFx(); initSettings(); initThemes(); initMotion(); initScale(); initHoverPreview(); initUiLang(); initVersion(); initActions();
    if (PPRO) initPremiere(); else initMogrt();
    if (bootError) setStatus('err', 'Не удалось загрузить движок: ' + bootError);
    else setStatus('', 'Выдели клип на таймлайне и жми «Сделать субтитры» \uD83D\uDC46');
  }

  window.SubFlowApp = { S: S, runMode: runMode, host: host, Core: Core, Engine: Engine, applyAeSkin: applyAeSkin, HOST: HOST, listTemplates: listTemplates };   // для отладки и тестов
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
