/*
 * SubFlow engine (Node.js внутри CEP-панели).
 *  - ffmpeg: достаёт аудио из выбранного клипа
 *  - распознавание: локальный whisper.cpp ИЛИ OpenAI API (whisper-1)
 *  - перевод субтитров: OpenAI-совместимый чат ИЛИ Anthropic API
 */
'use strict';

var fs = require('fs');
var path = require('path');
var os = require('os');
var cp = require('child_process');
var https = require('https');
var http = require('http');
var URL = require('url').URL;
var Core = require('./core.js');
var Secrets = require('./secrets.js');

var IS_WIN = process.platform === 'win32';
var EXT_ROOT = path.resolve(__dirname, '..');

var DEFAULTS = {
  engine: 'local',                       // 'local' | 'openai'
  ffmpegPath: '',
  whisperPath: '',
  modelPath: '',
  threads: 0,
  wordTiming: 'precise',                 // 'precise' (-ml 1 -sow) | 'fast' (по сегментам)
  openaiKey: '',
  openaiBase: 'https://api.openai.com/v1',
  openaiSttModel: 'whisper-1',
  trProvider: 'anthropic',               // 'anthropic' | 'openai'
  anthropicKey: '',
  anthropicBase: 'https://api.anthropic.com',
  anthropicModel: 'claude-sonnet-5-5',
  openaiChatModel: 'gpt-4o-mini',
  anthropicModel2: '',                   // запасная модель: если основная перегружена
  openaiChatModel2: ''
};

/* ------------------------------------------------------------------ отмена */
var active = { procs: [], reqs: [], cancelled: false };

function begin() { active.cancelled = false; active.procs = []; active.reqs = []; }
function cancelError() { var e = new Error('Отменено'); e.cancelled = true; return e; }
function checkCancel() { if (active.cancelled) throw cancelError(); }
function cancel() {
  active.cancelled = true;
  active.procs.forEach(function (p) { try { p.kill(); } catch (e) { /* уже завершён */ } });
  active.reqs.forEach(function (r) { try { r.destroy(); } catch (e) { /* ignore */ } });
}

/* ------------------------------------------------------------------ поиск бинарников */
function isFile(p) { try { return fs.statSync(p).isFile(); } catch (e) { return false; } }
function isAscii(s) { return /^[\x00-\x7F]*$/.test(s); }

function findInTree(dir, names, depth) {
  var list;
  try { list = fs.readdirSync(dir); } catch (e) { return null; }
  for (var i = 0; i < list.length; i++) {
    if (names.indexOf(list[i].toLowerCase()) >= 0 && isFile(path.join(dir, list[i]))) return path.join(dir, list[i]);
  }
  if (depth > 0) {
    for (i = 0; i < list.length; i++) {
      var sub = path.join(dir, list[i]);
      try { if (!fs.statSync(sub).isDirectory()) continue; } catch (e) { continue; }
      var r = findInTree(sub, names, depth - 1);
      if (r) return r;
    }
  }
  return null;
}

function findBinary(baseNames, configured, extraDirs) {
  if (configured && isFile(configured)) return configured;
  var names = baseNames.map(function (n) { return (IS_WIN ? n + '.exe' : n).toLowerCase(); });
  var r = findInTree(path.join(EXT_ROOT, 'bin'), names, 3);
  if (r) return r;
  var dirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
  if (IS_WIN) {
    dirs = dirs.concat(['C:\\ffmpeg\\bin', 'C:\\Program Files\\ffmpeg\\bin', 'C:\\whisper.cpp', 'C:\\whisper']);
  } else {
    dirs = dirs.concat(['/opt/homebrew/bin', '/usr/local/bin', '/usr/bin']);
  }
  (extraDirs || []).forEach(function (d) { dirs.push(d); });
  for (var i = 0; i < dirs.length; i++) {
    r = findInTree(dirs[i], names, 0);
    if (r) return r;
  }
  return null;
}

function findFfmpeg(S) { return findBinary(['ffmpeg'], S && S.ffmpegPath); }
function findWhisper(S) { return findBinary(['whisper-cli', 'whisper-cpp'], S && S.whisperPath); }

var MODEL_PREF = ['large-v3-q5_0', 'large-v3.', 'large-v3-turbo-q5_0', 'large-v3-turbo', 'large-v2', 'medium-q5_0', 'medium', 'small', 'base', 'tiny'];

function modelDirs() {
  var home = os.homedir();
  var d = [path.join(EXT_ROOT, 'bin'), path.join(EXT_ROOT, 'models'), path.join(home, '.subflow', 'models')];
  if (process.platform === 'darwin') d.push(path.join(home, 'Library', 'Application Support', 'SubFlow', 'models'));
  if (IS_WIN) d.push('C:\\whisper\\models', 'C:\\whisper.cpp\\models');
  return d;
}

function findModel(S) {
  if (S && S.modelPath && isFile(S.modelPath)) return S.modelPath;
  var found = [];
  modelDirs().forEach(function (dir) {
    var list;
    try { list = fs.readdirSync(dir); } catch (e) { return; }
    list.forEach(function (f) {
      if (/^ggml-.*\.bin$/i.test(f) && !/encoder|silero|vad/i.test(f)) found.push(path.join(dir, f));
    });
  });
  if (!found.length) return null;
  function rank(p) {
    var n = path.basename(p).toLowerCase();
    for (var i = 0; i < MODEL_PREF.length; i++) if (n.indexOf(MODEL_PREF[i]) >= 0) return i;
    return 99;
  }
  found.sort(function (a, b) { return rank(a) - rank(b); });
  return found[0];
}

function diagnose(S) {
  S = Object.assign({}, DEFAULTS, S);
  return {
    ffmpeg: findFfmpeg(S),
    whisper: findWhisper(S),
    model: findModel(S),
    openaiKey: !!S.openaiKey,
    anthropicKey: !!S.anthropicKey
  };
}

/* ------------------------------------------------------------------ процессы и файлы */
function run(cmd, args, o) {
  o = o || {};
  return new Promise(function (resolve, reject) {
    var p;
    try { p = cp.spawn(cmd, args, { cwd: o.cwd, windowsHide: true }); } catch (e) { return reject(e); }
    active.procs.push(p);
    var out = '', err = '';
    p.stdout.setEncoding('utf8');
    p.stderr.setEncoding('utf8');
    p.stdout.on('data', function (d) { out = (out + d).slice(-20000); if (o.onStdout) o.onStdout(d); });
    p.stderr.on('data', function (d) { err = (err + d).slice(-20000); if (o.onStderr) o.onStderr(d); });
    p.on('error', reject);
    p.on('close', function (code) {
      if (active.cancelled) return reject(cancelError());
      resolve({ code: code, stdout: out, stderr: err });
    });
  });
}

function mkWorkDir() {
  var bases = [os.tmpdir()];
  if (IS_WIN) bases.push(path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'SubFlowTmp'));
  else bases.push('/tmp');
  var pick = null, i;
  for (i = 0; i < bases.length && !pick; i++) if (isAscii(bases[i])) pick = bases[i];   // whisper.cpp на Windows не любит кириллицу в путях
  if (!pick) pick = bases[0];
  try { fs.mkdirSync(pick, { recursive: true }); } catch (e) { /* ignore */ }
  return fs.mkdtempSync(path.join(pick, 'sf-'));
}

function rmrf(p) {
  try {
    if (fs.rmSync) fs.rmSync(p, { recursive: true, force: true });
    else {
      fs.readdirSync(p).forEach(function (f) { try { fs.unlinkSync(path.join(p, f)); } catch (e) { /* ignore */ } });
      fs.rmdirSync(p);
    }
  } catch (e) { /* ignore */ }
}

/* ------------------------------------------------------------------ ffmpeg */
function probeDuration(ffmpeg, file) {
  return run(ffmpeg, ['-nostdin', '-hide_banner', '-i', file]).then(function (r) {
    var m = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(r.stderr);
    return m ? (+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3]) : 0;
  });
}

function extractAudio(ffmpeg, input, start, dur, out, fmt) {
  var args = ['-nostdin', '-y', '-hide_banner', '-loglevel', 'error'];
  if (start > 0) args.push('-ss', String(start));
  args.push('-i', input);
  if (dur > 0) args.push('-t', String(dur));
  args.push('-map', '0:a:0', '-vn', '-sn', '-dn', '-ac', '1', '-ar', '16000');
  if (fmt === 'mp3') args.push('-c:a', 'libmp3lame', '-b:a', '48k');
  else args.push('-c:a', 'pcm_s16le');
  args.push(out);
  return run(ffmpeg, args).then(function (r) {
    if (r.code !== 0) {
      if (/matches no streams|does not contain any stream|Output file does not contain/i.test(r.stderr))
        throw new Error('В этом файле нет звуковой дорожки.');
      throw new Error('ffmpeg не смог достать звук: ' + (r.stderr.trim().split('\n').pop() || 'код ' + r.code));
    }
    var size = 0;
    try { size = fs.statSync(out).size; } catch (e) { /* нет файла */ }
    if (size < 1000) throw new Error('В выбранном участке нет звука.');
  });
}

/* ------------------------------------------------------------------ локальный whisper.cpp */
function transcribeLocal(wavPath, workDir, o, S) {
  var whisper = findWhisper(S);
  if (!whisper) throw new Error('Не найден whisper-cli. Запусти установщик или укажи путь в «Настройки».');
  var model = findModel(S);
  if (!model) throw new Error('Не найдена модель whisper (ggml-*.bin). Скачай её или укажи путь в «Настройки».');

  var precise = S.wordTiming !== 'fast';
  var outBase = path.join(workDir, 'out');
  var outJson = outBase + '.json';

  function once(preciseMode) {
    var cwd = workDir, modelArg = model;
    if (!isAscii(model)) { cwd = path.dirname(model); modelArg = path.basename(model); }   // относительный путь = ASCII
    var args = ['-m', modelArg, '-f', wavPath, '-oj', '-of', outBase, '-pp', '-l', o.lang && o.lang !== 'auto' ? o.lang : 'auto'];
    if (S.threads > 0) args.push('-t', String(S.threads));
    if (preciseMode) args.push('-ml', '1', '-sow');
    try { fs.unlinkSync(outJson); } catch (e) { /* нет файла */ }
    return run(whisper, args, {
      cwd: cwd,
      onStderr: function (d) {
        var m, re = /progress\s*=\s*(\d+)%/g;
        while ((m = re.exec(d))) if (o.onProgress) o.onProgress(+m[1]);
      }
    }).then(function (r) {
      if (r.code !== 0 || !isFile(outJson))
        throw new Error('whisper-cli завершился с ошибкой (' + r.code + '): ' + r.stderr.trim().split('\n').slice(-2).join(' | '));
      var text = fs.readFileSync(outJson).toString('utf8');
      return { text: text, bad: text.indexOf('\uFFFD') >= 0 };
    });
  }

  return once(precise).then(function (r) {
    if (r.bad && precise) { precise = false; return once(false); }   // битый UTF-8 в пословном режиме — перезапуск по сегментам
    return r;
  }).then(function (r) {
    var parsed = Core.parseWhisperCpp(JSON.parse(r.text), precise);
    if (o.lang && o.lang !== 'auto') parsed.language = o.lang;
    return parsed;
  });
}

/* ------------------------------------------------------------------ HTTP */
function request(method, urlStr, headers, body, timeoutMs) {
  return new Promise(function (resolve, reject) {
    var u = new URL(urlStr);
    var lib = u.protocol === 'http:' ? http : https;
    var h = Object.assign({}, headers || {});
    if (body && !h['Content-Length']) h['Content-Length'] = Buffer.byteLength(body);
    var req = lib.request({
      method: method, hostname: u.hostname, port: u.port || (u.protocol === 'http:' ? 80 : 443),
      path: u.pathname + u.search, headers: h
    }, function (res) {
      var chunks = [];
      res.on('data', function (c) { chunks.push(c); });
      res.on('end', function () { resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString('utf8') }); });
    });
    req.setTimeout(timeoutMs || 600000, function () { req.destroy(new Error('Таймаут запроса к ' + u.hostname)); });
    req.on('error', function (e) { reject(active.cancelled ? cancelError() : e); });
    active.reqs.push(req);
    if (body) req.write(body);
    req.end();
  });
}

function apiError(res, what) {
  var msg = res.body;
  try { var j = JSON.parse(res.body); if (Array.isArray(j)) j = j[0] || {}; msg = (j.error && (j.error.message || j.error)) || j.message || msg; } catch (e) { /* не JSON */ }
  if (typeof msg !== 'string') msg = JSON.stringify(msg);
  var hint = res.status === 401 ? ' (проверь API-ключ в «Настройки»)' : (res.status === 429 ? ' (лимит запросов или нет денег на счёте)' : (res.status === 503 || res.status === 502 || res.status === 504 ? ' (сервер модели перегружен, это временно)' : ''));
  return new Error(what + ': HTTP ' + res.status + ' — ' + String(msg).slice(0, 300) + hint);
}

function multipart(fields, file) {
  var boundary = '----sf' + Date.now().toString(16) + Math.random().toString(16).slice(2);
  var bufs = [];
  fields.forEach(function (f) {
    bufs.push(Buffer.from('--' + boundary + '\r\nContent-Disposition: form-data; name="' + f[0] + '"\r\n\r\n' + f[1] + '\r\n'));
  });
  bufs.push(Buffer.from('--' + boundary + '\r\nContent-Disposition: form-data; name="file"; filename="' + file.filename +
    '"\r\nContent-Type: ' + file.type + '\r\n\r\n'));
  bufs.push(fs.readFileSync(file.path));
  bufs.push(Buffer.from('\r\n--' + boundary + '--\r\n'));
  return { type: 'multipart/form-data; boundary=' + boundary, body: Buffer.concat(bufs) };
}

/* ------------------------------------------------------------------ OpenAI распознавание */
function transcribeOpenAI(audioPath, o, S) {
  if (!S.openaiKey) throw new Error('Нет OpenAI API-ключа. Впиши его в «Настройки».');
  var fields = [['model', S.openaiSttModel || 'whisper-1'], ['response_format', 'verbose_json'],
    ['timestamp_granularities[]', 'word'], ['timestamp_granularities[]', 'segment']];
  if (o.lang && o.lang !== 'auto') fields.push(['language', o.lang]);
  var mp = multipart(fields, { filename: 'audio.mp3', type: 'audio/mpeg', path: audioPath });
  return request('POST', S.openaiBase.replace(/\/+$/, '') + '/audio/transcriptions', {
    Authorization: 'Bearer ' + S.openaiKey, 'Content-Type': mp.type
  }, mp.body, 900000).then(function (res) {
    if (res.status >= 400) throw apiError(res, 'OpenAI (распознавание)');
    var r = Core.parseOpenAI(JSON.parse(res.body));
    if (o.lang && o.lang !== 'auto') r.language = o.lang;
    return r;
  });
}


/* ------------------------------------------------------------------ смешанная речь: язык определяется для каждой фразы */
var MULTI_LANGS = ['ru', 'kk', 'en'];

function detectSilences(ffmpeg, wav) {
  var log = '';
  return run(ffmpeg, ['-nostdin', '-hide_banner', '-i', wav, '-af', 'silencedetect=noise=-33dB:d=0.3', '-f', 'null', '-'], {
    onStderr: function (d) { log += d; }
  }).then(function () {
    var out = [], re = /silence_(start|end):\s*(-?[\d.]+)/g, m, cur = null;
    while ((m = re.exec(log))) {
      if (m[1] === 'start') cur = Math.max(0, parseFloat(m[2]));
      else if (cur !== null) { out.push({ s: cur, e: parseFloat(m[2]) }); cur = null; }
    }
    return out;
  });
}

function transcribeMixed(o, S, ffmpeg, work, status, progress, start) {
  var wav = path.join(work, 'audio.wav'), chunks = [], words = [], i = 0, total = 0, openai = S.engine === 'openai';
  var allowed = o.langs && o.langs.length ? o.langs : MULTI_LANGS;

  function recog(f, lang) {
    if (openai) return transcribeOpenAI(f, { lang: lang }, S);
    return transcribeLocal(f, work, { lang: lang }, S);
  }
  function next() {
    if (i >= chunks.length) return Promise.resolve();
    checkCancel();
    var c = chunks[i], f = path.join(work, 'm' + i + (openai ? '.mp3' : '.wav'));
    status('Определяю язык и распознаю… фраза ' + (i + 1) + '/' + chunks.length);
    progress(Math.round(100 * i / chunks.length));
    return extractAudio(ffmpeg, wav, c.s, c.d, f, openai ? 'mp3' : 'wav').then(function () {
      return recog(f, 'auto');
    }).then(function (r) {
      var lang = Core.mapLang(r.language, allowed);
      if (lang === Core.normLang(r.language)) { r.language = lang; return r; }
      return recog(f, lang).then(function (r2) { r2.language = lang; return r2; });   // язык вне списка → переделываем с ближайшим из своих
    }).then(function (r) {
      r.words.forEach(function (w) { words.push({ w: w.w, s: w.s + c.s, e: w.e + c.s, l: r.language }); });
    }, function (e) {
      if (e && e.cancelled) throw e;
      if (/нет звука/.test(String(e && e.message))) return;   // пустой кусок — пропускаем
      throw e;
    }).then(function () { i++; return next(); });
  }

  status('Достаю аудио…');
  return extractAudio(ffmpeg, o.input, start, o.duration, wav, 'wav').then(function () {
    return probeDuration(ffmpeg, wav);
  }).then(function (dur) {
    total = dur;
    status('Ищу паузы в речи…');
    return detectSilences(ffmpeg, wav);
  }).then(function (sil) {
    chunks = Core.planChunks(total, sil, { min: 3, max: 25 });
    if (!chunks.length) chunks = [{ s: 0, d: total }];
    return next();
  }).then(function () {
    progress(100);
    var sh = Core.langShares(words);
    return { language: sh.length ? sh[0].l : '', mixed: true, words: words, shares: sh };
  });
}

/* ------------------------------------------------------------------ высокоуровневое распознавание клипа */
var CHUNK = 600;   // сек, для API

/*
 * o: { input, start, duration, lang, settings, onStatus(text), onProgress(0..100) }
 * → { language, words[{w,s,e}] } со временем от начала вырезанного куска
 */
function transcribeClip(o) {
  begin();
  var S = Object.assign({}, DEFAULTS, o.settings);
  var ffmpeg = findFfmpeg(S);
  if (!ffmpeg) return Promise.reject(new Error('Не найден ffmpeg. Запусти установщик или укажи путь в «Настройки».'));
  if (!isFile(o.input)) return Promise.reject(new Error('Файл не найден: ' + o.input));
  var status = o.onStatus || function () {};
  var progress = o.onProgress || function () {};
  var work = mkWorkDir();
  var start = o.start > 0 ? o.start : 0;

  function cleanup(v) { rmrf(work); return v; }
  function fail(e) { rmrf(work); throw e; }

  if (o.lang === 'multi') return transcribeMixed(o, S, ffmpeg, work, status, progress, start).then(cleanup, fail);

  if (S.engine === 'openai') {
    var total;
    return (o.duration > 0 ? Promise.resolve(o.duration) : probeDuration(ffmpeg, o.input).then(function (d) { return Math.max(0, d - start); }))
      .then(function (dur) {
        total = dur || CHUNK;
        var n = Math.max(1, Math.ceil(total / CHUNK));
        var words = [], language = '', i = 0;
        function next() {
          if (i >= n) return Promise.resolve();
          checkCancel();
          var cs = start + i * CHUNK, cd = Math.min(CHUNK, total - i * CHUNK);
          var f = path.join(work, 'c' + i + '.mp3');
          status('Распознаю (OpenAI)… часть ' + (i + 1) + '/' + n);
          progress(Math.round(100 * i / n));
          return extractAudio(ffmpeg, o.input, cs, cd, f, 'mp3')
            .then(function () { return transcribeOpenAI(f, o, S); })
            .then(function (r) {
              var off = i * CHUNK;
              r.words.forEach(function (w) { words.push({ w: w.w, s: w.s + off, e: w.e + off }); });
              if (!language) language = r.language;
              i++;
              return next();
            });
        }
        return next().then(function () { progress(100); return { language: language, words: words }; });
      }).then(cleanup, fail);
  }

  status('Достаю аудио…');
  var wav = path.join(work, 'audio.wav');
  return extractAudio(ffmpeg, o.input, start, o.duration, wav, 'wav')
    .then(function () {
      status('Распознаю (Whisper локально)…');
      return transcribeLocal(wav, work, {
        lang: o.lang,
        onProgress: function (p) { progress(p); status('Распознаю (Whisper локально)… ' + p + '%'); }
      }, S);
    }).then(cleanup, fail);
}


/* ------------------------------------------------------------------ обновление плагина по клику */
function getUrl(urlStr, dest, depth) {
  depth = depth || 0;
  return new Promise(function (resolve, reject) {
    var u;
    try { u = new URL(urlStr); } catch (e) { return reject(new Error('Неверный адрес обновлений.')); }
    if (!/^https?:$/.test(u.protocol)) return reject(new Error('Неверный адрес обновлений.'));
    var lib = u.protocol === 'http:' ? http : https;
    var req = lib.get({
      hostname: u.hostname, port: u.port || (u.protocol === 'http:' ? 80 : 443), path: u.pathname + u.search,
      headers: { 'User-Agent': 'SubLee-updater', 'Cache-Control': 'no-cache' }
    }, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        if (depth > 5) return reject(new Error('Слишком много перенаправлений при скачивании.'));
        return resolve(getUrl(new URL(res.headers.location, urlStr).toString(), dest, depth + 1));
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('Не удалось скачать обновление: HTTP ' + res.statusCode)); }
      if (dest) {
        var out = fs.createWriteStream(dest);
        res.pipe(out);
        out.on('finish', function () { resolve({ file: dest }); });
        out.on('error', reject);
        res.on('error', reject);
      } else {
        var chunks = [];
        res.on('data', function (c) { chunks.push(c); });
        res.on('end', function () { resolve({ body: Buffer.concat(chunks).toString('utf8') }); });
        res.on('error', reject);
      }
    });
    req.setTimeout(dest ? 120000 : 10000, function () { req.destroy(new Error('Сервер обновлений не отвечает.')); });
    req.on('error', function (e) { reject(active.cancelled ? cancelError() : e); });
    active.reqs.push(req);
  });
}

/* update.json: { "version": "1.7.0", "zip": "SubLee-update.zip" (адрес относительно update.json или полный), "restart": false } */
function checkUpdate(url, currentVersion) {
  return getUrl(url).then(function (r) {
    var info;
    try { info = JSON.parse(r.body); } catch (e) { throw new Error('Файл обновления прочитать не удалось (ожидается update.json).'); }
    if (!info || !/^\d+(\.\d+){0,3}$/.test(String(info.version || ''))) throw new Error('В файле обновления нет номера версии.');
    var zip = new URL(info.zip || 'SubLee-update.zip', url).toString();
    return { version: String(info.version), zip: zip, restart: !!info.restart, newer: Core.cmpVer(info.version, currentVersion) > 0 };
  });
}

function mkdirp(dir) {
  if (isDir(dir)) return;
  mkdirp(path.dirname(dir));
  try { fs.mkdirSync(dir); } catch (e) { if (!isDir(dir)) throw e; }
}
function isDir(p) { try { return fs.statSync(p).isDirectory(); } catch (e) { return false; } }

function extractZip(zip, dir) {
  mkdirp(dir);
  function q(s) { return "'" + String(s).replace(/'/g, "''") + "'"; }
  var job = IS_WIN
    ? run('powershell', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', 'Expand-Archive -LiteralPath ' + q(zip) + ' -DestinationPath ' + q(dir) + ' -Force'])
    : run('unzip', ['-qo', zip, '-d', dir]);
  return job.then(function (r) {
    if (r.code !== 0) throw new Error('Не удалось распаковать обновление: ' + (r.stderr.trim().split('\n').pop() || 'код ' + r.code));
  });
}

// копируем новые файлы поверх старых; перед заменой старый файл откладываем в backup — при ошибке всё возвращается
function copyOver(src, dst, backup, skipTop, rel, done) {
  fs.readdirSync(src).forEach(function (name) {
    if (!rel && skipTop.indexOf(name) >= 0) return;
    var s = path.join(src, name), d = path.join(dst, name), b = path.join(backup, rel || '', name), r = (rel ? rel + '/' : '') + name;
    if (isDir(s)) { mkdirp(d); copyOver(s, d, backup, skipTop, r, done); return; }
    if (isFile(d)) { mkdirp(path.dirname(b)); fs.copyFileSync(d, b); done.push({ d: d, b: b, had: true }); }
    else done.push({ d: d, had: false });
    fs.copyFileSync(s, d);
  });
}

function installUpdate(info, target) {
  begin();
  target = target || EXT_ROOT;
  var work = mkWorkDir(), zip = path.join(work, 'update.zip'), out = path.join(work, 'x'), done = [];
  function cleanup(v) { rmrf(work); return v; }
  function fail(e) { rmrf(work); throw e; }
  return getUrl(info.zip, zip).then(function () {
    var size = 0;
    try { size = fs.statSync(zip).size; } catch (e) { /* нет файла */ }
    if (size < 1000) throw new Error('Файл обновления повреждён или пуст.');
    return extractZip(zip, out);
  }).then(function () {
    var root = isFile(path.join(out, 'index.html')) ? out : path.join(out, 'SubFlow');
    if (!isFile(path.join(root, 'index.html')) || !isFile(path.join(root, 'js', 'app.js')))
      throw new Error('В архиве нет папки SubFlow с панелью.');
    var nv = '';
    try { nv = JSON.parse(fs.readFileSync(path.join(root, 'version.json'), 'utf8')).version; } catch (e) { /* ignore */ }
    if (nv && info.version && nv !== info.version) throw new Error('Версия в архиве (' + nv + ') не совпадает с update.json (' + info.version + ').');
    try { copyOver(root, target, path.join(work, 'backup'), ['bin'], '', done); }
    catch (e) {
      done.slice().reverse().forEach(function (x) { try { if (x.had) fs.copyFileSync(x.b, x.d); else fs.unlinkSync(x.d); } catch (e2) { /* ignore */ } });
      throw new Error('Не удалось записать файлы обновления: ' + (e && e.message || e));
    }
    return { version: nv || info.version, files: done.length, restart: !!info.restart };
  }).then(cleanup, fail);
}

/* ------------------------------------------------------------------ перевод */
function buildPrompt(lines, from, to) {
  return 'You are a professional subtitle translator.\n' +
    'Translate every subtitle line below from ' + Core.langName(from) + ' to ' + Core.langName(to) + '.\n' +
    'Rules:\n' +
    '- Natural, concise spoken language suitable for on-screen subtitles; keep the meaning, tone and proper names.\n' +
    '- Keep numbers and Latin product names as they are.\n' +
    (to === 'kk' ? '- Write Kazakh in modern Kazakh Cyrillic using the letters ә, ғ, қ, ң, ө, ұ, ү, һ, і where needed.\n' : '') +
    '- Keep punctuation natural for the target language.\n' +
    '- Output exactly ' + lines.length + ' strings, one per input line, same order. Never merge or split lines.\n' +
    'Return ONLY a JSON array of strings — no comments, no markdown fences.\n\n' +
    'Input lines (JSON array):\n' + JSON.stringify(lines);
}

function parseArray(text, n) {
  var a = text.indexOf('['), b = text.lastIndexOf(']');
  if (a < 0 || b <= a) throw new Error('Модель вернула не JSON-массив');
  var arr = JSON.parse(text.slice(a, b + 1));
  if (!Array.isArray(arr)) throw new Error('Ответ не массив');
  arr = arr.map(function (x) { return String(x).trim(); });
  if (arr.length !== n) { var e = new Error('Количество строк не совпало: ' + arr.length + ' вместо ' + n); e.mismatch = true; throw e; }
  return arr;
}

/* основная модель или запасная (после того как основная не отвечала на повторы) */
function modelFor(S, key) { return S._state && S._state.fb && S[key + '2'] ? S[key + '2'] : S[key]; }

function callLLM(prompt, S) {
  if (S.trProvider === 'openai') {
    if (!S.openaiKey) return Promise.reject(new Error('Для перевода нужен OpenAI API-ключ (или выбери Anthropic в «Настройки»).'));
    return request('POST', S.openaiBase.replace(/\/+$/, '') + '/chat/completions', {
      Authorization: 'Bearer ' + S.openaiKey, 'Content-Type': 'application/json'
    }, JSON.stringify({ model: modelFor(S, 'openaiChatModel'), messages: [{ role: 'user', content: prompt }] }), 300000)
      .then(function (res) {
        if (res.status >= 400) throw apiError(res, 'OpenAI (перевод)');
        return JSON.parse(res.body).choices[0].message.content;
      });
  }
  if (!S.anthropicKey) return Promise.reject(new Error('Для перевода нужен Anthropic API-ключ (или выбери OpenAI в «Настройки»).'));
  return request('POST', S.anthropicBase.replace(/\/+$/, '') + '/v1/messages', {
    'x-api-key': S.anthropicKey, 'anthropic-version': '2023-06-01', 'Content-Type': 'application/json'
  }, JSON.stringify({ model: modelFor(S, 'anthropicModel'), max_tokens: 8192, messages: [{ role: 'user', content: prompt }] }), 300000)
    .then(function (res) {
      if (res.status >= 400) throw apiError(res, 'Anthropic (перевод)');
      var j = JSON.parse(res.body);
      return (j.content || []).map(function (c) { return c.text || ''; }).join('');
    });
}

function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

/* паузы (секунды) между повторами при перегрузке сервера или лимите запросов */
var RETRY_WAIT = [2, 4, 8, 15, 25, 40];

function translateBatch(lines, from, to, S, tries, net, cb) {
  checkCancel();
  net = net || 0; cb = cb || {};
  return callLLM(buildPrompt(lines, from, to), S).then(function (txt) {
    return parseArray(txt, lines.length);
  }).catch(function (e) {
    if (e.cancelled) throw e;
    if (e.mismatch || /JSON|массив/.test(e.message)) {
      if (lines.length > 1) {                                   // делим пополам и пробуем снова
        var h = Math.ceil(lines.length / 2);
        return translateBatch(lines.slice(0, h), from, to, S, 0, net, cb).then(function (a) {
          return translateBatch(lines.slice(h), from, to, S, 0, net, cb).then(function (b) { return a.concat(b); });
        });
      }
      if (tries < 2) return translateBatch(lines, from, to, S, tries + 1, net, cb);
    }
    if (/HTTP (429|5\d\d)|Таймаут|ECONNRESET/.test(e.message)) {
      if (net < RETRY_WAIT.length) {
        var wait = RETRY_WAIT[net];
        if (cb.retry) cb.retry(wait, net + 1, RETRY_WAIT.length);
        return sleep(wait * 1000 * (S.retryScale > 0 ? S.retryScale : 1)).then(function () { return translateBatch(lines, from, to, S, tries, net + 1, cb); });
      }
      var fb = S.trProvider === 'openai' ? S.openaiChatModel2 : S.anthropicModel2;
      if (fb && S._state && !S._state.fb) {                     // основная модель так и не ответила: переходим на запасную
        S._state.fb = true;
        if (cb.fallback) cb.fallback(fb);
        return translateBatch(lines, from, to, S, tries, 0, cb);
      }
    }
    throw e;
  });
}

/* texts[] → переведённые texts[] (та же длина). */
function translateTexts(texts, from, to, settings, onProgress, onRetry, onFallback) {
  begin();
  var S = Object.assign({}, DEFAULTS, settings), cb = { retry: onRetry, fallback: onFallback };
  S._state = { fb: false };
  var batches = [], cur = [], chars = 0;
  texts.forEach(function (t) {
    if (cur.length >= 30 || chars + t.length > 5000) { batches.push(cur); cur = []; chars = 0; }
    cur.push(t); chars += t.length;
  });
  if (cur.length) batches.push(cur);
  var out = [], i = 0;
  function next() {
    if (i >= batches.length) return Promise.resolve(out);
    if (onProgress) onProgress(Math.round(100 * i / batches.length));
    return translateBatch(batches[i], from, to, S, 0, 0, cb).then(function (r) { out = out.concat(r); i++; return next(); });
  }
  return next();
}

module.exports = {
  DEFAULTS: DEFAULTS, EXT_ROOT: EXT_ROOT,
  findFfmpeg: findFfmpeg, findWhisper: findWhisper, findModel: findModel, diagnose: diagnose,
  transcribeClip: transcribeClip, translateTexts: translateTexts,
  probeDuration: probeDuration, extractAudio: extractAudio,
  checkUpdate: checkUpdate, installUpdate: installUpdate,
  encryptSecret: Secrets.encryptSecret, decryptSecret: Secrets.decryptSecret,
  cancel: cancel, begin: begin
};
