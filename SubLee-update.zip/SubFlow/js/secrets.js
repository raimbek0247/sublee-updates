/*
 * Шифрование API-ключей в файле настроек (Node.js внутри CEP-панели).
 * AES-256-GCM; ключ шифра выводится (scrypt) из ID этого компьютера + имени пользователя ОС.
 * Файл настроек, отправленный другу, выложенный на GitHub или показанный на скриншоте,
 * без этого компьютера не расшифровать. От вредоносной программы, запущенной под твоим же
 * пользователем, это не защищает (как и любое локальное хранение без пароля).
 */
'use strict';

var crypto = require('crypto');
var os = require('os');
var fs = require('fs');
var cp = require('child_process');

var PREFIX = 'enc:v1:';
var cachedId = null;

function machineId() {
  if (cachedId) return cachedId;
  var id = '', m;
  try {
    if (process.platform === 'win32') {
      var out = cp.execFileSync('reg', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'],
        { encoding: 'utf8', windowsHide: true, timeout: 5000, stdio: ['ignore', 'pipe', 'ignore'] });
      m = /MachineGuid\s+REG_SZ\s+(\S+)/i.exec(out); if (m) id = m[1];
    } else if (process.platform === 'darwin') {
      var o = cp.execFileSync('ioreg', ['-rd1', '-c', 'IOPlatformExpertDevice'],
        { encoding: 'utf8', timeout: 5000, stdio: ['ignore', 'pipe', 'ignore'] });
      m = /"IOPlatformUUID"\s*=\s*"([^"]+)"/.exec(o); if (m) id = m[1];
    } else {
      ['/etc/machine-id', '/var/lib/dbus/machine-id'].forEach(function (p) {
        if (!id) { try { id = fs.readFileSync(p, 'utf8').trim(); } catch (e) { /* нет файла */ } }
      });
    }
  } catch (e) { id = ''; }
  var user = '';
  try { user = os.userInfo().username; } catch (e) { user = ''; }
  cachedId = [id || os.hostname(), user, process.platform].join('|');
  return cachedId;
}

function deriveKey(salt) { return crypto.scryptSync(machineId(), salt, 32); }

function isEncrypted(s) { return typeof s === 'string' && s.indexOf(PREFIX) === 0; }

function encryptSecret(plain) {
  if (!plain) return '';
  var salt = crypto.randomBytes(16), iv = crypto.randomBytes(12);
  var c = crypto.createCipheriv('aes-256-gcm', deriveKey(salt), iv);
  var ct = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  var tag = c.getAuthTag();
  return PREFIX + [salt, iv, tag, ct].map(function (b) { return b.toString('hex'); }).join(':');
}

/* → { value, ok, plain }  plain=true: в файле лежал открытый текст (старый формат); ok=false: не расшифровалось */
function decryptSecret(stored) {
  if (!stored) return { value: '', ok: true, plain: false };
  if (!isEncrypted(stored)) return { value: String(stored), ok: true, plain: true };
  try {
    var p = stored.slice(PREFIX.length).split(':');
    if (p.length !== 4) throw new Error('format');
    var b = p.map(function (x) { return Buffer.from(x, 'hex'); });
    var d = crypto.createDecipheriv('aes-256-gcm', deriveKey(b[0]), b[1]);
    d.setAuthTag(b[2]);
    return { value: Buffer.concat([d.update(b[3]), d.final()]).toString('utf8'), ok: true, plain: false };
  } catch (e) { return { value: '', ok: false, plain: false }; }
}

module.exports = { encryptSecret: encryptSecret, decryptSecret: decryptSecret, isEncrypted: isEncrypted, PREFIX: PREFIX };
