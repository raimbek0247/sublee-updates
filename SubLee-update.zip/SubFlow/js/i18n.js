/* SubLee — переводы интерфейса (RU / EN / KK).
 * Ключ — русский текст. Динамические сообщения с {подстановками} сопоставляются шаблонами.
 * В панели: SFI18n.setLang('en') переводит весь DOM (и всё, что приложение допишет позже).
 * Файл сгенерирован из словаря; правь строки в массиве DATA. */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.SFI18n = api;
})(typeof window !== 'undefined' ? window : this, function () {
  'use strict';

  var DATA = [
[
"накинем субтитры?",
"let's add subtitles?",
"субтитр қосамыз ба?"
],
[
"✨ Субтитры",
"✨ Subtitles",
"✨ Субтитрлер"
],
[
"🎨 Стили",
"🎨 Styles",
"🎨 Стильдер"
],
[
"🎬 Анимация",
"🎬 Animation",
"🎬 Анимация"
],
[
"Сделать субтитры",
"Make subtitles",
"Субтитр жасау"
],
[
"Слой на подпись",
"Layer per caption",
"Әр жазуға бір қабат"
],
[
"Один слой",
"Single layer",
"Бір қабат"
],
[
"Пре-комп",
"Pre-comp",
"Пре-комп"
],
[
"Проверка текста",
"Review text",
"Мәтінді тексеру"
],
[
"Шрифт",
"Font",
"Қаріп"
],
[
"Язык",
"Language",
"Тіл"
],
[
"Речь в видео",
"Speech in the video",
"Бейнедегі сөйлеу тілі"
],
[
"Авто",
"Auto",
"Авто"
],
[
"Субтитры на языках",
"Subtitle languages",
"Субтитр тілдері"
],
[
"(можно несколько)",
"(pick several if you like)",
"(бірнешеуін таңдауға болады)"
],
[
"Позиция",
"Position",
"Орны"
],
[
"По центру",
"Center",
"Ортада"
],
[
"Снизу",
"Bottom",
"Төменде"
],
[
"Сверху",
"Top",
"Жоғарыда"
],
[
"Дополнительно",
"More options",
"Қосымша"
],
[
"Откуда брать звук",
"Audio source",
"Дыбыс көзі"
],
[
"Выбрать файл…",
"Choose file…",
"Файлды таңдау…"
],
[
"выделенный слой в композиции",
"selected layer in the comp",
"композициядағы таңдалған қабат"
],
[
"Заменять прошлые субтитры (того же языка)",
"Replace previous subtitles (same language)",
"Алдыңғы субтитрлерді ауыстыру (сол тілдегі)"
],
[
"Сразу убрать пунктуацию",
"Remove punctuation right away",
"Тыныс белгілерін бірден алып тастау"
],
[
"Высота подписи, % от верха",
"Caption height, % from top",
"Жазу биіктігі, жоғарыдан %"
],
[
"(пусто = авто)",
"(empty = auto)",
"(бос = авто)"
],
[
"Показать / скрыть в композиции",
"Show / hide in comp",
"Композицияда көрсету / жасыру"
],
[
"слова, строки и безопасная зона",
"words, lines and safe area",
"сөздер, жолдар және қауіпсіз аймақ"
],
[
"Слов в подписи",
"Words per caption",
"Жазудағы сөздер"
],
[
"Строк",
"Lines",
"Жолдар"
],
[
"Символов в строке",
"Characters per line",
"Жолдағы таңбалар"
],
[
"(0 = авто)",
"(0 = auto)",
"(0 = авто)"
],
[
"Безопасная зона, %",
"Safe area, %",
"Қауіпсіз аймақ, %"
],
[
"Создать (Custom)",
"Create (Custom)",
"Жасау (Custom)"
],
[
"Выделить все",
"Select all",
"Бәрін таңдау"
],
[
"Пунктуация",
"Punctuation",
"Тыныс белгілері"
],
[
"Удалить все",
"Delete all",
"Бәрін жою"
],
[
"Импорт SRT",
"Import SRT",
"SRT импорттау"
],
[
"Экспорт SRT",
"Export SRT",
"SRT экспорттау"
],
[
"Отмена",
"Cancel",
"Бас тарту"
],
[
"Мои стили",
"My styles",
"Менің стильдерім"
],
[
"Сохранить новый",
"Save as new",
"Жаңасын сақтау"
],
[
"Обновить выбранный",
"Update selected",
"Таңдалғанды жаңарту"
],
[
"Удалить",
"Delete",
"Жою"
],
[
"Настрой стиль ниже (цвета, обводка, тень, плашка, шрифт со вкладки «Субтитры») и сохрани. Выбери свой стиль, поправь ползунки и нажми «Обновить выбранный» — он перезапишется.",
"Tweak the style below (colors, outline, shadow, box, and the font from the Subtitles tab) and save it. Pick your style, move the sliders and press “Update selected” to overwrite it.",
"Төмендегі стильді реттеп (түстер, контур, көлеңке, тақтайша, «Субтитрлер» қойындысындағы қаріп), сақтаңыз. Өз стиліңізді таңдап, жүгірткілерді жылжытыңыз да «Таңдалғанды жаңарту» батырмасын басыңыз — ол қайта жазылады."
],
[
"Размер, % от короткой стороны кадра",
"Size, % of the frame’s short side",
"Өлшемі, кадрдың қысқа жағынан %"
],
[
"Цвет текста",
"Text color",
"Мәтін түсі"
],
[
"Цвет обводки",
"Outline color",
"Контур түсі"
],
[
"Обводка",
"Outline",
"Контур"
],
[
"Толщина обводки",
"Outline width",
"Контур қалыңдығы"
],
[
"Тень / свечение",
"Shadow / glow",
"Көлеңке / жарқыл"
],
[
"Цвет тени",
"Shadow color",
"Көлеңке түсі"
],
[
"Непрозрачность",
"Opacity",
"Мөлдір еместік"
],
[
"Размытие",
"Blur",
"Бұлдырату"
],
[
"Смещение",
"Offset",
"Ығысу"
],
[
"Смещение 0 + большое размытие = свечение.",
"Offset 0 + big blur = glow.",
"Ығысу 0 + үлкен бұлдырату = жарқыл."
],
[
"ЗАГЛАВНЫЕ буквы",
"UPPERCASE",
"БАС ӘРІПТЕР"
],
[
"Трекинг",
"Tracking",
"Трекинг"
],
[
"Межстрочный",
"Line spacing",
"Жол аралығы"
],
[
"Плашка под текстом",
"Box behind text",
"Мәтін астындағы тақтайша"
],
[
"(только при создании)",
"(only when creating)",
"(тек жасау кезінде)"
],
[
"Цвет плашки",
"Box color",
"Тақтайша түсі"
],
[
"Прозрачность",
"Transparency",
"Мөлдірлік"
],
[
"Отступ по ширине",
"Horizontal padding",
"Ені бойынша шегініс"
],
[
"Отступ по высоте",
"Vertical padding",
"Биіктігі бойынша шегініс"
],
[
"Скругление",
"Roundness",
"Дөңгелектеу"
],
[
"К выделенным",
"To selected",
"Таңдалғандарға"
],
[
"Ко всем субтитрам",
"To all subtitles",
"Барлық субтитрге"
],
[
"Стиль также используется для новых субтитров. «ЗАГЛАВНЫЕ» при применении к готовым слоям необратимы — отмена через Ctrl+Z.",
"The style is also used for new subtitles. “UPPERCASE” on existing layers can only be undone with Ctrl+Z.",
"Стиль жаңа субтитрлер үшін де қолданылады. Дайын қабаттарға «БАС ӘРІПТЕР» қолдану тек Ctrl+Z арқылы қайтарылады."
],
[
"Bounce (выражения)",
"Bounce (expressions)",
"Bounce (өрнектер)"
],
[
"Колебание после появления. Выбери, что «пружинит»: позиция, масштаб, поворот — можно несколько сразу или по очереди разными типами.",
"Wobble after appearing. Choose what “springs”: position, scale, rotation — several at once or one by one with different types.",
"Пайда болғаннан кейінгі тербеліс. Нені «серпілту» керектігін таңдаңыз: орны, масштабы, бұрылуы — бірнешеуін бірден немесе түрлі типпен кезекпен."
],
[
"Амплитуда",
"Amplitude",
"Амплитуда"
],
[
"Частота",
"Frequency",
"Жиілік"
],
[
"Затухание",
"Decay",
"Өшу"
],
[
"Упругость отскока",
"Bounce elasticity",
"Секірудің серпімділігі"
],
[
"Применять при создании субтитров",
"Apply when creating subtitles",
"Субтитр жасағанда қолдану"
],
[
"Bounce It — к выделенным",
"Bounce It — to selected",
"Bounce It — таңдалғандарға"
],
[
"Если у свойства нет ключей, они создаются сами (длительность и «сила» — из настроек ниже). Выбор пресета «Нет» выше снимает всю анимацию, включая Bounce.",
"If a property has no keyframes, they are created automatically (duration and “strength” come from the settings below). Choosing the “None” preset above removes all animation, including Bounce.",
"Егер қасиетте кілт кадрлар болмаса, олар өздігінен жасалады (ұзақтығы мен «күші» төмендегі баптаулардан алынады). Жоғарыдағы «Жоқ» пресетін таңдау барлық анимацияны, соның ішінде Bounce-ты алып тастайды."
],
[
"Мои анимации",
"My animations",
"Менің анимацияларым"
],
[
"Сохранить новую",
"Save as new",
"Жаңасын сақтау"
],
[
"Обновить выбранную",
"Update selected",
"Таңдалғанды жаңарту"
],
[
"Сохраняется выбранный выше пресет вместе с длительностью, силой и исчезновением.",
"Saves the preset chosen above along with duration, strength and fade-out.",
"Жоғарыда таңдалған пресет ұзақтығымен, күшімен және жоғалуымен бірге сақталады."
],
[
"Длительность появления, кадров",
"Appear duration, frames",
"Пайда болу ұзақтығы, кадр"
],
[
"Сила анимации",
"Animation strength",
"Анимация күші"
],
[
"Анимация исчезновения тоже",
"Animate fade-out too",
"Жоғалу анимациясы да"
],
[
"Применять автоматически при создании",
"Apply automatically when creating",
"Жасағанда автоматты түрде қолдану"
],
[
"Работает в режиме «слой на подпись». Выбор «Нет» снимает анимацию.",
"Works in “layer per caption” mode. Choosing “None” removes the animation.",
"«Әр жазуға бір қабат» режимінде жұмыс істейді. «Жоқ» таңдау анимацияны алып тастайды."
],
[
"Оформление",
"Appearance",
"Безендіру"
],
[
"Распознавание речи",
"Speech recognition",
"Сөйлеуді тану"
],
[
"Локальный Whisper",
"Local Whisper",
"Жергілікті Whisper"
],
[
"(пусто = найти автоматически)",
"(empty = find automatically)",
"(бос = өздігінен табу)"
],
[
"Модель ggml-*.bin",
"Model ggml-*.bin",
"ggml-*.bin моделі"
],
[
"Потоков CPU",
"CPU threads",
"CPU ағындары"
],
[
"Тайминг слов",
"Word timing",
"Сөздердің уақыты"
],
[
"Точный (по словам)",
"Precise (per word)",
"Дәл (сөз бойынша)"
],
[
"Быстрый (по фразам)",
"Fast (per phrase)",
"Жылдам (фраза бойынша)"
],
[
"OpenAI API-ключ",
"OpenAI API key",
"OpenAI API кілті"
],
[
"Модель распознавания",
"Recognition model",
"Тану моделі"
],
[
"Перевод субтитров",
"Subtitle translation",
"Субтитр аудармасы"
],
[
"Anthropic API-ключ",
"Anthropic API key",
"Anthropic API кілті"
],
[
"Модель",
"Model",
"Модель"
],
[
"Модель чата (ключ — из блока выше)",
"Chat model (key is from the block above)",
"Чат моделі (кілт — жоғарыдағы блоктан)"
],
[
"Перевод нужен, только когда язык субтитров отличается от языка речи. Ключи хранятся в файле настроек на этом компьютере.",
"Translation is only needed when the subtitle language differs from the speech language. Keys are stored in the settings file on this computer.",
"Аударма тек субтитр тілі сөйлеу тілінен өзгеше болғанда керек. Кілттер осы компьютердегі баптау файлында сақталады."
],
[
"Проверить установку",
"Check installation",
"Орнатуды тексеру"
],
[
"Сохранить",
"Save",
"Сақтау"
],
[
"Создать слои",
"Create layers",
"Қабаттарды жасау"
],
[
"Настройки",
"Settings",
"Баптаулар"
],
[
"Один слой на все подписи или отдельный слой на каждую",
"One layer for all captions or a separate layer for each",
"Барлық жазуға бір қабат немесе әрқайсына бөлек қабат"
],
[
"Сбросить",
"Reset",
"Тастау"
],
[
"Поиск шрифта… или впиши PostScript-имя",
"Search font… or type a PostScript name",
"Қаріпті іздеу… немесе PostScript атауын жазыңыз"
],
[
"Вернуть: выделенный слой",
"Reset: selected layer",
"Қайтару: таңдалған қабат"
],
[
"авто",
"auto",
"авто"
],
[
"название стиля",
"style name",
"стиль атауы"
],
[
"Выражение на свойства, выделенные в таймлайне AE (у них уже должны быть ключи)",
"Puts the expression on properties selected in the AE timeline (they must already have keyframes)",
"AE таймлайнында таңдалған қасиеттерге өрнек қояды (оларда кілт кадрлар болуы керек)"
],
[
"название анимации",
"animation name",
"анимация атауы"
],
[
"путь к whisper-cli(.exe)",
"path to whisper-cli(.exe)",
"whisper-cli(.exe) жолы"
],
[
"путь к модели",
"path to model",
"модель жолы"
],
[
"путь к ffmpeg(.exe)",
"path to ffmpeg(.exe)",
"ffmpeg(.exe) жолы"
],
[
"По слову, как в шортсах",
"One word at a time, shorts style",
"Бір сөзден, шортс сияқты"
],
[
"Пара слов за раз",
"A couple of words at a time",
"Бір мезгілде екі сөз"
],
[
"Короткие фразы по смыслу",
"Short phrases by meaning",
"Мағына бойынша қысқа фразалар"
],
[
"Фразы подлиннее",
"Longer phrases",
"Ұзынырақ фразалар"
],
[
"Целые предложения",
"Whole sentences",
"Тұтас сөйлемдер"
],
[
"Классика",
"Classic",
"Классика"
],
[
"Жёлтый",
"Yellow",
"Сары"
],
[
"Плашка",
"Box",
"Тақтайша"
],
[
"Шорты",
"Shorts",
"Шортс"
],
[
"Неон",
"Neon",
"Неон"
],
[
"Мягкий",
"Soft",
"Жұмсақ"
],
[
"Контур",
"Outline",
"Контур"
],
[
"Крупный жёлтый",
"Big yellow",
"Үлкен сары"
],
[
"Красный контур",
"Red outline",
"Қызыл контур"
],
[
"Золото",
"Gold",
"Алтын"
],
[
"Тёмный текст",
"Dark text",
"Қою мәтін"
],
[
"Стикер",
"Sticker",
"Стикер"
],
[
"Фиолетовая",
"Violet",
"Күлгін"
],
[
"Маркер",
"Marker",
"Маркер"
],
[
"Подкаст",
"Podcast",
"Подкаст"
],
[
"Эфир",
"On air",
"Эфир"
],
[
"Стекло",
"Glass",
"Шыны"
],
[
"Ретро тень",
"Retro shadow",
"Ретро көлеңке"
],
[
"Свечение",
"Glow",
"Жарқыл"
],
[
"Зелёное свечение",
"Green glow",
"Жасыл жарқыл"
],
[
"Розовый неон",
"Pink neon",
"Қызғылт неон"
],
[
"Кино",
"Cinema",
"Кино"
],
[
"Нет",
"None",
"Жоқ"
],
[
"Плавно",
"Fade",
"Баяу"
],
[
"Поп",
"Pop",
"Поп"
],
[
"Пружина",
"Spring",
"Серіппе"
],
[
"Подъём",
"Rise",
"Көтерілу"
],
[
"Печать",
"Typewriter",
"Басып шығару"
],
[
"Удар",
"Stomp",
"Соққы"
],
[
"Падение",
"Drop",
"Құлау"
],
[
"Наезд",
"Zoom in",
"Жақындау"
],
[
"Поворот",
"Spin",
"Бұрылу"
],
[
"Из размытия",
"From blur",
"Бұлдырдан"
],
[
"По буквам",
"By letters",
"Әріптер бойынша"
],
[
"Разъезд",
"Spread",
"Жайылу"
],
[
"Дрожь",
"Shake",
"Діріл"
],
[
"Мерцание",
"Flicker",
"Жыпылықтау"
],
[
"Кобальт",
"Cobalt",
"Кобальт"
],
[
"Электро",
"Electro",
"Электро"
],
[
"Закат",
"Sunset",
"Күн батуы"
],
[
"Лёд",
"Ice",
"Мұз"
],
[
"Графит",
"Graphite",
"Графит"
],
[
"Мой стиль",
"My style",
"Менің стилім"
],
[
"Моя анимация",
"My animation",
"Менің анимациям"
],
[
"Пока пусто — настрой стиль ниже и нажми «Сохранить новый»",
"Nothing here yet — tweak a style below and press “Save as new”",
"Әзірше бос — төменде стильді реттеп, «Жаңасын сақтау» батырмасын басыңыз"
],
[
"Сначала выбери свой стиль в списке выше",
"First pick your style in the list above",
"Алдымен жоғарыдағы тізімнен өз стиліңізді таңдаңыз"
],
[
"Пока пусто — выбери пресет, подстрой ползунки и нажми «Сохранить новую»",
"Nothing here yet — pick a preset, adjust the sliders and press “Save as new”",
"Әзірше бос — пресетті таңдап, жүгірткілерді реттеп, «Жаңасын сақтау» батырмасын басыңыз"
],
[
"Сначала выбери свою анимацию в списке выше",
"First pick your animation in the list above",
"Алдымен жоғарыдағы тізімнен өз анимацияңызды таңдаңыз"
],
[
"Точно?",
"Sure?",
"Сенімдісіз бе?"
],
[
"Точно удалить?",
"Really delete?",
"Шынымен жою?"
],
[
"Сохранено: {x}",
"Saved: {x}",
"Сақталды: {x}"
],
[
"Обновлено: {x}",
"Updated: {x}",
"Жаңартылды: {x}"
],
[
"Удалено: {x}",
"Deleted: {x}",
"Жойылды: {x}"
],
[
"Сохранено.",
"Saved.",
"Сақталды."
],
[
"Применяю стиль…",
"Applying style…",
"Стиль қолданылуда…"
],
[
"Стиль применён к {n} слоям",
"Style applied to {n} layers",
"Стиль {n} қабатқа қолданылды"
],
[
"Нет слоёв SubLee в этой композиции",
"No SubLee layers in this comp",
"Бұл композицияда SubLee қабаттары жоқ"
],
[
"Выбери, что пружинит: Position, Scale, Rotation или Selected",
"Choose what springs: Position, Scale, Rotation or Selected",
"Нені серпілту керектігін таңдаңыз: Position, Scale, Rotation немесе Selected"
],
[
"Добавляю Bounce…",
"Adding Bounce…",
"Bounce қосылуда…"
],
[
"Bounce добавлен к свойствам: {n} (пропущено без ключей: {k})",
"Bounce added to {n} properties ({k} skipped — no keyframes)",
"Bounce {n} қасиетке қосылды (кілт кадрсыз өткізілді: {k})"
],
[
"Bounce добавлен к свойствам: {n}",
"Bounce added to {n} properties",
"Bounce {n} қасиетке қосылды"
],
[
"Выдели в таймлайне AE свойства с ключами (минимум 2 ключа)",
"Select properties with keyframes in the AE timeline (at least 2 keyframes)",
"AE таймлайнында кілт кадрлары бар қасиеттерді таңдаңыз (кемінде 2 кілт)"
],
[
"Bounce добавлен к {n} слоям",
"Bounce added to {n} layers",
"Bounce {n} қабатқа қосылды"
],
[
"Нет подходящих слоёв (нужен режим «слой на подпись»)",
"No suitable layers (needs “layer per caption” mode)",
"Қолайлы қабаттар жоқ («әр жазуға бір қабат» режимі керек)"
],
[
"Применяю анимацию…",
"Applying animation…",
"Анимация қолданылуда…"
],
[
"Анимация применена к {n} слоям",
"Animation applied to {n} layers",
"Анимация {n} қабатқа қолданылды"
],
[
"Нет подходящих слоёв (анимация работает в режиме «слой на подпись»)",
"No suitable layers (animation works in “layer per caption” mode)",
"Қолайлы қабаттар жоқ (анимация «әр жазуға бір қабат» режимінде жұмыс істейді)"
],
[
"Авто → {x}",
"Auto → {x}",
"Авто → {x}"
],
[
"Если язык субтитров отличается от языка речи, текст переводится через API (ключ в «Настройках»). Совпадающий язык берётся прямо из распознавания.",
"If the subtitle language differs from the speech language, the text is translated via API (key in “Settings”). A matching language is taken straight from recognition.",
"Егер субтитр тілі сөйлеу тілінен өзгеше болса, мәтін API арқылы аударылады (кілт «Баптаулар» бөлімінде). Сәйкес тіл тікелей тану нәтижесінен алынады."
],
[
"Для казахского нужен шрифт с буквами ә ғ қ ң ө ұ ү һ і. Если видишь квадраты — смени шрифт (Arial, Segoe UI, Roboto).",
"Kazakh needs a font with the letters ә ғ қ ң ө ұ ү һ і. If you see squares, change the font (Arial, Segoe UI, Roboto).",
"Қазақша үшін ә ғ қ ң ө ұ ү һ і әріптері бар қаріп керек. Шаршыларды көрсеңіз, қаріпті ауыстырыңыз (Arial, Segoe UI, Roboto)."
],
[
"Список шрифтов недоступен (нужен AE 2023+). Впиши PostScript-имя в поле выше и нажми Enter.",
"Font list is unavailable (needs AE 2023+). Type a PostScript name in the field above and press Enter.",
"Қаріптер тізімі қолжетімсіз (AE 2023+ керек). Жоғарыдағы өріске PostScript атауын жазып, Enter басыңыз."
],
[
"Показан язык {l} ({n} слоёв)",
"Language {l} shown ({n} layers)",
"{l} тілі көрсетілді ({n} қабат)"
],
[
"Скрыт язык {l} ({n} слоёв)",
"Language {l} hidden ({n} layers)",
"{l} тілі жасырылды ({n} қабат)"
],
[
"Выбери видео или аудио",
"Choose a video or audio file",
"Бейне немесе аудио таңдаңыз"
],
[
"Выбери файл",
"Choose a file",
"Файлды таңдаңыз"
],
[
"Выбери файл субтитров",
"Choose a subtitle file",
"Субтитр файлын таңдаңыз"
],
[
"Сохранить SRT",
"Save SRT",
"SRT сақтау"
],
[
"Диалог выбора файла недоступен: {x}",
"File dialog unavailable: {x}",
"Файл таңдау диалогы қолжетімсіз: {x}"
],
[
"Диалог сохранения недоступен: {x}",
"Save dialog unavailable: {x}",
"Сақтау диалогы қолжетімсіз: {x}"
],
[
"Node.js недоступен в панели (проверь manifest: --enable-nodejs)",
"Node.js is unavailable in the panel (check manifest: --enable-nodejs)",
"Панельде Node.js қолжетімсіз (manifest тексеріңіз: --enable-nodejs)"
],
[
"Открой композицию (кликни по ней в Timeline) и попробуй снова.",
"Open a composition (click it in the Timeline) and try again.",
"Композицияны ашыңыз (Timeline-да басыңыз) да, қайта байқаңыз."
],
[
"Скрипт SubLee в After Effects не отвечает. Перезапусти AE и открой панель заново.",
"The SubLee script in After Effects is not responding. Restart AE and reopen the panel.",
"After Effects ішіндегі SubLee скрипті жауап бермейді. AE-ді қайта іске қосып, панельді қайта ашыңыз."
],
[
"Непонятный ответ After Effects: {x}",
"Unexpected reply from After Effects: {x}",
"After Effects-тің түсініксіз жауабы: {x}"
],
[
"Нет связи с After Effects: {x}",
"Can’t reach After Effects: {x}",
"After Effects-пен байланыс жоқ: {x}"
],
[
"строка",
"line",
"жол"
],
[
"Движок",
"Engine",
"Қозғалтқыш"
],
[
"не найден",
"not found",
"табылмады"
],
[
"задан",
"set",
"берілген"
],
[
"Положи ffmpeg(.exe) в папку bin расширения или укажи путь выше.",
"Put ffmpeg(.exe) into the extension’s bin folder or set the path above.",
"ffmpeg(.exe) файлын кеңейтімнің bin қалтасына салыңыз немесе жоғарыда жолды көрсетіңіз."
],
[
"Запусти установщик с ключом -WithWhisper или укажи путь.",
"Run the installer with the -WithWhisper flag or set the path.",
"Орнатқышты -WithWhisper кілтімен іске қосыңыз немесе жолды көрсетіңіз."
],
[
"Нужен файл ggml-*.bin (рекомендую ggml-large-v3-turbo-q5_0.bin).",
"A ggml-*.bin file is needed (I recommend ggml-large-v3-turbo-q5_0.bin).",
"ggml-*.bin файлы керек (ggml-large-v3-turbo-q5_0.bin ұсынамын)."
],
[
"OpenAI ключ",
"OpenAI key",
"OpenAI кілті"
],
[
"Впиши ключ в поле выше.",
"Enter the key in the field above.",
"Кілтті жоғарыдағы өріске жазыңыз."
],
[
"Ключ для перевода: задан",
"Translation key: set",
"Аударма кілті: берілген"
],
[
"Ключ для перевода: не задан (нужен только если язык субтитров ≠ языку речи)",
"Translation key: not set (only needed if the subtitle language ≠ the speech language)",
"Аударма кілті: берілмеген (тек субтитр тілі ≠ сөйлеу тілі болғанда керек)"
],
[
"Выбран пре-комп. Выдели исходный слой с видео/аудио (или выбери файл в «Дополнительно»).",
"A pre-comp is selected. Select the source layer with video/audio (or choose a file in “More options”).",
"Пре-комп таңдалған. Бейне/аудиосы бар бастапқы қабатты таңдаңыз (немесе «Қосымша» бөлімінен файл таңдаңыз)."
],
[
"У слоя нет файла-источника. Выбери файл в «Дополнительно».",
"The layer has no source file. Choose a file in “More options”.",
"Қабаттың бастапқы файлы жоқ. «Қосымша» бөлімінен файл таңдаңыз."
],
[
"Выдели в композиции слой с видео или аудио (или выбери файл в «Дополнительно»).",
"Select a layer with video or audio in the comp (or choose a file in “More options”).",
"Композицияда бейнесі немесе аудиосы бар қабатты таңдаңыз (немесе «Қосымша» бөлімінен файл таңдаңыз)."
],
[
"Речь не найдена в «{x}».",
"No speech found in “{x}”.",
"«{x}» ішінде сөйлеу табылмады."
],
[
"Перевожу {a} → {b}…",
"Translating {a} → {b}…",
"Аударылуда {a} → {b}…"
],
[
"Движок не загружен: {x}",
"Engine failed to load: {x}",
"Қозғалтқыш жүктелмеді: {x}"
],
[
"Не удалось загрузить движок: {x}",
"Couldn’t load the engine: {x}",
"Қозғалтқышты жүктеу мүмкін болмады: {x}"
],
[
"Читаю композицию…",
"Reading the composition…",
"Композиция оқылуда…"
],
[
"Не получилось собрать ни одной подписи.",
"Couldn’t build a single caption.",
"Бірде-бір жазу жасалмады."
],
[
"Отменено.",
"Cancelled.",
"Бас тартылды."
],
[
"Отменено",
"Cancelled",
"Бас тартылды"
],
[
"Создаю слои в After Effects…",
"Creating layers in After Effects…",
"After Effects-те қабаттар жасалуда…"
],
[
"Создаю слои…",
"Creating layers…",
"Қабаттар жасалуда…"
],
[
"Готово! Создано подписей: {n} ({l}) ✨",
"Done! Captions created: {n} ({l}) ✨",
"Дайын! Жасалған жазулар: {n} ({l}) ✨"
],
[
"Проблемы: {x}",
"Problems: {x}",
"Мәселелер: {x}"
],
[
"{n} подписей",
"{n} captions",
"{n} жазу"
],
[
"Начало",
"Start",
"Басы"
],
[
"Конец",
"End",
"Соңы"
],
[
"Склеить со следующей",
"Merge with next",
"Келесімен біріктіру"
],
[
"Выделено слоёв: {n}",
"Layers selected: {n}",
"Таңдалған қабаттар: {n}"
],
[
"В этой композиции нет слоёв SubLee",
"No SubLee layers in this comp",
"Бұл композицияда SubLee қабаттары жоқ"
],
[
"Убрана пунктуация в {n} слоях",
"Punctuation removed in {n} layers",
"{n} қабатта тыныс белгілері алынды"
],
[
"Нет слоёв SubLee",
"No SubLee layers",
"SubLee қабаттары жоқ"
],
[
"Удалено слоёв: {n} (Ctrl+Z вернёт)",
"Layers deleted: {n} (Ctrl+Z brings them back)",
"Жойылған қабаттар: {n} (Ctrl+Z қайтарады)"
],
[
"Нечего удалять",
"Nothing to delete",
"Жоятын ештеңе жоқ"
],
[
"В файле не нашлось подписей (формат SRT).",
"No captions found in the file (SRT format).",
"Файлда жазулар табылмады (SRT форматы)."
],
[
"В композиции нет субтитров SubLee.",
"There are no SubLee subtitles in the comp.",
"Композицияда SubLee субтитрлері жоқ."
],
[
"Выдели клип на таймлайне и жми «Сделать субтитры» 👆",
"Select a clip on the timeline and hit “Make subtitles” 👆",
"Таймлайнда клипті таңдап, «Субтитр жасау» батырмасын басыңыз 👆"
],
[
"Неизвестный режим: {x}",
"Unknown mode: {x}",
"Белгісіз режим: {x}"
],
[
"В этом файле нет звуковой дорожки.",
"This file has no audio track.",
"Бұл файлда аудио жол жоқ."
],
[
"ffmpeg не смог достать звук: {x}",
"ffmpeg couldn’t extract the audio: {x}",
"ffmpeg дыбысты шығара алмады: {x}"
],
[
"код {n}",
"code {n}",
"код {n}"
],
[
"В выбранном участке нет звука.",
"There is no sound in the selected range.",
"Таңдалған бөлікте дыбыс жоқ."
],
[
"Не найден whisper-cli. Запусти установщик или укажи путь в «Настройки».",
"whisper-cli not found. Run the installer or set the path in “Settings”.",
"whisper-cli табылмады. Орнатқышты іске қосыңыз немесе «Баптаулар» бөлімінде жолды көрсетіңіз."
],
[
"Не найдена модель whisper (ggml-*.bin). Скачай её или укажи путь в «Настройки».",
"Whisper model (ggml-*.bin) not found. Download it or set the path in “Settings”.",
"Whisper моделі (ggml-*.bin) табылмады. Жүктеп алыңыз немесе «Баптаулар» бөлімінде жолды көрсетіңіз."
],
[
"whisper-cli завершился с ошибкой ({c}): {x}",
"whisper-cli failed with an error ({c}): {x}",
"whisper-cli қатемен аяқталды ({c}): {x}"
],
[
"Таймаут запроса к {x}",
"Request to {x} timed out",
"{x} сұрауының уақыты бітті"
],
[
"проверь API-ключ в «Настройки»",
"check the API key in “Settings”",
"API кілтін «Баптаулар» бөлімінде тексеріңіз"
],
[
"лимит запросов или нет денег на счёте",
"rate limit or no funds on the account",
"сұраулар лимиті немесе шотта қаражат жоқ"
],
[
"OpenAI (перевод)",
"OpenAI (translation)",
"OpenAI (аударма)"
],
[
"Anthropic (перевод)",
"Anthropic (translation)",
"Anthropic (аударма)"
],
[
"OpenAI (распознавание)",
"OpenAI (recognition)",
"OpenAI (тану)"
],
[
"Нет OpenAI API-ключа. Впиши его в «Настройки».",
"No OpenAI API key. Enter it in “Settings”.",
"OpenAI API кілті жоқ. Оны «Баптаулар» бөлімінде жазыңыз."
],
[
"Не найден ffmpeg. Запусти установщик или укажи путь в «Настройки».",
"ffmpeg not found. Run the installer or set the path in “Settings”.",
"ffmpeg табылмады. Орнатқышты іске қосыңыз немесе «Баптаулар» бөлімінде жолды көрсетіңіз."
],
[
"Файл не найден: {x}",
"File not found: {x}",
"Файл табылмады: {x}"
],
[
"Распознаю (OpenAI)… часть {i}/{n}",
"Recognizing (OpenAI)… part {i}/{n}",
"Танылуда (OpenAI)… {i}/{n} бөлік"
],
[
"Достаю аудио…",
"Extracting audio…",
"Дыбыс шығарылуда…"
],
[
"Распознаю (Whisper локально)…",
"Recognizing (local Whisper)…",
"Танылуда (жергілікті Whisper)…"
],
[
"Распознаю (Whisper локально)… {p}%",
"Recognizing (local Whisper)… {p}%",
"Танылуда (жергілікті Whisper)… {p}%"
],
[
"Модель вернула не JSON-массив",
"The model didn’t return a JSON array",
"Модель JSON-массив қайтармады"
],
[
"Ответ не массив",
"The reply is not an array",
"Жауап массив емес"
],
[
"Количество строк не совпало: {a} вместо {b}",
"Line count mismatch: {a} instead of {b}",
"Жол саны сәйкес келмеді: {b} орнына {a}"
],
[
"Для перевода нужен OpenAI API-ключ (или выбери Anthropic в «Настройки»).",
"Translation needs an OpenAI API key (or pick Anthropic in “Settings”).",
"Аударма үшін OpenAI API кілті керек (немесе «Баптаулар» бөлімінде Anthropic таңдаңыз)."
],
[
"Для перевода нужен Anthropic API-ключ (или выбери OpenAI в «Настройки»).",
"Translation needs an Anthropic API key (or pick OpenAI in “Settings”).",
"Аударма үшін Anthropic API кілті керек (немесе «Баптаулар» бөлімінде OpenAI таңдаңыз)."
],
[
"Язык интерфейса",
"Interface language",
"Интерфейс тілі"
],
[
"Одно слово",
"One Word",
"Бір сөз"
],
[
"Два слова",
"Two Words",
"Екі сөз"
],
[
"Умные короткие",
"Smart Short",
"Ақылды қысқа"
],
[
"Умные длинные",
"Smart Long",
"Ақылды ұзын"
],
[
"Предложения",
"Sentences",
"Сөйлемдер"
],
[
"Свой режим",
"Custom",
"Өз режимім"
],
[
"Анимация интерфейса",
"Interface animations",
"Интерфейс анимациясы"
],
[
"Каждый стиль играет свою анимацию. Наведи — увидишь выбранную на вкладке «Анимация».",
"Each style plays its own animation. Hover to see the one chosen on the “Animation” tab.",
"Әр стиль өз анимациясын ойнатады. Меңзесеңіз — «Анимация» қойындысында таңдалғаны көрінеді."
],
[
"Пресеты проигрываются прямо на карточках.",
"Presets play right on the cards.",
"Пресеттер тікелей карточкаларда ойнатылады."
],
[
"Масштаб по размеру панели",
"Scale with panel size",
"Панель өлшеміне қарай масштабтау"
],
[
"Размер текста",
"Text size",
"Мәтін өлшемі"
],
[
"(% от короткой стороны кадра)",
"(% of the frame’s short side)",
"(кадрдың қысқа жағынан %)"
],
[
"Ко всем готовым",
"To all existing",
"Барлық дайындарға"
],
[
"Меняю размер…",
"Changing size…",
"Өлшемі өзгертілуде…"
],
[
"Размер текста изменён у {n} слоёв",
"Text size changed on {n} layers",
"Мәтін өлшемі {n} қабатта өзгертілді"
],
[
"Шрифт {a} не установлен, использован {b}",
"Font {a} is not installed, used {b}",
"{a} қарпі орнатылмаған, {b} қолданылды"
],
[
"💫 Кастом",
"💫 Custom",
"💫 Кастом"
],
[
"Только In",
"In only",
"Тек In"
],
[
"Только Out",
"Out only",
"Тек Out"
],
[
"Все",
"All",
"Барлығы"
],
[
"Выделенные слои, а если ничего не выделено — все",
"Selected layers, or all if nothing is selected",
"Таңдалған қабаттар, ештеңе таңдалмаса — барлығы"
],
[
"Появление (In), кадров",
"Appear (In), frames",
"Пайда болу (In), кадр"
],
[
"Исчезновение (Out), кадров",
"Disappear (Out), frames",
"Жоғалу (Out), кадр"
],
[
"Сила эффекта",
"Effect strength",
"Эффект күші"
],
[
"Удалить все анимации",
"Delete all animations",
"Барлық анимацияларды жою"
],
[
"Клик по карточке — анимация сразу на выделенный текстовый слой (любой, не только субтитры). Если ничего не выделено — на все подписи. Скорость меняй прямо на слое: тяни маркеры «SF In» и «SF Out» — чем ближе к краю клипа, тем быстрее. Ползунки выше задают только стартовое положение маркеров. Анимации вкладки «Анимация» не мешают: сначала ставь их, потом эти.",
"Click a card to apply the animation to the selected text layer right away (any text layer, not only subtitles). If nothing is selected, it goes to all captions. Change the speed right on the layer: drag the “SF In” and “SF Out” markers — the closer to the clip edge, the faster. The sliders above only set the markers’ starting position. Animations from the “Animation” tab don’t conflict: apply those first, then these.",
"Карточканы басыңыз — анимация бірден таңдалған мәтін қабатына қосылады (кез келген, тек субтитр емес). Ештеңе таңдалмаса — барлық жазуларға. Жылдамдықты тікелей қабатта өзгертіңіз: «SF In» және «SF Out» маркерлерін сүйреңіз — клип шетіне жақын болған сайын, соғұрлым жылдам. Жоғарыдағы жүгірткілер маркерлердің бастапқы орнын ғана береді. «Анимация» қойындысының анимациялары кедергі келтірмейді: алдымен солар, содан кейін мыналар."
],
[
"Добавляю эффект…",
"Adding effect…",
"Эффект қосылуда…"
],
[
"Удаляю анимации…",
"Removing animations…",
"Анимациялар жойылуда…"
],
[
"Эффект «{x}» ({m}): {n} слоёв",
"Effect “{x}” ({m}): {n} layers",
"«{x}» эффектісі ({m}): {n} қабат"
],
[
"Нет текстовых слоёв: выдели текст или создай субтитры (режим «один слой» не поддерживается)",
"No text layers: select a text layer or create subtitles (“single layer” mode is not supported)",
"Мәтін қабаттары жоқ: мәтінді таңдаңыз немесе субтитр жасаңыз («бір қабат» режимі қолдау таппайды)"
],
[
"Анимации удалены: {n} слоёв (Ctrl+Z вернёт)",
"Animations removed: {n} layers (Ctrl+Z brings them back)",
"Анимациялар жойылды: {n} қабат (Ctrl+Z қайтарады)"
],
[
"Сдвиг",
"Move",
"Жылжу"
],
[
"Сдвиг + размытие",
"Move + blur",
"Жылжу + бұлдырау"
],
[
"Случайные",
"Random",
"Кездейсоқ"
],
[
"3D",
"3D",
"3D"
],
[
"Якорь",
"Anchor",
"Зәкір"
],
[
"Масштаб",
"Scale",
"Масштаб"
],
[
"Вращение",
"Rotation",
"Айналу"
],
[
"Слова вниз",
"Words down",
"Сөздер төмен"
],
[
"Слова вверх",
"Words up",
"Сөздер жоғары"
],
[
"Слова влево",
"Words left",
"Сөздер солға"
],
[
"Слова вправо",
"Words right",
"Сөздер оңға"
],
[
"Буквы вниз",
"Letters down",
"Әріптер төмен"
],
[
"Буквы вверх",
"Letters up",
"Әріптер жоғары"
],
[
"Буквы влево",
"Letters left",
"Әріптер солға"
],
[
"Буквы вправо",
"Letters right",
"Әріптер оңға"
],
[
"Слова вниз + размытие",
"Words down + blur",
"Сөздер төмен + бұлдырау"
],
[
"Слова вверх + размытие",
"Words up + blur",
"Сөздер жоғары + бұлдырау"
],
[
"Слова влево + размытие",
"Words left + blur",
"Сөздер солға + бұлдырау"
],
[
"Слова вправо + размытие",
"Words right + blur",
"Сөздер оңға + бұлдырау"
],
[
"Буквы вниз + размытие",
"Letters down + blur",
"Әріптер төмен + бұлдырау"
],
[
"Буквы вверх + размытие",
"Letters up + blur",
"Әріптер жоғары + бұлдырау"
],
[
"Буквы влево + размытие",
"Letters left + blur",
"Әріптер солға + бұлдырау"
],
[
"Буквы вправо + размытие",
"Letters right + blur",
"Әріптер оңға + бұлдырау"
],
[
"Слова",
"Words",
"Сөздер"
],
[
"Буквы",
"Letters",
"Әріптер"
],
[
"Строки",
"Lines",
"Жолдар"
],
[
"Слова + размытие",
"Words + blur",
"Сөздер + бұлдырау"
],
[
"Буквы + размытие",
"Letters + blur",
"Әріптер + бұлдырау"
],
[
"Случайные слова",
"Random words",
"Кездейсоқ сөздер"
],
[
"Случайные буквы",
"Random letters",
"Кездейсоқ әріптер"
],
[
"Случайные слова + размытие",
"Random words + blur",
"Кездейсоқ сөздер + бұлдырау"
],
[
"Случайные буквы + размытие",
"Random letters + blur",
"Кездейсоқ әріптер + бұлдырау"
],
[
"Случайные слова вверх",
"Random words up",
"Кездейсоқ сөздер жоғары"
],
[
"Случайные буквы вниз",
"Random letters down",
"Кездейсоқ әріптер төмен"
],
[
"3D слова вниз",
"3D words down",
"3D сөздер төмен"
],
[
"3D слова вверх",
"3D words up",
"3D сөздер жоғары"
],
[
"3D слова влево",
"3D words left",
"3D сөздер солға"
],
[
"3D слова вправо",
"3D words right",
"3D сөздер оңға"
],
[
"3D слова вперёд",
"3D words front",
"3D сөздер алға"
],
[
"3D буквы вниз",
"3D letters down",
"3D әріптер төмен"
],
[
"3D буквы вверх",
"3D letters up",
"3D әріптер жоғары"
],
[
"3D буквы влево",
"3D letters left",
"3D әріптер солға"
],
[
"3D буквы вправо",
"3D letters right",
"3D әріптер оңға"
],
[
"3D буквы вперёд",
"3D letters front",
"3D әріптер алға"
],
[
"3D буквы + поворот вниз",
"3D letters + rotate down",
"3D әріптер + бұру төмен"
],
[
"3D буквы + поворот вверх",
"3D letters + rotate up",
"3D әріптер + бұру жоғары"
],
[
"3D буквы + поворот влево",
"3D letters + rotate left",
"3D әріптер + бұру солға"
],
[
"3D буквы + поворот вправо",
"3D letters + rotate right",
"3D әріптер + бұру оңға"
],
[
"Слова якорь вниз",
"Words anchor down",
"Сөздер зәкір төмен"
],
[
"Слова якорь вверх",
"Words anchor up",
"Сөздер зәкір жоғары"
],
[
"Слова якорь влево",
"Words anchor left",
"Сөздер зәкір солға"
],
[
"Слова якорь вправо",
"Words anchor right",
"Сөздер зәкір оңға"
],
[
"Буквы якорь вниз",
"Letters anchor down",
"Әріптер зәкір төмен"
],
[
"Буквы якорь вверх",
"Letters anchor up",
"Әріптер зәкір жоғары"
],
[
"Буквы якорь влево",
"Letters anchor left",
"Әріптер зәкір солға"
],
[
"Буквы якорь вправо",
"Letters anchor right",
"Әріптер зәкір оңға"
],
[
"Печать: буквы",
"Typewriter: letters",
"Басу: әріптер"
],
[
"Печать: слова",
"Typewriter: words",
"Басу: сөздер"
],
[
"Печать + размытие",
"Typewriter + blur",
"Басу + бұлдырау"
],
[
"Слова вырастают",
"Words grow",
"Сөздер өседі"
],
[
"Буквы вырастают",
"Letters grow",
"Әріптер өседі"
],
[
"Слова: наезд",
"Words: zoom in",
"Сөздер: жақындау"
],
[
"Буквы: наезд",
"Letters: zoom in",
"Әріптер: жақындау"
],
[
"Буквы: вращение",
"Letters: spin",
"Әріптер: айналу"
],
[
"Слова: вращение",
"Words: spin",
"Сөздер: айналу"
],
[
"Вихрь",
"Whirl",
"Құйын"
],
[
"Разъезд букв",
"Letters spread",
"Әріптердің жайылуы"
],
[
"Сжатие букв",
"Letters squeeze",
"Әріптердің қысылуы"
],
[
"Проявление",
"Fade",
"Көріну"
],
[
"Нет текстовых слоёв в этой композиции",
"No text layers in this composition",
"Бұл композицияда мәтін қабаттары жоқ"
],
[
"Смешанная",
"Mixed",
"Аралас"
],
[
"Человек переключается между русским, казахским и английским: язык определяется для каждой фразы",
"The speaker switches between Russian, Kazakh and English: the language is detected for each phrase",
"Адам орыс, қазақ және ағылшын тілдері арасында ауысады: тіл әр фраза үшін анықталады"
],
[
"Как сказано",
"As spoken",
"Айтылғандай"
],
[
"Каждая фраза остаётся на том языке, на котором её сказали, без перевода",
"Each phrase stays in the language it was spoken in, no translation",
"Әр фраза айтылған тілде қалады, аударусыз"
],
[
"Смешанная речь: звук режется по паузам, язык определяется для каждой фразы (RU / KK / EN). «Как сказано» оставляет фразы на своём языке, остальные языки — перевод через API. Переключение внутри одной фразы не ловится; лучше всего работают модели small и больше.",
"Mixed speech: the audio is split at pauses and the language is detected for each phrase (RU / KK / EN). “As spoken” keeps phrases in their own language; other languages are translated via API. Switching inside a single phrase is not caught; models small and larger work best.",
"Аралас сөйлеу: дыбыс үзілістер бойынша бөлінеді, тіл әр фраза үшін анықталады (RU / KK / EN). «Айтылғандай» фразаларды өз тілінде қалдырады, басқа тілдер API арқылы аударылады. Бір фраза ішіндегі ауысу ұсталмайды; small және одан үлкен модельдер жақсы жұмыс істейді."
],
[
"Определяю язык и распознаю… фраза {a}/{b}",
"Detecting language and recognizing… phrase {a}/{b}",
"Тілді анықтап, тану… {a}/{b} фраза"
],
[
"Ищу паузы в речи…",
"Looking for pauses in speech…",
"Сөйлеудегі үзілістерді іздеу…"
],
[
"Перевожу фразы на {x}…",
"Translating phrases to {x}…",
"Фразаларды {x} тіліне аудару…"
],
[
"Языки в речи: {x}",
"Languages in speech: {x}",
"Сөйлеудегі тілдер: {x}"
],
[
"Что нового",
"What’s new",
"Жаңалықтар"
],
[
"Закрыть",
"Close",
"Жабу"
],
[
"сейчас",
"current",
"қазір"
],
[
"Обновлено до v{v} · Что нового",
"Updated to v{v} · What’s new",
"v{v} нұсқасына жаңартылды · Жаңалықтар"
],
[
"Доступно обновление v{v} · нажми, чтобы обновить",
"Update v{v} available · click to install",
"v{v} жаңартуы қолжетімді · орнату үшін басыңыз"
],
[
"Не удалось обновить: {x}",
"Update failed: {x}",
"Жаңарту сәтсіз: {x}"
],
[
"Скачиваю обновление…",
"Downloading update…",
"Жаңартуды жүктеп жатыр…"
],
[
"Готово! Перезагружаю панель…",
"Done! Reloading the panel…",
"Дайын! Панельді қайта жүктеу…"
],
[
"Готово! Перезапусти After Effects, чтобы закончить обновление.",
"Done! Restart After Effects to finish the update.",
"Дайын! Жаңартуды аяқтау үшін After Effects-ті қайта іске қосыңыз."
],
[
"Обновить до v{v}",
"Update to v{v}",
"v{v} нұсқасына жаңарту"
],
[
"Обновить сейчас",
"Update now",
"Қазір жаңарту"
],
[
"Проверить обновления",
"Check for updates",
"Жаңартуларды тексеру"
],
[
"Проверяю…",
"Checking…",
"Тексеруде…"
],
[
"Доступна версия v{v}",
"Version v{v} is available",
"v{v} нұсқасы қолжетімді"
],
[
"Обновлений нет: у тебя последняя версия v{v}",
"No updates: you have the latest version v{v}",
"Жаңартулар жоқ: сізде соңғы v{v} нұсқасы"
],
[
"Адрес обновлений не задан (Настройки → Обновления)",
"Update address is not set (Settings → Updates)",
"Жаңарту мекенжайы берілмеген (Баптаулар → Жаңартулар)"
],
[
"Не удалось проверить обновления: {x}",
"Could not check for updates: {x}",
"Жаңартуларды тексеру мүмкін болмады: {x}"
],
[
"Обновления",
"Updates",
"Жаңартулар"
],
[
"Адрес update.json",
"update.json address",
"update.json мекенжайы"
],
[
"Проверять при запуске",
"Check on startup",
"Іске қосқанда тексеру"
],
[
"Рядом с update.json должен лежать архив обновления. Когда выйдет новая версия, сверху появится кнопка: клик скачает и установит её.",
"The update archive must sit next to update.json. When a new version is out, a button appears at the top: click it to download and install.",
"update.json қасында жаңарту архиві болуы керек. Жаңа нұсқа шыққанда жоғарыда түйме пайда болады: басқанда ол жүктеліп орнатылады."
],
[
"Неверный адрес обновлений.",
"Invalid update address.",
"Жаңарту мекенжайы дұрыс емес."
],
[
"Слишком много перенаправлений при скачивании.",
"Too many redirects while downloading.",
"Жүктеу кезінде қайта бағыттау тым көп."
],
[
"Не удалось скачать обновление: HTTP {n}",
"Could not download the update: HTTP {n}",
"Жаңартуды жүктеу мүмкін болмады: HTTP {n}"
],
[
"Сервер обновлений не отвечает.",
"The update server is not responding.",
"Жаңарту сервері жауап бермейді."
],
[
"Файл обновления прочитать не удалось (ожидается update.json).",
"Could not read the update file (update.json expected).",
"Жаңарту файлын оқу мүмкін болмады (update.json күтілуде)."
],
[
"В файле обновления нет номера версии.",
"The update file has no version number.",
"Жаңарту файлында нұсқа нөмірі жоқ."
],
[
"Не удалось распаковать обновление: {x}",
"Could not unpack the update: {x}",
"Жаңартуды ашу мүмкін болмады: {x}"
],
[
"Файл обновления повреждён или пуст.",
"The update file is damaged or empty.",
"Жаңарту файлы бүлінген немесе бос."
],
[
"В архиве нет папки SubFlow с панелью.",
"The archive has no SubFlow panel folder.",
"Архивте SubFlow панель қалтасы жоқ."
],
[
"Версия в архиве ({a}) не совпадает с update.json ({b}).",
"Archive version ({a}) does not match update.json ({b}).",
"Архивтегі нұсқа ({a}) update.json-мен ({b}) сәйкес келмейді."
],
[
"Не удалось записать файлы обновления: {x}",
"Could not write the update files: {x}",
"Жаңарту файлдарын жазу мүмкін болмады: {x}"
]
];

  var LANGS = ['ru', 'en', 'kk'];
  var CYR = /[А-Яа-яЁё]/;
  var exact = { en: {}, kk: {} };
  var patterns = [];      // { re, keys[], to:{en,kk}, weight }
  var frags = [];         // фрагменты без подстановок (для составных сообщений)

  function norm(s) { return String(s).replace(/\s+/g, ' ').trim(); }
  function esc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  DATA.forEach(function (r) {
    var key = norm(r[0]);
    if (/\{\w+\}/.test(key)) {
      var keys = [];
      var src = esc(key).replace(/\\\{(\w+)\\\}/g, function (m, k) { keys.push(k); return '([\\s\\S]*?)'; });
      patterns.push({ re: new RegExp('^' + src + '$'), keys: keys, to: { en: r[1], kk: r[2] }, weight: key.replace(/\{\w+\}/g, '').length });
    } else {
      exact.en[key] = r[1]; exact.kk[key] = r[2];
      if (key.length >= 5) frags.push(key);
    }
  });
  patterns.sort(function (a, b) { return b.weight - a.weight; });
  frags.sort(function (a, b) { return b.length - a.length; });

  var WORDCH = /[A-Za-zА-Яа-яЁё0-9_]/;

  function trCore(s, lang) {
    var i, m, p;
    if (Object.prototype.hasOwnProperty.call(exact[lang], s)) return exact[lang][s];
    for (i = 0; i < patterns.length; i++) {
      p = patterns[i];
      m = p.re.exec(s);
      if (m) {
        var vals = {};
        p.keys.forEach(function (k, j) { vals[k] = trAny(m[j + 1], lang); });
        return p.to[lang].replace(/\{(\w+)\}/g, function (x, k) { return vals[k] !== undefined ? vals[k] : x; });
      }
    }
    // составные сообщения: подменяем известные фрагменты по границам слов
    var out = s;
    frags.forEach(function (f) {
      var from = 0, at, a, b;
      while ((at = out.indexOf(f, from)) >= 0) {
        a = at > 0 ? out.charAt(at - 1) : ''; b = out.charAt(at + f.length);
        if ((a && WORDCH.test(a)) || (b && WORDCH.test(b))) { from = at + 1; continue; }
        out = out.slice(0, at) + exact[lang][f] + out.slice(at + f.length);
        from = at + exact[lang][f].length;
      }
    });
    return out;
  }

  function trLine(line, lang) {
    if (!CYR.test(line)) return line;
    var m = /^([\s✓✗!•]*)([\s\S]*?)(\s*)$/.exec(line);
    return m[1] + trCore(norm(m[2]), lang) + m[3];
  }
  function trAny(text, lang) {
    if (lang === 'ru' || text === null || text === undefined) return text;
    text = String(text);
    if (!CYR.test(text)) return text;
    return text.split('\n').map(function (l) { return trLine(l, lang); }).join('\n');
  }

  var state = { lang: 'ru' };
  function tr(text, lang) { return trAny(text, lang || state.lang); }
  function t(text, vars, lang) {
    var base = (lang || state.lang) === 'ru' ? text : tr(text, lang);
    return base.replace(/\{(\w+)\}/g, function (x, k) { return vars && vars[k] !== undefined ? vars[k] : x; });
  }

  /* ---------------------------------------------------------------- DOM */
  var ATTRS = ['title', 'placeholder', 'aria-label'];
  var textStore = null, attrStore = null, observer = null;

  function skipNode(n) {
    var p = n.parentNode, q;
    if (!p || (p.nodeName && /^(SCRIPT|STYLE|TEXTAREA)$/.test(p.nodeName))) return true;
    for (q = p; q && q.getAttribute; q = q.parentNode) if (q.getAttribute('data-i18n') === 'off') return true;   // текст уже на нужном языке (список изменений)
    return false;
  }
  function xText(node) {
    if (skipNode(node)) return;
    var v = node.data, e = textStore.get(node), orig = (e && v === e.t) ? e.o : v;
    var out = state.lang === 'ru' ? orig : tr(orig);
    if (!e && out === orig) return;
    textStore.set(node, { o: orig, t: out });
    if (node.data !== out) node.data = out;
  }
  function xAttr(el, name) {
    if (!el.hasAttribute(name)) return;
    var m = attrStore.get(el); if (!m) { m = {}; attrStore.set(el, m); }
    var v = el.getAttribute(name), e = m[name], orig = (e && v === e.t) ? e.o : v;
    var out = state.lang === 'ru' ? orig : tr(orig);
    if (!e && out === orig) return;
    m[name] = { o: orig, t: out };
    if (v !== out) el.setAttribute(name, out);
  }
  function walk(node) {
    var i, kids;
    if (node.nodeType === 3) { xText(node); return; }
    if (node.nodeType !== 1) return;
    if (/^(SCRIPT|STYLE)$/.test(node.nodeName) || node.getAttribute('data-i18n') === 'off') return;
    for (i = 0; i < ATTRS.length; i++) xAttr(node, ATTRS[i]);
    kids = node.childNodes;
    for (i = 0; i < kids.length; i++) walk(kids[i]);
  }
  function onMutations(recs) {
    recs.forEach(function (r) {
      if (r.type === 'characterData') xText(r.target);
      else if (r.type === 'attributes') xAttr(r.target, r.attributeName);
      else Array.prototype.forEach.call(r.addedNodes, walk);
    });
  }
  function attach() {
    if (observer || typeof document === 'undefined' || typeof MutationObserver === 'undefined') return;
    textStore = new WeakMap(); attrStore = new WeakMap();
    observer = new MutationObserver(onMutations);
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }
  function setLang(lang) {
    if (LANGS.indexOf(lang) < 0) lang = 'ru';
    state.lang = lang;
    if (typeof document === 'undefined') return lang;
    attach();
    document.documentElement.setAttribute('lang', lang);
    walk(document.documentElement);
    return lang;
  }

  return { LANGS: LANGS, DATA: DATA, tr: tr, t: t, setLang: setLang, getLang: function () { return state.lang; }, _norm: norm };
});
