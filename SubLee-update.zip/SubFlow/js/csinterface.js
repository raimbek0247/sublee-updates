/* Минимальная замена CSInterface.js (Adobe CEP) — нужны только evalScript и пути. */
(function (w) {
  'use strict';
  function CSInterface() {}

  CSInterface.prototype.evalScript = function (script, cb) {
    w.__adobe_cep__.evalScript(script, cb || function () {});
  };

  CSInterface.prototype.getSystemPath = function (type) {
    var p = decodeURI(w.__adobe_cep__.getSystemPath(type));
    if (/Win/i.test(navigator.platform)) p = p.replace('file:///', '');
    else p = p.replace('file://', '');
    return p;
  };

  CSInterface.prototype.openURL = function (url) {
    try { w.cep.util.openURLInDefaultBrowser(url); } catch (e) { w.open(url); }
  };

  w.CSInterface = CSInterface;
})(window);
