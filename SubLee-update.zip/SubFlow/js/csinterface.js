/* Минимальная замена CSInterface.js (Adobe CEP) — нужны только evalScript и пути. */
(function (w) {
  'use strict';
  function CSInterface() {}

  CSInterface.prototype.evalScript = function (script, cb) {
    w.__adobe_cep__.evalScript(script, cb || function () {});
  };

  CSInterface.prototype.getSystemPath = function (type) {
    var p = decodeURI(w.__adobe_cep__.getSystemPath(type));
    if (/Win/i.test(navigator.platform)) p = p.replace('file:///', '');
    else p = p.replace('file://', '');
    return p;
  };

  CSInterface.prototype.openURL = function (url) {
    try { w.cep.util.openURLInDefaultBrowser(url); } catch (e) { w.open(url); }
  };

  /* цвета интерфейса AE (панель «подстраивается» под яркость, которую выбрал пользователь) */
  CSInterface.prototype.getHostEnvironment = function () {
    try { return JSON.parse(w.__adobe_cep__.getHostEnvironment()); } catch (e) { return null; }
  };
  CSInterface.prototype.addEventListener = function (type, cb) {
    try { w.__adobe_cep__.addEventListener(type, cb); } catch (e) { /* не в AE */ }
  };

  w.CSInterface = CSInterface;
})(window);
