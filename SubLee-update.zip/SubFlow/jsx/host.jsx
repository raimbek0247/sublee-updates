// SubFlow - ExtendScript host (After Effects).
// RULES: ES3 only (no let/const/arrow, no Array.map/forEach/indexOf, no JSON), ASCII only in this file.
// Errors are thrown as codes (E_...) and translated into text by the panel.

var SF_TAG = "SubFlow";
var SF_LABEL = { ru: 8, en: 9, kk: 2, orig: 6 };
var SF_API = {};

/* ------------------------------------------------------------------ utils */
function sf_trim(s) { return String(s).replace(/^\s+|\s+$/g, ""); }

function sf_esc(s) {
  var out = "", i, c, code;
  s = String(s);
  for (i = 0; i < s.length; i++) {
    c = s.charAt(i);
    code = s.charCodeAt(i);
    if (c === "\\") out += "\\\\";
    else if (c === '"') out += '\\"';
    else if (c === "\n") out += "\\n";
    else if (c === "\r") out += "\\r";
    else if (c === "\t") out += "\\t";
    else if (code < 32 || code === 0x2028 || code === 0x2029) out += "\\u" + ("0000" + code.toString(16)).slice(-4);
    else out += c;
  }
  return out;
}

function sf_stringify(v) {
  var t = typeof v, i, a, k;
  if (v === null || v === undefined) return "null";
  if (t === "number") return isFinite(v) ? String(v) : "null";
  if (t === "boolean") return v ? "true" : "false";
  if (t === "string") return '"' + sf_esc(v) + '"';
  if (v instanceof Array) {
    a = [];
    for (i = 0; i < v.length; i++) a.push(sf_stringify(v[i]));
    return "[" + a.join(",") + "]";
  }
  a = [];
  for (k in v) {
    if (v.hasOwnProperty(k) && typeof v[k] !== "function") a.push('"' + sf_esc(k) + '":' + sf_stringify(v[k]));
  }
  return "{" + a.join(",") + "}";
}

function sf_rgb(hex) {
  hex = String(hex || "#ffffff").replace("#", "");
  if (hex.length === 3) hex = hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
  return [parseInt(hex.substr(0, 2), 16) / 255, parseInt(hex.substr(2, 2), 16) / 255, parseInt(hex.substr(4, 2), 16) / 255];
}

function sf_inList(arr, v) {
  var i;
  for (i = 0; i < arr.length; i++) if (arr[i] === v) return true;
  return false;
}

// Same function as SFCore.stripPunct (a test checks both give identical results)
function sf_stripPunct(s) {
  if (s === null || s === undefined) return '';
  var t = String(s);
  var NB = '[^\\s\'\u2019\u2018`"\u00ab\u00bb\u201c\u201d\u201e()\\[\\]{}.,!?;:\u2026]';
  t = t.replace(new RegExp('(' + NB + ')[\'\u2019`](?=' + NB + ')', 'g'), '$1\u0001');
  t = t.replace(/(\d)([.,:])(?=\d)/g, function (m, d, c) {
    return d + (c === '.' ? '\u0004' : (c === ',' ? '\u0005' : '\u0006'));
  });
  t = t.replace(/([^\s\-\u2013\u2014])-(?=[^\s\-\u2013\u2014])/g, '$1\u0007');
  t = t.replace(/[.,!?;:\u2026"\u00ab\u00bb\u201c\u201d\u201e\u201f\u2039\u203a\u2018\u2019`\u00b4()\[\]{}\u00bf\u00a1\u2022\u00b7]/g, '');
  t = t.replace(/[\-\u2013\u2014]/g, '');
  t = t.replace(/\u0001/g, "'").replace(/\u0004/g, '.').replace(/\u0005/g, ',')
    .replace(/\u0006/g, ':').replace(/\u0007/g, '-');
  t = t.replace(/[ \t]+/g, ' ').replace(/ ?([\r\n]) ?/g, '$1');
  return t.replace(/^[ \t]+|[ \t]+$/g, '');
}

function sf_comp() {
  var c = app.project ? app.project.activeItem : null;
  if (!c || !(c instanceof CompItem)) throw new Error("E_NO_COMP");
  return c;
}

/* tag format on layer comment:  SubFlow:<lang>:<anchor b|c|t|s>:<kind t=text x=box p=precomp> */
function sf_info(L) {
  var c = "", p;
  try { c = L.comment; } catch (e) { c = ""; }
  if (!c || c.indexOf(SF_TAG + ":") !== 0) return null;
  p = c.split(":");
  return { lang: p[1], anchor: p[2], kind: p[3] };
}
function sf_mark(L, lang, anchor, kind) { L.comment = SF_TAG + ":" + lang + ":" + anchor + ":" + kind; }

/* all SubFlow layers (descending into SubFlow precomps). opts.selectedOnly, opts.filter(info,layer) */
function sf_collect(comp, opts) {
  var out = [], i, L, inf, j, inner, sub;
  opts = opts || {};
  for (i = 1; i <= comp.numLayers; i++) {
    L = comp.layer(i);
    inf = sf_info(L);
    if (!inf) continue;
    if (inf.kind === "p") {
      if (opts.selectedOnly && !L.selected) continue;
      try {
        sub = L.source;
        if (sub instanceof CompItem) {
          inner = sf_collect(sub, { filter: opts.filter });
          for (j = 0; j < inner.length; j++) out.push(inner[j]);
        }
      } catch (e) { /* ignore */ }
      continue;
    }
    if (opts.selectedOnly && !L.selected) continue;
    if (opts.filter && !opts.filter(inf, L)) continue;
    out.push({ comp: comp, layer: L, info: inf });
  }
  return out;
}

function sf_textProp(L) { return L.property("ADBE Text Properties").property("ADBE Text Document"); }
function sf_tr(L) { return L.property("ADBE Transform Group"); }

/* base for relative sizes: the shorter side, so vertical and horizontal comps get the same caption size */
function sf_base(comp) { return Math.min(comp.width, comp.height); }

function sf_trunc(s, n) {
  s = String(s).replace(/[\r\n\u0003]+/g, " ");
  return s.length > n ? s.substr(0, n) + "..." : s;
}

/* ------------------------------------------------------------------ fonts */
var sf_fontNote = "";

function sf_fontInstalled(name) {
  var f, all, i, j;
  try { f = app.fonts.getFontsByPostScriptName(name); return !!(f && f.length > 0); } catch (e0) { /* API missing */ }
  try {
    all = app.fonts.allFonts;
    for (i = 0; i < all.length; i++) for (j = 0; j < all[i].length; j++) if (all[i][j].postScriptName === name) return true;
    return false;
  } catch (e1) { /* AE older than 24.0 */ }
  return null;
}

/* the wanted font, or Montserrat Bold, or Arial Bold, or Arial - whatever is really installed (never the leftover font of the last text layer) */
function sf_setFont(td, wanted) {
  var list = [wanted, "Montserrat-Bold", "Arial-BoldMT", "ArialMT"], i, name, ok;
  for (i = 0; i < list.length; i++) {
    name = list[i];
    if (!name) continue;
    ok = sf_fontInstalled(name);
    if (ok === false) continue;
    try {
      td.font = name;
      if (ok === true || td.font === name) {
        if (wanted && name !== wanted) sf_fontNote = wanted + " -> " + name;
        return name;
      }
    } catch (e) { /* try the next one */ }
  }
  return "";
}

/* ------------------------------------------------------------------ text document */
function sf_fillDoc(td, st, px, comp) {
  var lh = st.lineHeight > 0 ? st.lineHeight : 1.15;
  try { td.resetCharStyle(); } catch (e0) { /* ignore */ }
  td.fontSize = px;
  sf_setFont(td, st.font);
  td.applyFill = true;
  td.fillColor = sf_rgb(st.fill);
  if (st.useStroke && st.strokeW > 0) {
    td.applyStroke = true;
    td.strokeColor = sf_rgb(st.stroke);
    td.strokeWidth = Math.max(0.5, st.strokeW * sf_base(comp) / 1080);
    try { td.strokeOverFill = false; } catch (e2) { /* ignore */ }
  } else {
    td.applyStroke = false;
  }
  td.justification = ParagraphJustification.CENTER_JUSTIFY;
  try { td.tracking = st.tracking || 0; } catch (e3) { /* ignore */ }
  try { td.autoLeading = false; td.leading = px * lh; } catch (e4) { /* ignore */ }
  return td;
}

function sf_makeDoc(prop, text, st, px, comp) {
  var td = sf_fillDoc(prop.value, st, px, comp);
  td.text = String(text).replace(/\r\n?|\n/g, "\r");
  return td;
}

/* ------------------------------------------------------------------ effects / box */
function sf_setShadow(L, st, px) {
  var fx, i, par, sd, sb, col, dist, soft;
  try {
    par = L.property("ADBE Effect Parade");
    for (i = par.numProperties; i >= 1; i--) {
      if (par.property(i).name === "SF Shadow") par.property(i).remove();
    }
    if (!st.shadow) return;
    sd = (st.shadowDist === undefined || st.shadowDist === null) ? 1 : st.shadowDist;
    sb = (st.shadowBlur === undefined || st.shadowBlur === null) ? 1 : st.shadowBlur;
    col = sf_rgb(st.shadowColor || "#000000");
    dist = sd > 0 ? Math.max(2, px * 0.06 * sd) : 0;
    soft = sb > 0 ? Math.max(3, px * 0.14 * sb) : 0;
    fx = par.addProperty("ADBE Drop Shadow");
    fx.name = "SF Shadow";
    fx.property("ADBE Drop Shadow-0001").setValue([col[0], col[1], col[2], 1]);
    fx.property("ADBE Drop Shadow-0002").setValue(255 * (st.shadowOpacity > 0 ? st.shadowOpacity : 60) / 100);
    fx.property("ADBE Drop Shadow-0003").setValue(180);
    fx.property("ADBE Drop Shadow-0004").setValue(dist);
    fx.property("ADBE Drop Shadow-0005").setValue(soft);
  } catch (e) { /* effect missing - not critical */ }
}

function sf_boxOf(L) {
  var inf = sf_info(L), c, cand, ci;
  if (!inf || inf.kind !== "t") return null;
  try {
    c = L.containingComp;
    if (L.index >= c.numLayers) return null;
    cand = c.layer(L.index + 1);
    ci = sf_info(cand);
    if (ci && ci.kind === "x" && ci.lang === inf.lang && Math.abs(cand.inPoint - L.inPoint) < 0.001) return cand;
  } catch (e) { /* ignore */ }
  return null;
}

function sf_fitBox(L, B, st, px, keepLook) {
  var t = L.inPoint + (L.outPoint - L.inPoint) / 2;
  var r = L.sourceRectAtTime(t, false);
  var trT = sf_tr(L), trB = sf_tr(B);
  var anc = trT.property("ADBE Anchor Point").value;
  var pos = trT.property("ADBE Position").numKeys > 0 ? trT.property("ADBE Position").valueAtTime(t, false) : trT.property("ADBE Position").value;
  var padX = px * (st.boxPadX > 0 ? st.boxPadX : 0.45);
  var padY = px * (st.boxPadY > 0 ? st.boxPadY : 0.2);
  var w = r.width + padX * 2, h = r.height + padY * 2;
  var grp = B.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
  var rect = grp.property("ADBE Vector Shape - Rect");
  rect.property("ADBE Vector Rect Size").setValue([w, h]);
  rect.property("ADBE Vector Rect Roundness").setValue((Math.min(w, h) / 2) * (st.boxRound >= 0 ? st.boxRound : 0.35));
  if (!keepLook) grp.property("ADBE Vector Graphic - Fill").property("ADBE Vector Fill Color").setValue(sf_rgb(st.boxColor || "#000000"));
  trB.property("ADBE Anchor Point").setValue([anc[0] - (r.left + r.width / 2), anc[1] - (r.top + r.height / 2)]);
  trB.property("ADBE Position").setValue([pos[0], pos[1]]);
  if (!keepLook) trB.property("ADBE Opacity").setValue(st.boxOpacity >= 0 ? st.boxOpacity : 70);
}

function sf_addBox(comp, L, st, px, lang, cap) {
  var B = comp.layers.addShape();
  var g = B.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
  g.property("ADBE Vectors Group").addProperty("ADBE Vector Shape - Rect");
  g.property("ADBE Vectors Group").addProperty("ADBE Vector Graphic - Fill");
  B.name = "[" + lang.toUpperCase() + "] box";
  B.startTime = cap.start;
  B.outPoint = cap.end;
  sf_mark(B, lang, "b", "x");
  try { B.label = SF_LABEL[lang] || 0; } catch (e) { /* ignore */ }
  sf_fitBox(L, B, st, px);
  B.moveAfter(L);
  return B;
}

/* ------------------------------------------------------------------ create */
function sf_deleteLayers(comp, filter) {
  var items = sf_collect(comp, {}), i, n = 0, L, pcs = [];
  var rm = [];
  for (i = 0; i < comp.numLayers; i++) { /* find precomp wrappers */
    var w = comp.layer(i + 1), wi = sf_info(w);
    if (wi && wi.kind === "p") pcs.push(w);
  }
  for (i = 0; i < pcs.length; i++) {
    if (!filter || filter({ lang: "-", kind: "p" }, pcs[i])) {
      try { rm.push(pcs[i].source); } catch (e) { /* ignore */ }
      pcs[i].remove(); n++;
    }
  }
  for (i = 0; i < rm.length; i++) { try { rm[i].remove(); } catch (e2) { /* still used */ } }
  items = sf_collect(comp, {});
  for (i = items.length - 1; i >= 0; i--) {
    L = items[i].layer;
    if (!filter || filter(items[i].info, L)) { try { L.remove(); n++; } catch (e3) { /* ignore */ } }
  }
  return n;
}

function sf_countLines(text) {
  var m = String(text).split(/\n/);
  return m.length;
}

SF_API.createCaptions = function (a) {
  var comp = sf_comp();
  sf_fontNote = "";
  var st = a.style, lay = a.layout, sets = a.sets;
  var px = Math.max(6, Math.round(sf_base(comp) * st.sizePct / 100));
  var lh = st.lineHeight > 0 ? st.lineHeight : 1.15;
  var mode = a.mode === "single" ? "single" : "multi";
  var posName = lay.pos === "top" ? "t" : (lay.pos === "center" ? "c" : "b");
  var baseFrac = lay.y > 0 ? lay.y / 100 : (posName === "t" ? 0.08 : (posName === "c" ? 0.5 : (comp.height > comp.width ? 0.78 : 0.9)));
  var made = [], created = 0, errors = [], si, ci, i, maxLines0 = 1, langs = [], res = {};

  for (si = 0; si < sets.length; si++) langs.push(sets[si].lang);
  for (ci = 0; ci < sets[0].captions.length; ci++) {
    i = sf_countLines(sets[0].captions[ci].text);
    if (i > maxLines0) maxLines0 = i;
  }
  var gap = px * lh * maxLines0 + px * 0.3;

  app.beginUndoGroup("SubLee: subtitles");
  try {
    if (a.replace) {
      /* replace only what overlaps the time range of the new captions, so other clips keep their subtitles */
      var t0 = 1e9, t1 = -1e9;
      for (si = 0; si < sets.length; si++) {
        for (ci = 0; ci < sets[si].captions.length; ci++) {
          if (sets[si].captions[ci].start < t0) t0 = sets[si].captions[ci].start;
          if (sets[si].captions[ci].end > t1) t1 = sets[si].captions[ci].end;
        }
      }
      sf_deleteLayers(comp, function (inf, L) {
        if (!(inf.kind === "p" || sf_inList(langs, inf.lang))) return false;
        try { return L.inPoint < t1 - 0.01 && L.outPoint > t0 + 0.01; } catch (eo) { return false; }
      });
    }
    for (si = 0; si < sets.length; si++) {
      var set = sets[si], caps = set.captions, lang = set.lang;
      var yPx = baseFrac * comp.height, shift;
      if (posName === "t") yPx += si * gap;
      else if (posName === "c") yPx += (si - (sets.length - 1) / 2) * gap;
      else yPx -= si * gap;

      if (mode === "single") {
        try { made.push(sf_createSingle(comp, set, st, px, lh, posName, yPx, maxLines0)); created += caps.length; }
        catch (es) { errors.push(String(es.message || es)); }
        continue;
      }
      for (ci = 0; ci < caps.length; ci++) {
        try {
          var L = sf_createOne(comp, caps[ci], lang, st, px, posName, yPx);
          made.push(L);
          if (st.box) { try { made.push(sf_addBox(comp, L, st, px, lang, caps[ci])); } catch (eb) { if (errors.length < 3) errors.push("box: " + String(eb.message || eb)); } }
          created++;
        } catch (e) {
          if (errors.length < 3) errors.push(String(e.message || e));
        }
      }
    }
    res.precomp = false;
    if (a.precomp && made.length) {
      var idx = [], k, pc, pl;
      for (k = 0; k < made.length; k++) idx.push(made[k].index);
      idx.sort(function (x, y) { return x - y; });
      pc = comp.layers.precompose(idx, "SubFlow Captions", true);
      for (k = 1; k <= comp.numLayers; k++) {
        pl = comp.layer(k);
        try { if (pl.source === pc) { sf_mark(pl, "-", "-", "p"); break; } } catch (e5) { /* ignore */ }
      }
      res.precomp = true;
    }
  } finally {
    app.endUndoGroup();
  }
  res.created = created;
  res.errors = errors;
  res.fontNote = sf_fontNote;
  return res;
};

function sf_timing(L, s, e) {
  L.startTime = s;
  L.outPoint = e;
}

function sf_createOne(comp, cap, lang, st, px, posName, yPx) {
  var L = comp.layers.addText("x");
  var tp = sf_textProp(L);
  tp.setValue(sf_makeDoc(tp, cap.text, st, px, comp));
  sf_timing(L, cap.start, cap.end);
  var tr = sf_tr(L);
  var r = L.sourceRectAtTime(L.inPoint, false);
  var ax = r.left + r.width / 2;
  var ay = posName === "b" ? r.top + r.height : (posName === "t" ? r.top : r.top + r.height / 2);
  tr.property("ADBE Anchor Point").setValue([ax, ay]);
  tr.property("ADBE Position").setValue([comp.width / 2, yPx]);
  L.name = "[" + lang.toUpperCase() + "] " + sf_trunc(cap.text, 42);
  sf_mark(L, lang, posName, "t");
  try { L.label = SF_LABEL[lang] || 0; } catch (e) { /* ignore */ }
  sf_setShadow(L, st, px);
  return L;
}

function sf_createSingle(comp, set, st, px, lh, posName, yPx, maxLines) {
  var caps = set.captions, i, tp, L, d, tr, y;
  L = comp.layers.addText("x");
  tp = sf_textProp(L);
  L.startTime = 0;
  tp.setValue(sf_makeDoc(tp, caps[0].text, st, px, comp));
  for (i = 0; i < caps.length; i++) {
    tp.setValueAtTime(caps[i].start, sf_makeDoc(tp, caps[i].text, st, px, comp));
    if (i + 1 >= caps.length || caps[i + 1].start - caps[i].end > 0.01) {
      tp.setValueAtTime(caps[i].end, sf_makeDoc(tp, "", st, px, comp));
    }
  }
  L.inPoint = caps[0].start;
  L.outPoint = caps[caps.length - 1].end;
  tr = sf_tr(L);
  var block = maxLines * px * lh;
  if (posName === "b") y = yPx - px * 0.25 - (maxLines - 1) * px * lh;
  else if (posName === "t") y = yPx + px * 0.8;
  else y = yPx - block / 2 + px * 0.8;
  tr.property("ADBE Anchor Point").setValue([0, 0]);
  tr.property("ADBE Position").setValue([comp.width / 2, y]);
  L.name = "[" + set.lang.toUpperCase() + "] subtitles";
  sf_mark(L, set.lang, "s", "t");
  try { L.label = SF_LABEL[set.lang] || 0; } catch (e) { /* ignore */ }
  sf_setShadow(L, st, px);
  return L;
}

/* ------------------------------------------------------------------ context / fonts */
SF_API.ping = function () {
  return { version: String(app.version), os: $.os };
};

SF_API.getContext = function () {
  var comp = sf_comp();
  var res = {
    aeVersion: String(app.version),
    comp: { name: comp.name, width: comp.width, height: comp.height, fps: comp.frameRate, duration: comp.duration, time: comp.time,
      workStart: comp.workAreaStart, workDur: comp.workAreaDuration },
    layers: [], all: [], sfCount: 0, langs: {}
  };
  var i, L, inf, o, src, st, sd;
  function describe(Lyr) {
    var d = { index: Lyr.index, name: Lyr.name, file: "", hasAudio: false, note: "" };
    try {
      src = Lyr.source;
      if (src && src instanceof FootageItem) {
        if (src.mainSource instanceof FileSource && src.mainSource.file) d.file = src.mainSource.file.fsName;
        d.hasAudio = src.hasAudio !== false;
        st = Lyr.stretch;
        if (!st || st <= 0) st = 100;
        d.stretch = st;
        d.inPoint = Lyr.inPoint;
        d.outPoint = Lyr.outPoint;
        d.startTime = Lyr.startTime;
        d.srcStart = Math.max(0, (Lyr.inPoint - Lyr.startTime) * 100 / st);
        d.srcDur = (Lyr.outPoint - Lyr.inPoint) * 100 / st;
        sd = src.duration;
        if (sd > 0 && d.srcStart + d.srcDur > sd) d.srcDur = Math.max(0.1, sd - d.srcStart);
        if (Lyr.timeRemapEnabled) d.note = "remap";
        if (!d.file) d.note = "nofile";
      } else if (src && src instanceof CompItem) {
        d.note = "precomp";
      } else {
        d.note = "notmedia";
      }
    } catch (e) { d.note = "error"; }
    return d;
  }
  for (i = 1; i <= comp.numLayers; i++) {
    L = comp.layer(i);
    inf = sf_info(L);
    if (inf) {
      if (inf.kind === "t") { res.sfCount++; res.langs[inf.lang] = (res.langs[inf.lang] || 0) + 1; }
      continue;
    }
    o = describe(L);
    if (o.file && o.hasAudio && res.all.length < 30) res.all.push(o);
    if (L.selected) res.layers.push(o);
  }
  return res;
};

SF_API.listFonts = function () {
  var out = [], all, i, j;
  try {
    all = app.fonts.allFonts;
    for (i = 0; i < all.length; i++) {
      for (j = 0; j < all[i].length; j++) {
        out.push({ ps: all[i][j].postScriptName, fam: all[i][j].familyName, sty: all[i][j].styleName });
      }
    }
  } catch (e) { /* AE older than 24.0 has no app.fonts */ }
  return { fonts: out };
};

/* ------------------------------------------------------------------ select / delete / punctuation */
SF_API.selectAll = function () {
  var comp = sf_comp(), i, n = 0;
  for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
  for (i = 1; i <= comp.numLayers; i++) {
    if (sf_info(comp.layer(i))) { comp.layer(i).selected = true; n++; }   /* text, box and precomp wrapper layers */
  }
  return { count: n };
};

SF_API.deleteAll = function (a) {
  var comp = sf_comp(), n;
  app.beginUndoGroup("SubLee: delete");
  try {
    n = sf_deleteLayers(comp, function (inf) { return !a.lang || inf.kind === "p" || inf.lang === a.lang; });
  } finally { app.endUndoGroup(); }
  return { count: n };
};

function sf_targets(comp, a, kindWanted) {
  var items = sf_collect(comp, { selectedOnly: !!a.selectedOnly }), out = [], i;
  if (a.selectedOnly && !items.length) items = sf_collect(comp, {});
  for (i = 0; i < items.length; i++) if (items[i].info.kind === kindWanted) out.push(items[i]);
  return out;
}

SF_API.stripPunct = function (a) {
  var comp = sf_comp(), t = sf_targets(comp, a, "t"), i, k, tp, td, n = 0;
  app.beginUndoGroup("SubLee: remove punctuation");
  try {
    for (i = 0; i < t.length; i++) {
      tp = sf_textProp(t[i].layer);
      if (tp.numKeys > 0) {
        for (k = 1; k <= tp.numKeys; k++) { td = tp.keyValue(k); td.text = sf_stripPunct(td.text); tp.setValueAtKey(k, td); }
      } else {
        td = tp.value;
        td.text = sf_stripPunct(td.text);
        tp.setValue(td);
      }
      n++;
    }
  } finally { app.endUndoGroup(); }
  return { count: n };
};

SF_API.toggleLang = function (a) {
  var comp = sf_comp(), items = sf_collect(comp, { filter: function (inf) { return inf.lang === a.lang; } }), i;
  app.beginUndoGroup("SubLee: toggle language");
  try { for (i = 0; i < items.length; i++) items[i].layer.enabled = !!a.visible; } finally { app.endUndoGroup(); }
  return { count: items.length };
};

SF_API.getCaptions = function () {
  var comp = sf_comp(), t = sf_collect(comp, {}), out = [], i, k, L, tp, nk, txt;
  for (i = 0; i < t.length; i++) {
    if (t[i].info.kind !== "t") continue;
    L = t[i].layer;
    tp = sf_textProp(L);
    nk = tp.numKeys;
    if (nk > 0) {
      for (k = 1; k <= nk; k++) {
        txt = String(tp.keyValue(k).text).replace(/\r\n?|\u0003/g, "\n");
        if (!txt) continue;
        out.push({ lang: t[i].info.lang, start: tp.keyTime(k), end: k < nk ? tp.keyTime(k + 1) : L.outPoint, text: txt });
      }
    } else {
      txt = String(tp.value.text).replace(/\r\n?|\u0003/g, "\n");
      out.push({ lang: t[i].info.lang, start: L.inPoint, end: L.outPoint, text: txt });
    }
  }
  out.sort(function (x, y) { return x.start - y.start; });
  return { captions: out };
};

/* ------------------------------------------------------------------ style on existing layers */
SF_API.applyStyle = function (a) {
  var comp = sf_comp(), st = a.style, t = sf_targets(comp, a, "t");
  sf_fontNote = "";
  var px = Math.max(6, Math.round(sf_base(comp) * st.sizePct / 100));
  var i, k, L, tp, td, n = 0, r, ax, ay, B, mode;
  app.beginUndoGroup("SubLee: style");
  try {
    for (i = 0; i < t.length; i++) {
      L = t[i].layer;
      mode = t[i].info.anchor;
      tp = sf_textProp(L);
      if (tp.numKeys > 0) {
        for (k = 1; k <= tp.numKeys; k++) {
          td = sf_fillDoc(tp.keyValue(k), st, px, comp);
          if (st.uppercase) td.text = String(td.text).toUpperCase();
          tp.setValueAtKey(k, td);
        }
      } else {
        td = sf_fillDoc(tp.value, st, px, comp);
        if (st.uppercase) td.text = String(td.text).toUpperCase();
        tp.setValue(td);
      }
      sf_setShadow(L, st, px);
      if (mode === "b" || mode === "c" || mode === "t") {
        r = L.sourceRectAtTime(L.inPoint + (L.outPoint - L.inPoint) / 2, false);
        ax = r.left + r.width / 2;
        ay = mode === "b" ? r.top + r.height : (mode === "t" ? r.top : r.top + r.height / 2);
        sf_tr(L).property("ADBE Anchor Point").setValue([ax, ay]);
        B = sf_boxOf(L);
        if (B) { try { sf_fitBox(L, B, st, px); } catch (eb) { /* ignore */ } }
      }
      n++;
    }
  } finally { app.endUndoGroup(); }
  return { count: n, fontNote: sf_fontNote };
};

/* ------------------------------------------------------------------ text size only (colors, shadow look, box look stay) */
SF_API.applySize = function (a) {
  var comp = sf_comp(), st = a.style, t = sf_targets(comp, a, "t");
  var px = Math.max(6, Math.round(sf_base(comp) * st.sizePct / 100));
  var i, k, L, tp, td, n = 0, r, ax, ay, B, mode, oldPx, ratio, par, j, fx;
  app.beginUndoGroup("SubLee: size");
  try {
    for (i = 0; i < t.length; i++) {
      L = t[i].layer;
      mode = t[i].info.anchor;
      tp = sf_textProp(L);
      td = tp.numKeys > 0 ? tp.keyValue(1) : tp.value;
      oldPx = td.fontSize > 0 ? td.fontSize : px;
      if (tp.numKeys > 0) {
        for (k = 1; k <= tp.numKeys; k++) {
          td = tp.keyValue(k);
          td.fontSize = px;
          tp.setValueAtKey(k, td);
        }
      } else {
        td = tp.value;
        td.fontSize = px;
        tp.setValue(td);
      }
      ratio = px / oldPx;
      try {
        par = L.property("ADBE Effect Parade");
        for (j = 1; j <= par.numProperties; j++) {
          if (par.property(j).name === "SF Shadow") {
            fx = par.property(j);
            fx.property("ADBE Drop Shadow-0004").setValue(fx.property("ADBE Drop Shadow-0004").value * ratio);
            fx.property("ADBE Drop Shadow-0005").setValue(fx.property("ADBE Drop Shadow-0005").value * ratio);
          }
        }
      } catch (es) { /* shadow missing - not critical */ }
      if (mode === "b" || mode === "c" || mode === "t") {
        r = L.sourceRectAtTime(L.inPoint + (L.outPoint - L.inPoint) / 2, false);
        ax = r.left + r.width / 2;
        ay = mode === "b" ? r.top + r.height : (mode === "t" ? r.top : r.top + r.height / 2);
        sf_tr(L).property("ADBE Anchor Point").setValue([ax, ay]);
        B = sf_boxOf(L);
        if (B) { try { sf_fitBox(L, B, st, px, true); } catch (eb) { /* ignore */ } }
      }
      n++;
    }
  } finally { app.endUndoGroup(); }
  return { count: n, px: px };
};

/* ------------------------------------------------------------------ animation */
function sf_dimVal(prop, v) {
  var cur = prop.value, out = [], i;
  for (i = 0; i < cur.length; i++) out.push(v);
  return out;
}

function sf_ease(prop, k) {
  var tries = [1, 2, 3], i, j, arr;
  for (i = 0; i < tries.length; i++) {
    try {
      arr = [];
      for (j = 0; j < tries[i]; j++) arr.push(new KeyframeEase(0, 66));
      prop.setTemporalEaseAtKey(k, arr, arr);
      return;
    } catch (e) { /* wrong dimension count - try next */ }
  }
}

function sf_keys(prop, pairs) {
  var i, k;
  for (i = 0; i < pairs.length; i++) {
    k = prop.addKey(pairs[i][0]);
    prop.setValueAtKey(k, pairs[i][1]);
  }
  for (i = 1; i <= prop.numKeys; i++) sf_ease(prop, i);
}

function sf_clearAnim(L) {
  var tr = sf_tr(L), pOp = tr.property("ADBE Opacity"), pSc = tr.property("ADBE Scale"), pPos = tr.property("ADBE Position");
  var pRot = tr.property("ADBE Rotate Z"), par, fxi;
  var mid = L.inPoint + (L.outPoint - L.inPoint) / 2, base, opBase, i, an;
  try { pPos.expression = ""; } catch (ex1) { /* ignore */ }
  try { pOp.expression = ""; } catch (ex2) { /* ignore */ }
  try { pSc.expression = ""; } catch (ex3) { /* ignore */ }
  opBase = pOp.numKeys > 0 ? pOp.valueAtTime(mid, false) : pOp.value;
  if (pPos.numKeys > 0) {
    base = pPos.valueAtTime(mid, false);
    while (pPos.numKeys > 0) pPos.removeKey(1);
    pPos.setValue(base);
  }
  if (pOp.numKeys > 0) {
    while (pOp.numKeys > 0) pOp.removeKey(1);
    pOp.setValue(opBase);
  }
  if (pSc.numKeys > 0) { while (pSc.numKeys > 0) pSc.removeKey(1); }
  pSc.setValue(sf_dimVal(pSc, 100));
  try {
    if (pRot.numKeys > 0) { while (pRot.numKeys > 0) pRot.removeKey(1); }
    pRot.setValue(0);
  } catch (ex4) { /* ignore */ }
  try {
    par = L.property("ADBE Effect Parade");
    for (fxi = par.numProperties; fxi >= 1; fxi--) if (par.property(fxi).name === "SF Blur") par.property(fxi).remove();
  } catch (ex5) { /* ignore */ }
  try {
    an = L.property("ADBE Text Properties").property("ADBE Text Animators");
    for (i = an.numProperties; i >= 1; i--) if (an.property(i).name.indexOf("SF ") === 0) an.property(i).remove();
  } catch (e) { /* shape layer has no text animators */ }
  sf_fxMarkerClear(L, "SF In");
  sf_fxMarkerClear(L, "SF Out");
}

function sf_boxMarker(L) {
  var inf = sf_info(L);
  return inf && inf.kind === "x";
}

function sf_typewriter(L, d, t0, nChars) {
  var dur = L.outPoint - L.inPoint;
  var dt = Math.min(dur * 0.6, Math.max(d, nChars * 0.035));
  var an = L.property("ADBE Text Properties").property("ADBE Text Animators").addProperty("ADBE Text Animator");
  var sels, sel, start;
  an.name = "SF Typewriter";
  an.property("ADBE Text Animator Properties").addProperty("ADBE Text Opacity").setValue(0);
  sels = an.property("ADBE Text Selectors");
  if (sels.numProperties === 0) sels.addProperty("ADBE Text Selector");
  sel = sels.property(1);
  start = sel.property("ADBE Text Percent Start");
  start.setValueAtTime(t0, 0);
  start.setValueAtTime(t0 + dt, 100);
}

function sf_letters(L, d, t0, nChars, rise, pw) {
  var dur = L.outPoint - L.inPoint;
  var dt = Math.min(dur * 0.7, Math.max(d, nChars * 0.045));
  var an = L.property("ADBE Text Properties").property("ADBE Text Animators").addProperty("ADBE Text Animator");
  var props, sels, sel, off;
  an.name = "SF Letters";
  props = an.property("ADBE Text Animator Properties");
  props.addProperty("ADBE Text Opacity").setValue(0);
  props.addProperty("ADBE Text Position 3D").setValue([0, rise * pw, 0]);
  sels = an.property("ADBE Text Selectors");
  if (sels.numProperties === 0) sels.addProperty("ADBE Text Selector");
  sel = sels.property(1);
  off = sel.property("ADBE Text Percent Offset");
  off.setValueAtTime(t0, 0);
  off.setValueAtTime(t0 + dt, 100);
}

function sf_trackIn(L, d, t0, pw) {
  var an = L.property("ADBE Text Properties").property("ADBE Text Animators").addProperty("ADBE Text Animator");
  var tk;
  an.name = "SF Tracking";
  tk = an.property("ADBE Text Animator Properties").addProperty("ADBE Text Tracking Amount");
  tk.setValueAtTime(t0, 70 * pw);
  tk.setValueAtTime(t0 + d * 1.6, 0);
}

function sf_blurIn(L, t0, d, pw) {
  var fx = L.property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2"), b;
  fx.name = "SF Blur";
  b = fx.property("ADBE Gaussian Blur 2-0001");
  b.setValueAtTime(t0, 45 * pw);
  b.setValueAtTime(t0 + d, 0);
}

function sf_animOne(L, comp, p, nChars) {
  var tr = sf_tr(L), pOp = tr.property("ADBE Opacity"), pSc = tr.property("ADBE Scale"), pPos = tr.property("ADBE Position");
  var pRot = tr.property("ADBE Rotate Z");
  var dur = L.outPoint - L.inPoint, fps = comp.frameRate;
  var d = p.frames / fps, t0 = L.inPoint, t1 = L.outPoint, isBox = sf_boxMarker(L), base, px, opMax;
  var pw = (p.power > 0 ? p.power : 100) / 100;
  if (d > dur * 0.4) d = dur * 0.4;
  if (d < 1 / fps) d = 1 / fps;
  px = sf_base(comp) * 0.05;
  sf_clearAnim(L);
  if (p.preset === "none") return;
  opMax = pOp.value;
  base = pPos.value;
  var pre = p.preset;
  if (isBox && (pre === "type" || pre === "letters" || pre === "tracking")) pre = "fade";
  var hasOut = p.out && dur > d * 2.5;
  var outOp = hasOut ? [[t1 - d * 0.6, opMax], [t1, 0]] : [];
  var j, up, mid, down;

  if (pre === "fade") {
    sf_keys(pOp, [[t0, 0], [t0 + d, opMax]].concat(hasOut ? [[t1 - d, opMax], [t1, 0]] : []));
  } else if (pre === "pop") {
    sf_keys(pSc, [[t0, sf_dimVal(pSc, 100 - 30 * pw)], [t0 + d * 0.65, sf_dimVal(pSc, 100 + 8 * pw)], [t0 + d, sf_dimVal(pSc, 100)]]
      .concat(hasOut ? [[t1 - d * 0.6, sf_dimVal(pSc, 100)], [t1, sf_dimVal(pSc, 85)]] : []));
    sf_keys(pOp, [[t0, 0], [t0 + d * 0.5, opMax]].concat(outOp));
  } else if (pre === "bounce") {
    sf_keys(pSc, [[t0, sf_dimVal(pSc, 0)], [t0 + d * 0.5, sf_dimVal(pSc, 100 + 18 * pw)], [t0 + d * 0.75, sf_dimVal(pSc, 100 - 7 * pw)], [t0 + d, sf_dimVal(pSc, 100)]]
      .concat(hasOut ? [[t1 - d * 0.6, sf_dimVal(pSc, 100)], [t1, sf_dimVal(pSc, 0)]] : []));
    sf_keys(pOp, [[t0, 0], [t0 + d * 0.3, opMax]].concat(outOp));
  } else if (pre === "slide") {
    up = []; mid = []; down = [];
    for (j = 0; j < base.length; j++) { up.push(base[j]); mid.push(base[j]); down.push(base[j]); }
    up[1] = base[1] + px * 0.9 * pw;
    down[1] = base[1] - px * 0.5 * pw;
    sf_keys(pPos, [[t0, up], [t0 + d, mid]].concat(hasOut ? [[t1 - d, mid], [t1, down]] : []));
    sf_keys(pOp, [[t0, 0], [t0 + d * 0.7, opMax]].concat(hasOut ? [[t1 - d * 0.7, opMax], [t1, 0]] : []));
  } else if (pre === "type") {
    sf_typewriter(L, d, t0, nChars);
  } else if (pre === "stomp") {
    sf_keys(pSc, [[t0, sf_dimVal(pSc, 100 + 70 * pw)], [t0 + d * 0.55, sf_dimVal(pSc, 100 - 4 * pw)], [t0 + d * 0.8, sf_dimVal(pSc, 100)]]
      .concat(hasOut ? [[t1 - d * 0.5, sf_dimVal(pSc, 100)], [t1, sf_dimVal(pSc, 100)]] : []));
    sf_keys(pOp, [[t0, 0], [t0 + d * 0.25, opMax]].concat(outOp));
  } else if (pre === "drop") {
    up = []; mid = []; down = [];
    for (j = 0; j < base.length; j++) { up.push(base[j]); mid.push(base[j]); down.push(base[j]); }
    up[1] = base[1] - px * 1.8 * pw;
    mid[1] = base[1] + px * 0.2 * pw;
    sf_keys(pPos, [[t0, up], [t0 + d * 0.65, mid], [t0 + d, base]]);
    sf_keys(pOp, [[t0, 0], [t0 + d * 0.3, opMax]].concat(outOp));
  } else if (pre === "zoom") {
    sf_keys(pSc, [[t0, sf_dimVal(pSc, 100)], [t1, sf_dimVal(pSc, 100 + 10 * pw)]]);
    sf_keys(pOp, [[t0, 0], [t0 + d * 0.8, opMax]].concat(outOp));
  } else if (pre === "spin") {
    sf_keys(pRot, [[t0, -12 * pw], [t0 + d, 0]]);
    sf_keys(pSc, [[t0, sf_dimVal(pSc, 100 - 40 * pw)], [t0 + d * 0.7, sf_dimVal(pSc, 104)], [t0 + d, sf_dimVal(pSc, 100)]]);
    sf_keys(pOp, [[t0, 0], [t0 + d * 0.5, opMax]].concat(outOp));
  } else if (pre === "blur") {
    sf_blurIn(L, t0, d, pw);
    sf_keys(pOp, [[t0, 0], [t0 + d * 0.8, opMax]].concat(outOp));
  } else if (pre === "wiggle") {
    pPos.expression = "wiggle(6, " + (px * 0.08 * pw).toFixed(2) + ");";
    sf_keys(pOp, [[t0, 0], [t0 + d * 0.5, opMax]].concat(outOp));
  } else if (pre === "flicker") {
    pOp.expression = "var t = time - inPoint; seedRandom(Math.floor(inPoint * 1000) + Math.floor(t * 24), true); (t < " + (0.15 + 0.3 * pw).toFixed(2) + " && random() < 0.5) ? value * 0.15 : value;";
  } else if (pre === "letters") {
    sf_letters(L, d, t0, nChars, px * 0.9, pw);
  } else if (pre === "tracking") {
    sf_trackIn(L, d, t0, pw);
    sf_keys(pOp, [[t0, 0], [t0 + d * 0.8, opMax]].concat(outOp));
  }
}

SF_API.applyAnimation = function (a) {
  var comp = sf_comp(), items = sf_collect(comp, { selectedOnly: !!a.selectedOnly }), i, n = 0, tp, txt;
  if (a.selectedOnly && !items.length) items = sf_collect(comp, {});
  app.beginUndoGroup("SubLee: animation");
  try {
    for (i = 0; i < items.length; i++) {
      txt = "";
      if (items[i].info.kind === "t") {
        tp = sf_textProp(items[i].layer);
        if (tp.numKeys > 0) continue;   /* single-layer mode has no per-caption timing - skipped */
        txt = String(tp.value.text);
      }
      sf_animOne(items[i].layer, comp, a, txt.length);
      n++;
    }
  } finally { app.endUndoGroup(); }
  return { count: n };
};

/* ------------------------------------------------------------------ text effects (per-word / per-character animators, In and Out) */
function sf_selProp(sel, name) {
  var g;
  try { g = sel.property("ADBE Text Range Advanced"); if (g) return g.property(name); } catch (e0) { /* no group */ }
  try { return sel.property(name); } catch (e1) { /* ignore */ }
  return null;
}

function sf_setSel(sel, sp, isOut) {
  var unit = sp.u === "w" ? 3 : (sp.u === "l" ? 4 : 1), p;
  p = sf_selProp(sel, "ADBE Text Range Type2");
  try { if (p) p.setValue(unit); } catch (e1) { /* ignore */ }
  p = sf_selProp(sel, "ADBE Text Range Shape");
  try { if (p) p.setValue(sp.sh ? 1 : (isOut ? 3 : 2)); } catch (e2) { /* ignore */ }
  if (sp.sh) {
    p = sf_selProp(sel, "ADBE Text Selector Smoothness");
    try { if (p) p.setValue(0); } catch (e3) { /* ignore */ }
  }
  if (sp.r) {
    p = sf_selProp(sel, "ADBE Text Randomize Order");
    try { if (p) p.setValue(1); } catch (e4) { /* ignore */ }
  }
}

function sf_fxAdd(props, match, val) {
  try { props.addProperty(match).setValue(val); } catch (e) { /* property not available in this AE version */ }
}

/* k = +1 for In (comes from the offset), -1 for Out (keeps going the same way); pw = strength 0..2 */
function sf_fxProps(an, sp, k, px, pw) {
  var props = an.property("ADBE Text Animator Properties"), q = px * k * pw, sc;
  sf_fxAdd(props, "ADBE Text Opacity", sp.o === undefined ? 0 : sp.o);
  if (sp.x || sp.y || sp.z) sf_fxAdd(props, "ADBE Text Position 3D", [(sp.x || 0) * q, (sp.y || 0) * q, (sp.z || 0) * q]);
  if (sp.s !== undefined) { sc = 100 + (sp.s - 100) * pw; if (sc < 0) sc = 0; sf_fxAdd(props, "ADBE Text Scale 3D", [sc, sc, sc]); }
  if (sp.t) sf_fxAdd(props, "ADBE Text Rotation", sp.t * k * pw);
  if (sp.rx) sf_fxAdd(props, "ADBE Text Rotation X", sp.rx * k * pw);
  if (sp.ry) sf_fxAdd(props, "ADBE Text Rotation Y", sp.ry * k * pw);
  if (sp.ax || sp.ay) sf_fxAdd(props, "ADBE Text Anchor Point 3D", [(sp.ax || 0) * q, (sp.ay || 0) * q, 0]);
  if (sp.b) sf_fxAdd(props, "ADBE Text Blur", [sp.b * px * pw, sp.b * px * pw]);
  if (sp.k) sf_fxAdd(props, "ADBE Text Tracking Amount", sp.k * pw);
}

function sf_clearFx(L, which) {
  var an, i, nm;
  try {
    an = L.property("ADBE Text Properties").property("ADBE Text Animators");
    for (i = an.numProperties; i >= 1; i--) {
      nm = an.property(i).name;
      if ((which !== "out" && nm === "SF FX In") || (which !== "in" && nm === "SF FX Out")) an.property(i).remove();
    }
  } catch (e) { /* shape layer */ }
  if (which !== "out") sf_fxMarkerClear(L, "SF In");
  if (which !== "in") sf_fxMarkerClear(L, "SF Out");
}

function sf_fxFind(L, name) {
  var an, i;
  try {
    an = L.property("ADBE Text Properties").property("ADBE Text Animators");
    for (i = 1; i <= an.numProperties; i++) if (an.property(i).name === name) return an.property(i);
  } catch (e) { /* ignore */ }
  return null;
}

/* layer markers "SF In" / "SF Out": the user drags them to set how long the in / out animation lasts */
function sf_fxMarkerClear(L, name) {
  var mk, i;
  try {
    mk = L.property("ADBE Marker");
    for (i = mk.numKeys; i >= 1; i--) if (name === undefined || mk.keyValue(i).comment === name) mk.removeKey(i);
  } catch (e) { /* no markers */ }
}

function sf_fxMarkerSet(L, name, t) {
  sf_fxMarkerClear(L, name);
  L.property("ADBE Marker").setValueAtTime(t, new MarkerValue(name));
}

function sf_fxMarkerTime(L, name) {
  var mk, i;
  try {
    mk = L.property("ADBE Marker");
    for (i = 1; i <= mk.numKeys; i++) if (mk.keyValue(i).comment === name) return mk.keyTime(i);
  } catch (e) { /* ignore */ }
  return -1;
}

function sf_fxOffsetExpr(isOut, sharp, d) {
  var ds = d.toFixed(4), A, B;
  if (isOut) { A = -100; B = sharp ? 0 : 100; } else { A = sharp ? 0 : -100; B = 100; }
  if (isOut) {
    return "var t1 = outPoint; var t0 = t1 - " + ds + "; try { t0 = thisLayer.marker.key(\"SF Out\").time; } catch (e) {} " +
      "if (t0 > t1 - 0.04) t0 = t1 - 0.04; linear(time, t0, t1, " + A + ", " + B + ");";
  }
  return "var t0 = inPoint; var t1 = t0 + " + ds + "; try { t1 = thisLayer.marker.key(\"SF In\").time; } catch (e) {} " +
    "if (t1 < t0 + 0.04) t1 = t0 + 0.04; linear(time, t0, t1, " + A + ", " + B + ");";
}

function sf_fxOne(L, sp, isOut, d, px, pw) {
  var an = L.property("ADBE Text Properties").property("ADBE Text Animators").addProperty("ADBE Text Animator");
  var sels = an.property("ADBE Text Selectors"), sel, off;
  an.name = isOut ? "SF FX Out" : "SF FX In";
  sf_fxProps(an, sp, isOut ? -1 : 1, px, pw);
  if (sels.numProperties === 0) sels.addProperty("ADBE Text Selector");
  sel = sels.property(1);
  sf_setSel(sel, sp, isOut);
  off = sel.property("ADBE Text Percent Offset");
  off.setValue(isOut ? -100 : (sp.sh ? 0 : -100));
  off.expression = sf_fxOffsetExpr(isOut, !!sp.sh, d);
  sf_fxMarkerSet(L, isOut ? "SF Out" : "SF In", isOut ? L.outPoint - d : L.inPoint + d);
}

/* the caption box (plate) fades along with the text; it reads the same markers from the text layer right above it */
function sf_fxBox(L) {
  var B = sf_boxOf(L), pOp, mid, base, tIn, tOut, ex;
  if (!B) return;
  pOp = sf_tr(B).property("ADBE Opacity");
  try { pOp.expression = ""; } catch (e0) { /* ignore */ }
  mid = B.inPoint + (B.outPoint - B.inPoint) / 2;
  base = pOp.numKeys > 0 ? pOp.valueAtTime(mid, false) : pOp.value;
  while (pOp.numKeys > 0) pOp.removeKey(1);
  pOp.setValue(base);
  tIn = sf_fxMarkerTime(L, "SF In");
  tOut = sf_fxMarkerTime(L, "SF Out");
  if (tIn < 0 && tOut < 0) return;
  ex = "var T = thisComp.layer(index - 1); var v = value; ";
  if (tIn >= 0) {
    ex += "var t1 = inPoint + " + (tIn - L.inPoint).toFixed(4) + "; try { t1 = T.marker.key(\"SF In\").time; } catch (e) {} " +
      "if (t1 < inPoint + 0.04) t1 = inPoint + 0.04; v = Math.min(v, linear(time, inPoint, t1, 0, value)); ";
  }
  if (tOut >= 0) {
    ex += "var t0 = outPoint - " + (L.outPoint - tOut).toFixed(4) + "; try { t0 = T.marker.key(\"SF Out\").time; } catch (e) {} " +
      "if (t0 > outPoint - 0.04) t0 = outPoint - 0.04; v = Math.min(v, linear(time, t0, outPoint, value, 0)); ";
  }
  pOp.expression = ex + "v;";
}

function sf_isText(L) {
  try { return L.matchName === "ADBE Text Layer"; } catch (e) { return false; }
}

/* effects work on any text layer: selected ones (made by SubLee or by hand), otherwise all captions, otherwise all text layers */
function sf_fxTargets(comp, a) {
  var out = [], i, L, items, it;
  if (a.selectedOnly) {
    for (i = 1; i <= comp.numLayers; i++) {
      L = comp.layer(i);
      if (L.selected && sf_isText(L)) out.push({ comp: comp, layer: L, info: sf_info(L) });
    }
    if (out.length) return out;
  }
  items = sf_collect(comp, {});
  for (i = 0; i < items.length; i++) if (items[i].info.kind === "t") out.push(items[i]);
  if (out.length) return out;
  for (i = 1; i <= comp.numLayers; i++) {
    L = comp.layer(i);
    if (sf_isText(L)) out.push({ comp: comp, layer: L, info: sf_info(L) });
  }
  return out;
}

SF_API.applyFx = function (a) {
  var comp = sf_comp(), t = sf_fxTargets(comp, a), sp = a.spec || {}, i, L, tp, n = 0, dur, dIn, dOut, fps = comp.frameRate;
  var mode = a.mode === "in" || a.mode === "out" ? a.mode : "both";
  var pw = (a.power > 0 ? a.power : 100) / 100, px = sf_base(comp) * 0.05, wantIn = mode !== "out", wantOut = mode !== "in";
  var fIn = a.inFrames > 0 ? a.inFrames : 12, fOut = a.outFrames > 0 ? a.outFrames : 10, cap;
  app.beginUndoGroup("SubLee: text effect");
  try {
    for (i = 0; i < t.length; i++) {
      L = t[i].layer;
      tp = sf_textProp(L);
      if (tp.numKeys > 0) continue;   /* single-layer mode has no per-caption timing - skipped */
      tp = tp.value;
      px = tp.fontSize > 0 ? tp.fontSize : px;
      dur = L.outPoint - L.inPoint;
      cap = wantIn && wantOut ? dur * 0.45 : dur * 0.9;
      dIn = Math.max(1 / fps, Math.min(fIn / fps, cap));
      dOut = Math.max(1 / fps, Math.min(fOut / fps, cap));
      sf_clearFx(L, mode);
      if (wantIn) sf_fxOne(L, sp, false, dIn, px, pw);
      if (wantOut) sf_fxOne(L, sp, true, dOut, px, pw);
      sf_fxBox(L);
      n++;
    }
  } finally { app.endUndoGroup(); }
  return { count: n };
};

SF_API.clearAnimations = function (a) {
  var comp = sf_comp(), items = sf_fxTargets(comp, a), i, n = 0, B;
  app.beginUndoGroup("SubLee: remove animations");
  try {
    for (i = 0; i < items.length; i++) {
      B = sf_boxOf(items[i].layer);
      sf_clearAnim(items[i].layer);
      n++;
      if (B) { sf_clearAnim(B); n++; }
    }
  } finally { app.endUndoGroup(); }
  return { count: n };
};

/* ------------------------------------------------------------------ bounce (expressions on chosen properties) */
function sf_bounceExpr(type, kind, a) {
  var amp = a.amp > 0 ? a.amp : 0.06, freq = a.freq > 0 ? a.freq : 3, decay = a.decay > 0 ? a.decay : 6;
  var e = a.elast > 0 ? a.elast : 0.7, g = kind === "rotation" ? 1500 : (kind === "scale" ? 6000 : 5000);
  if (type === "back") {
    return "var e = " + e + ", g = " + g + ", nMax = 9; var n = 0; if (numKeys > 0) { n = nearestKey(time).index; if (key(n).time > time) n--; } " +
      "if (n > 0) { var t = time - key(n).time; var v = -velocityAtTime(key(n).time - 0.001) * e; var vl = length(v); var vu; " +
      "if (value instanceof Array) { vu = (vl > 0) ? normalize(v) : [0, 0, 0]; } else { vu = (v < 0) ? -1 : 1; } " +
      "var tCur = 0, segDur = 2 * vl / g, tNext = segDur, nb = 1; " +
      "while (tNext < t && nb <= nMax) { vl *= e; segDur *= e; tCur = tNext; tNext = tNext + segDur; nb++; } " +
      "if (nb <= nMax) { var delta = t - tCur; value + vu * delta * (vl - g * delta / 2); } else { value; } } else { value; }";
  }
  return "var amp = " + amp + ", freq = " + freq + ", decay = " + decay + "; var n = 0; if (numKeys > 0) { n = nearestKey(time).index; if (key(n).time > time) n--; } " +
    "if (n > 0) { var t = time - key(n).time; var v = velocityAtTime(key(n).time - thisComp.frameDuration / 10); value + v * amp * Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t); } else { value; }";
}

function sf_bounceProp(L, comp, kind, a, d, px) {
  var tr = sf_tr(L), prop, base, up, pw = (a.power > 0 ? a.power : 100) / 100, t0 = L.inPoint, j, back = a.type === "back";
  if (kind === "position") prop = tr.property("ADBE Position");
  else if (kind === "scale") prop = tr.property("ADBE Scale");
  else prop = tr.property("ADBE Rotate Z");
  try { prop.expression = ""; } catch (e0) { /* ignore */ }
  if (prop.numKeys < 2) {
    while (prop.numKeys > 0) prop.removeKey(1);
    if (kind === "position") {
      base = prop.value; up = [];
      for (j = 0; j < base.length; j++) up.push(base[j]);
      up[1] = back ? base[1] - px * 2.2 * pw : base[1] + px * 0.9 * pw;
      sf_keys(prop, [[t0, up], [t0 + d, base]]);
    } else if (kind === "scale") {
      sf_keys(prop, [[t0, sf_dimVal(prop, 0)], [t0 + d, sf_dimVal(prop, 100)]]);
    } else {
      sf_keys(prop, [[t0, (back ? -25 : -20) * pw], [t0 + d, 0]]);
    }
    try {
      var pOp = tr.property("ADBE Opacity");
      if (pOp.numKeys === 0) { var ov = pOp.value; sf_keys(pOp, [[t0, 0], [t0 + d * 0.5, ov]]); }
    } catch (e1) { /* ignore */ }
  }
  prop.expression = sf_bounceExpr(a.type, kind, a);
}

SF_API.applyBounce = function (a) {
  var comp = sf_comp(), items, i, k, n = 0, skipped = 0, tp, d, px, props = a.props || [], L, sp, p, kindSel;
  app.beginUndoGroup("SubLee: bounce");
  try {
    if (a.useSelected) {
      sp = comp.selectedProperties || [];
      for (i = 0; i < sp.length; i++) {
        p = sp[i];
        if (typeof PropertyType !== "undefined" && p.propertyType !== PropertyType.PROPERTY) continue;
        if (p.canSetExpression === false || p.numKeys < 2) { skipped++; continue; }
        kindSel = p.matchName === "ADBE Rotate Z" ? "rotation" : (p.matchName === "ADBE Scale" ? "scale" : "position");
        try { p.expression = sf_bounceExpr(a.type, kindSel, a); n++; } catch (es) { skipped++; }
      }
      return { count: n, skipped: skipped };
    }
    items = sf_collect(comp, { selectedOnly: !!a.selectedOnly });
    if (a.selectedOnly && !items.length) items = sf_collect(comp, {});
    px = sf_base(comp) * 0.05;
    d = (a.frames > 0 ? a.frames : 8) / comp.frameRate;
    for (i = 0; i < items.length; i++) {
      L = items[i].layer;
      if (items[i].info.kind === "t") {
        tp = sf_textProp(L);
        if (tp.numKeys > 0) continue;   /* single-layer mode: no per-caption timing */
      }
      if (d > (L.outPoint - L.inPoint) * 0.4) { d = (L.outPoint - L.inPoint) * 0.4; }
      if (d < 1 / comp.frameRate) d = 1 / comp.frameRate;
      for (k = 0; k < props.length; k++) {
        if (props[k] === "position" || props[k] === "scale" || props[k] === "rotation") sf_bounceProp(L, comp, props[k], a, d, px);
      }
      n++;
      d = (a.frames > 0 ? a.frames : 8) / comp.frameRate;
    }
  } finally { app.endUndoGroup(); }
  return { count: n, skipped: skipped };
};

/* ------------------------------------------------------------------ After Effects: export a caption look as .mogrt for Premiere Pro */
function sf_region(comp, t, dur) {
  var mv = new MarkerValue("");
  mv.duration = dur;
  mv.protectedRegion = true;
  comp.markerProperty.setValueAtTime(t, mv);
}

/* a = { name, file, text, width, height, fps, duration, style, layout, anim (applyAnimation payload) | fx (applyFx payload), inFrames, outFrames } */
SF_API.exportMogrt = function (a) {
  var prevId = 0, tmp, i, L, inf, tl = null, tp, W = a.width > 0 ? a.width : 1080, H = a.height > 0 ? a.height : 1920;
  var fps = a.fps > 0 ? a.fps : 30, D = a.duration > 0 ? a.duration : 4, warnings = [], dIn, dOut, f, res = {};
  try { if (app.project.activeItem) prevId = app.project.activeItem.id; } catch (e0) { prevId = 0; }
  tmp = app.project.items.addComp("SubLee MOGRT " + a.name, W, H, 1, D, fps);
  tmp.openInViewer();
  SF_API.createCaptions({
    style: a.style, layout: a.layout || { pos: "below", y: 0, safe: 90 }, mode: "multi", replace: false, precomp: false,
    sets: [{ lang: "en", captions: [{ start: 0, end: D, text: a.text }] }]
  });
  if (a.anim && a.anim.preset && a.anim.preset !== "none") SF_API.applyAnimation(a.anim);
  if (a.fx && a.fx.spec) { a.fx.selectedOnly = false; SF_API.applyFx(a.fx); }
  for (i = 1; i <= tmp.numLayers; i++) {
    inf = sf_info(tmp.layer(i));
    if (inf && inf.kind === "t") { tl = tmp.layer(i); break; }
  }
  if (!tl) throw new Error("E_MOGRT_NO_TEXT");
  tp = sf_textProp(tl);
  if (!tp.canAddToMotionGraphicsTemplate(tmp)) throw new Error("E_MOGRT_PROP");
  tp.addToMotionGraphicsTemplate(tmp);
  try { tmp.setMotionGraphicsControllerName(1, "Text"); } catch (e1) { warnings.push("name"); }
  tmp.motionGraphicsTemplateName = a.name;
  /* protected regions: intro and outro keep their length when the clip is stretched in Premiere */
  dIn = (a.inFrames > 0 ? a.inFrames : 12) / fps;
  dOut = (a.outFrames > 0 ? a.outFrames : 10) / fps;
  try {
    if (dIn + dOut < D - 0.2) { sf_region(tmp, 0, dIn); sf_region(tmp, D - dOut, dOut); }
  } catch (e2) { warnings.push("region"); }
  f = new File(a.file);
  try { f.parent.create(); } catch (e3) { /* exists */ }
  res.started = tmp.exportAsMotionGraphicsTemplate(true, f.fsName);   /* the return value is unreliable: the panel waits for the file */
  res.file = f.fsName;
  res.prevId = prevId;
  res.compId = tmp.id;
  res.warnings = warnings;
  return res;
};

SF_API.exportMogrtCleanup = function (a) {
  var i, it, n = 0, prev = null;
  for (i = app.project.numItems; i >= 1; i--) {
    it = app.project.item(i);
    if (it instanceof CompItem && String(it.name).indexOf("SubLee MOGRT ") === 0) { try { it.remove(); n++; } catch (e) { /* busy */ } }
  }
  try { if (a && a.prevId) { prev = app.project.itemByID(a.prevId); if (prev) prev.openInViewer(); } } catch (e2) { /* ignore */ }
  return { removed: n };
};

/* ------------------------------------------------------------------ Premiere Pro (ExtendScript DOM) */
var SF_TICKS = 254016000000;

function sf_secs(t) {
  var n;
  if (t === null || t === undefined) return 0;
  if (typeof t === "number") return t;
  if (t.seconds !== undefined) return Number(t.seconds);
  n = Number(t.ticks);
  return isNaN(n) ? 0 : n / SF_TICKS;
}

function sf_seq() {
  var q = app.project ? app.project.activeSequence : null;
  if (!q) throw new Error("E_PP_NO_SEQUENCE");
  return q;
}

function sf_ppFps(q) {
  var tb = Number(q.timebase);
  return tb > 0 ? SF_TICKS / tb : 30;
}

function sf_ppClipInfo(c, trackKind) {
  var d = { index: 0, name: "", file: "", hasAudio: true, note: "" }, pi, tl, sd;
  try { d.name = String(c.name); } catch (e0) { d.name = "clip"; }
  try {
    pi = c.projectItem;
    if (!pi) { d.note = "notmedia"; return d; }
    try { if (pi.isSequence && pi.isSequence()) { d.note = "precomp"; return d; } } catch (e1) { /* older versions */ }
    d.file = String(pi.getMediaPath() || "");
    if (!d.file) d.note = "nofile";
    d.inPoint = sf_secs(c.start);
    d.startTime = d.inPoint;
    d.srcStart = sf_secs(c.inPoint);
    sd = sf_secs(c.outPoint) - d.srcStart;
    tl = sf_secs(c.end) - d.inPoint;
    d.srcDur = sd > 0 ? sd : tl;
    d.outPoint = sf_secs(c.end);
    d.stretch = (sd > 0 && tl > 0) ? tl * 100 / sd : 100;
    d.track = trackKind;
  } catch (e) { d.note = "error"; }
  return d;
}

SF_API.ppContext = function () {
  var q = sf_seq(), fps = sf_ppFps(q), res, sel, i, j, k, tr, c, o, seen = {}, key, end = 0, kinds = ["video", "audio"], tracks, e;
  res = { host: "PPRO", aeVersion: String(app.version),
    comp: { name: String(q.name), width: Number(q.frameSizeHorizontal), height: Number(q.frameSizeVertical), fps: fps, duration: 0, time: sf_secs(q.getPlayerPosition()), workStart: 0, workDur: 0 },
    layers: [], all: [], sfCount: 0, langs: {} };
  try { sel = q.getSelection(); } catch (e0) { sel = []; }
  for (i = 0; i < sel.length; i++) {
    o = sf_ppClipInfo(sel[i], "sel");
    key = o.file + "|" + o.inPoint + "|" + o.srcStart;
    if (o.note === "" && seen[key]) continue;
    seen[key] = 1;
    res.layers.push(o);
  }
  for (k = 0; k < 2; k++) {
    tracks = k === 0 ? q.videoTracks : q.audioTracks;
    for (j = 0; j < tracks.numTracks; j++) {
      tr = tracks[j];
      for (i = 0; i < tr.clips.numItems; i++) {
        c = tr.clips[i];
        e = sf_secs(c.end);
        if (e > end) end = e;
        if (k === 1 || res.all.length < 30) {
          o = sf_ppClipInfo(c, kinds[k]);
          key = o.file + "|" + o.inPoint + "|" + o.srcStart;
          if (o.file && !seen["a" + key] && res.all.length < 30) { seen["a" + key] = 1; res.all.push(o); }
        }
      }
    }
  }
  res.comp.duration = end;
  res.comp.workDur = end;
  res.videoTracks = q.videoTracks.numTracks;
  return res;
};

/* a track is "free" when no clip overlaps [t0, t1] */
function sf_ppTrackFree(tr, t0, t1) {
  var i, c;
  for (i = 0; i < tr.clips.numItems; i++) {
    c = tr.clips[i];
    if (sf_secs(c.start) < t1 - 0.001 && sf_secs(c.end) > t0 + 0.001) return false;
  }
  return true;
}

function sf_ppJsonText(v, text) {
  var re = /"textEditValue"\s*:\s*"(?:[^"\\]|\\.)*"/, runs = /"fontTextRunLength"\s*:\s*\[[^\]]*\]/;
  if (!re.test(v)) return null;
  var out = v.replace(re, function () { return '"textEditValue":"' + sf_esc(text) + '"'; });
  if (runs.test(out)) out = out.replace(runs, function () { return '"fontTextRunLength":[' + text.length + ']'; });
  return out;
}

function sf_ppSetText(item, text, paramName) {
  var comp = item.getMGTComponent(), props, n, i, p, v, nm, hit = null, wanted = paramName ? String(paramName) : "Text", out;
  if (!comp) throw new Error("E_PP_NO_MGT");
  props = comp.properties;
  n = props.numItems;
  for (i = 0; i < n; i++) {
    p = props[i];
    nm = "";
    try { nm = String(p.displayName); } catch (e0) { nm = ""; }
    if (nm === wanted) { hit = p; break; }
  }
  if (!hit) {
    for (i = 0; i < n; i++) {   /* otherwise the first text-like parameter */
      p = props[i];
      try { v = p.getValue(); } catch (e1) { v = null; }
      if (typeof v === "string" && v.indexOf("textEditValue") >= 0) { hit = p; break; }
    }
  }
  if (!hit) throw new Error("E_PP_NO_TEXT_PARAM");
  text = String(text).replace(/\r?\n/g, "\r");
  v = null;
  try { v = hit.getValue(); } catch (e2) { v = null; }
  out = (typeof v === "string") ? sf_ppJsonText(v, text) : null;
  hit.setValue(out !== null ? out : text, true);
}

/* a = { mogrt, textParam, replace, sets: [{ lang, captions: [{ start, end, text }] }] } */
SF_API.ppInsert = function (a) {
  var q = sf_seq(), sets = a.sets, si, ci, caps, cap, t0 = 1e9, t1 = -1e9, free = [], ti, tr, item, created = 0, errors = [], tracks = [], e, i, c, removed = 0, tend;
  if (!a.mogrt) throw new Error("E_PP_NO_MOGRT");
  for (si = 0; si < sets.length; si++) {
    for (ci = 0; ci < sets[si].captions.length; ci++) {
      if (sets[si].captions[ci].start < t0) t0 = sets[si].captions[ci].start;
      if (sets[si].captions[ci].end > t1) t1 = sets[si].captions[ci].end;
    }
  }
  if (a.replace) {   /* remove the previous SubLee clips in this time range */
    for (ti = 0; ti < q.videoTracks.numTracks; ti++) {
      tr = q.videoTracks[ti];
      for (i = tr.clips.numItems - 1; i >= 0; i--) {
        c = tr.clips[i];
        if (String(c.name).indexOf("SubLee") === 0 && sf_secs(c.start) < t1 && sf_secs(c.end) > t0) {
          try { c.remove(false, false); removed++; } catch (er) { /* locked track */ }
        }
      }
    }
  }
  for (ti = q.videoTracks.numTracks - 1; ti >= 0 && free.length < sets.length; ti--) {
    if (sf_ppTrackFree(q.videoTracks[ti], t0, t1)) free.push(ti);
  }
  if (free.length < sets.length) throw new Error("E_PP_NO_FREE_TRACK");
  for (si = 0; si < sets.length; si++) {
    caps = sets[si].captions;
    tracks.push(free[si] + 1);
    for (ci = 0; ci < caps.length; ci++) {
      cap = caps[ci];
      try {
        item = q.importMGT(a.mogrt, String(Math.round(cap.start * SF_TICKS)), free[si], 0);
        if (!item) throw new Error("E_PP_IMPORT");
        sf_ppSetText(item, cap.text, a.textParam);
        try { tend = new Time(); tend.seconds = cap.end; item.end = tend; } catch (ee) { /* keeps the template length */ }
        try { item.name = "SubLee " + String(sets[si].lang).toUpperCase() + ": " + String(cap.text).replace(/\s+/g, " ").substr(0, 40); } catch (en) { /* ignore */ }
        created++;
      } catch (e) {
        if (errors.length < 3) errors.push(String(e && e.message ? e.message : e));
      }
    }
  }
  return { created: created, errors: errors, tracks: tracks, removed: removed };
};

/* fallback without a template: import an .srt and add it as a caption track */
SF_API.ppImportSrt = function (a) {
  var q = sf_seq(), before, item = null, i, kids, t, ok = false, errs = [], base = String(a.file).replace(/^.*[\\\/]/, "");
  app.project.importFiles([a.file], true, app.project.getInsertionBin(), false);
  kids = app.project.rootItem.children;
  for (i = kids.numItems - 1; i >= 0; i--) { if (String(kids[i].name) === base) { item = kids[i]; break; } }
  if (!item) throw new Error("E_PP_SRT_NOT_FOUND");
  t = new Time(); t.seconds = a.start > 0 ? a.start : 0;
  try { q.createCaptionTrack(item, t.seconds); ok = true; } catch (e1) { errs.push(String(e1.message || e1)); }
  if (!ok) { try { q.createCaptionTrack(item, t, 0); ok = true; } catch (e2) { errs.push(String(e2.message || e2)); } }
  if (!ok) throw new Error("E_PP_CAPTION_TRACK " + errs.join(" | "));
  return { created: 1, imported: base };
};

/* removes every SubLee clip from the video tracks */
SF_API.ppDeleteAll = function (a) {
  var q = sf_seq(), ti, tr, ci, c, n = 0, nm;
  for (ti = 0; ti < q.videoTracks.numTracks; ti++) {
    tr = q.videoTracks[ti];
    for (ci = tr.clips.numItems - 1; ci >= 0; ci--) {
      c = tr.clips[ci];
      nm = String(c.name || '');
      if (nm.indexOf('SubLee') === 0) { try { c.remove(false, false); n++; } catch (e) { /* skip */ } }
    }
  }
  return { count: n };
};

/* parameters of the first selected MOGRT clip (to see how a template exposes its text) */
SF_API.ppDiag = function () {
  var q = sf_seq(), sel = q.getSelection(), i, comp, j, p, out = { sequence: String(q.name), videoTracks: q.videoTracks.numTracks, params: [] }, v;
  for (i = 0; i < sel.length; i++) {
    try { comp = sel[i].getMGTComponent(); } catch (e0) { comp = null; }
    if (!comp) continue;
    for (j = 0; j < comp.properties.numItems; j++) {
      p = comp.properties[j];
      try { v = p.getValue(); } catch (e1) { v = "?"; }
      out.params.push({ name: String(p.displayName), value: String(v).substr(0, 160) });
    }
    break;
  }
  return out;
};

/* ------------------------------------------------------------------ dispatcher */
function sf_call(name, argJson) {
  var res, arg;
  try {
    arg = argJson ? eval("(" + argJson + ")") : {};
    if (!SF_API[name]) return sf_stringify({ ok: false, error: "E_UNKNOWN_API " + name });
    res = SF_API[name](arg);
    if (res === null || res === undefined) res = {};
    res.ok = true;
    return sf_stringify(res);
  } catch (e) {
    return sf_stringify({ ok: false, error: String(e && e.message ? e.message : e), line: (e && e.line) ? e.line : 0 });
  }
}
